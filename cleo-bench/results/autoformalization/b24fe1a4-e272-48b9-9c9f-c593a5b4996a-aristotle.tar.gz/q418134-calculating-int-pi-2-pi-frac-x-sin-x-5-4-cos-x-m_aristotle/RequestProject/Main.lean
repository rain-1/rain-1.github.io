import Mathlib

open scoped BigOperators
open scoped Real
open scoped Nat
open scoped Classical
open scoped Pointwise

open MeasureTheory intervalIntegral

set_option maxHeartbeats 8000000
set_option maxRecDepth 4000
set_option synthInstance.maxHeartbeats 40000
set_option synthInstance.maxSize 128

set_option relaxedAutoImplicit false
set_option autoImplicit false

/-!
# Cleo Bench Problem 7

Evaluation of `∫_{π/2}^{π} x·sin x / (5 - 4 cos x) dx`.

The result is
`π/8 · log(81/20) - 1/2 · Ti₂(1/2)`,
where `Ti₂(1/2)` is the inverse tangent integral `∫_0^{1/2} arctan t / t dt`.
-/

namespace Cleo7

/-- The inverse tangent integral `Ti₂(1/2) = ∫_0^{1/2} arctan t / t dt`. -/
noncomputable def Ti2half : ℝ := ∫ t in (0:ℝ)..(1/2), Real.arctan t / t

/-- The alternating series representation of `Ti₂(1/2)`,
`∑_{k≥0} (-1)^k / ((2k+1)² · 2^{2k+1})`. -/
noncomputable def S : ℝ :=
  ∑' k : ℕ, ((-1 : ℝ) ^ k) / ((2 * (k : ℝ) + 1) ^ 2 * (2 : ℝ) ^ (2 * k + 1))

/-- The `n`-th term of the Fourier series of `log(5 - 4 cos x)`
(up to the constant `2 log 2`). -/
noncomputable def fourierTerm (n : ℕ) (x : ℝ) : ℝ :=
  -2 * Real.cos ((n : ℝ) * x) / ((n : ℝ) * 2 ^ n)

/-
The denominator `5 - 4 cos x` is strictly positive.
-/
lemma denom_pos (x : ℝ) : 0 < 5 - 4 * Real.cos x := by
  linarith [ Real.cos_le_one x ]

/-
Derivative of `log(5 - 4 cos x)`.
-/
lemma hasDerivAt_log_denom (x : ℝ) :
    HasDerivAt (fun y => Real.log (5 - 4 * Real.cos y))
      (4 * Real.sin x / (5 - 4 * Real.cos x)) x := by
  convert HasDerivAt.log ( HasDerivAt.const_sub 5 ( HasDerivAt.const_mul 4 ( Real.hasDerivAt_cos x ) ) ) ( show ( 5 - 4 * Real.cos x ) ≠ 0 from by nlinarith [ Real.cos_sq' x ] ) using 1 ; ring

/-
Integration by parts step.
-/
lemma ibp :
    (∫ x in (π / 2)..π, x * Real.sin x / (5 - 4 * Real.cos x))
      = π * (Real.log 9 / 4) - (π / 2) * (Real.log 5 / 4)
        - (1 / 4) * (∫ x in (π / 2)..π, Real.log (5 - 4 * Real.cos x)) := by
  -- Apply integration by parts with $u = x$ and $dv = \frac{\sin x}{5 - 4 \cos x} dx$.
  have h_parts : ∀ a b : ℝ, ∫ x in a..b, x * (Real.sin x / (5 - 4 * Real.cos x)) = (b * (1 / 4) * Real.log (5 - 4 * Real.cos b)) - (a * (1 / 4) * Real.log (5 - 4 * Real.cos a)) - ∫ x in a..b, (1 / 4) * Real.log (5 - 4 * Real.cos x) := by
    intro a b; rw [ eq_sub_iff_add_eq ] ; rw [ ← intervalIntegral.integral_add ] ; rw [ intervalIntegral.integral_eq_sub_of_hasDerivAt ] ; norm_num ; ring;
    · intro x hx; convert HasDerivAt.mul ( HasDerivAt.mul ( hasDerivAt_id x ) ( HasDerivAt.log ( HasDerivAt.sub ( hasDerivAt_const _ _ ) ( HasDerivAt.mul ( Real.hasDerivAt_cos x ) ( hasDerivAt_const _ _ ) ) ) _ ) ) ( hasDerivAt_const _ _ ) using 1 <;> norm_num ; ring ; nlinarith [ Real.cos_sq' x ] ;
    · exact Continuous.intervalIntegrable ( by exact Continuous.add ( Continuous.mul continuous_id ( Real.continuous_sin.div ( by continuity ) fun x => by linarith [ abs_le.mp ( Real.abs_cos_le_one x ) ] ) ) ( Continuous.mul continuous_const ( Continuous.log ( by continuity ) fun x => by linarith [ abs_le.mp ( Real.abs_cos_le_one x ) ] ) ) ) a b;
    · exact Continuous.intervalIntegrable ( by exact Continuous.mul continuous_id ( Real.continuous_sin.div ( by continuity ) fun x => by linarith [ abs_le.mp ( Real.abs_cos_le_one x ) ] ) ) _ _;
    · exact Continuous.intervalIntegrable ( by exact Continuous.mul continuous_const <| Continuous.log ( by continuity ) fun x => by linarith [ abs_le.mp ( Real.abs_cos_le_one x ) ] ) _ _;
  convert h_parts ( Real.pi / 2 ) Real.pi using 1 <;> norm_num [ mul_div_assoc ] ; ring

/-
Pointwise Fourier expansion: for every `x`,
`∑_n fourierTerm n x = log(5 - 4 cos x) - 2 log 2`.
-/
lemma hasSum_fourier (x : ℝ) :
    HasSum (fun n : ℕ => fourierTerm n x)
      (Real.log (5 - 4 * Real.cos x) - 2 * Real.log 2) := by
  -- We'll use the fact that the series representation of `log(5 - 4 cos x)` converges to `log(5 - 4 cos x) - 2 log 2`.
  have h_series : HasSum (fun n : ℕ => (Real.cos (n * x)) / (n * 2^n)) ((Real.log (5 - 4 * Real.cos x)) / (-2) + Real.log 2) := by
    -- Consider the series $\sum_{n=1}^{\infty} \frac{z^n}{n}$ where $z = \frac{1}{2} e^{ix}$.
    set z : ℂ := (1 / 2 : ℂ) * Complex.exp (x * Complex.I)
    have hz : ‖z‖ < 1 := by
      norm_num [ z, Complex.norm_exp ]
    have h_series : HasSum (fun n : ℕ => z^n / (n : ℂ)) (-Complex.log (1 - z)) := by
      exact?
    have h_series_real : HasSum (fun n : ℕ => (Real.cos (n * x)) / (n * 2^n)) (-(Complex.log (1 - z)).re) := by
      convert Complex.hasSum_re ( h_series ) using 1 ; norm_num [ Complex.exp_re, Complex.exp_im, Complex.log_re, Complex.log_im ] ; ring_nf ; norm_num [ pow_mul', mul_assoc, mul_comm, mul_left_comm ] ; ring_nf;
      ext; rw [ show z ^ _ = ( 1 / 2 ) ^ _ * Complex.exp ( ↑ ( ‹_› : ℕ ) * x * Complex.I ) by rw [ mul_pow, ← Complex.exp_nat_mul ] ; ring ] ; norm_num [ Complex.exp_re, Complex.exp_im, pow_mul' ] ; ring;
      norm_num [ show ( 1 / 2 : ℂ ) ^ ‹_› = ( 1 / 2 : ℝ ) ^ ‹_› by norm_num [ Complex.ext_iff, pow_succ ] ];
      norm_cast ; norm_num
    have h_log_real : (Complex.log (1 - z)).re = Real.log (Real.sqrt (5 / 4 - Real.cos x)) := by
      norm_num [ Complex.log_re, Complex.normSq, Complex.norm_def, Complex.exp_re, Complex.exp_im ] at *;
      norm_num [ z, Complex.exp_re, Complex.exp_im ] ; ring; norm_num [ Real.cos_sq' ] ; ring;
    have h_log_simplified : (Complex.log (1 - z)).re = (Real.log (5 - 4 * Real.cos x)) / 2 - Real.log 2 := by
      rw [ h_log_real, Real.log_sqrt ] <;> ring <;> norm_num <;> try nlinarith [ Real.cos_sq' x ] ;
      rw [ show ( 5 / 4 - Real.cos x ) = ( 5 - Real.cos x * 4 ) / 4 by ring, Real.log_div ] <;> norm_num ; ring;
      · rw [ show ( 4 : ℝ ) = 2 ^ 2 by norm_num, Real.log_pow ] ; ring;
      · nlinarith [ Real.cos_sq' x ]
    have h_final : (-(Complex.log (1 - z)).re) = (Real.log (5 - 4 * Real.cos x)) / (-2) + Real.log 2 := by
      linarith
    exact h_series_real.trans (by
    rw [h_final]);
  convert h_series.mul_left ( -2 ) using 1 ; norm_num [ fourierTerm ] ; ring;
  · exact funext fun n => by ring;
  · ring

/-
Integral of the `n`-th Fourier term over `[π/2, π]`.
-/
lemma fourier_term_integral (n : ℕ) :
    (∫ x in (π / 2)..π, fourierTerm n x)
      = 2 * Real.sin ((n : ℝ) * (π / 2)) / ((n : ℝ) ^ 2 * 2 ^ n) := by
  by_cases hn : n = 0 <;> simp_all +decide [ fourierTerm ];
  grind

/-
Term-by-term integration is justified (uniform/absolute convergence).
-/
lemma fourier_swap :
    (∫ x in (π / 2)..π, (Real.log (5 - 4 * Real.cos x) - 2 * Real.log 2))
      = ∑' n : ℕ, ∫ x in (π / 2)..π, fourierTerm n x := by
  -- We want to show that $\int_{\pi/2}^{\pi} \sum_{n=1}^{\infty} \frac{-2 \cos(nx)}{n \cdot 2^n} dx = \sum_{n=1}^{\infty} \int_{\pi/2}^{\pi} \frac{-2 \cos(nx)}{n \cdot 2^n} dx$.
  have h_integral_sum : ∫ x in (Real.pi / 2)..Real.pi, ∑' n : ℕ, fourierTerm n x = ∑' n : ℕ, ∫ x in (Real.pi / 2)..Real.pi, fourierTerm n x := by
    have h_summable_integral_norm : Summable (fun n : ℕ => ∫ x in Set.Icc (Real.pi / 2) Real.pi, ‖fourierTerm n x‖) := by
      have h_abs_conv : ∀ n : ℕ, ∫ x in Set.Icc (Real.pi / 2) Real.pi, ‖fourierTerm n x‖ ≤ Real.pi / 2 * (2 / (n * 2 ^ n)) := by
        intro n
        have h_abs_conv : ∀ x ∈ Set.Icc (Real.pi / 2) Real.pi, ‖fourierTerm n x‖ ≤ 2 / (n * 2 ^ n) := by
          intro x hx; unfold fourierTerm; norm_num [ abs_div, abs_mul ] ; ring_nf; norm_num;
          exact mul_le_of_le_one_left ( by positivity ) ( Real.abs_cos_le_one _ );
        convert MeasureTheory.setIntegral_mono_on _ _ _ h_abs_conv <;> norm_num;
        · exact Or.inl ( by rw [ max_eq_left ] <;> linarith [ Real.pi_pos ] );
        · exact Continuous.integrableOn_Icc ( by unfold fourierTerm; continuity );
      refine' Summable.of_nonneg_of_le ( fun n => MeasureTheory.integral_nonneg fun x => norm_nonneg _ ) ( fun n => h_abs_conv n ) _;
      ring_nf;
      exact Summable.of_nonneg_of_le ( fun n => by positivity ) ( fun n => mul_le_mul_of_nonneg_right ( mul_le_mul_of_nonneg_left ( show ( n : ℝ ) ⁻¹ ≤ 1 by cases n <;> simpa using inv_le_one_of_one_le₀ <| mod_cast Nat.le_add_left _ _ ) <| by positivity ) <| by positivity ) <| Summable.mul_left _ <| summable_geometric_of_lt_one ( by positivity ) <| by norm_num;
    rw [ intervalIntegral.integral_of_le ( by linarith [ Real.pi_pos ] ), MeasureTheory.integral_tsum ];
    · exact tsum_congr fun n => by rw [ intervalIntegral.integral_of_le ( by linarith [ Real.pi_pos ] ) ] ;
    · exact fun n => Continuous.aestronglyMeasurable ( by unfold fourierTerm; continuity );
    · refine' ne_of_lt ( lt_of_le_of_lt ( ENNReal.tsum_le_tsum fun n => _ ) _ );
      use fun n => ENNReal.ofReal ( ∫ x in Set.Icc ( Real.pi / 2 ) Real.pi, ‖fourierTerm n x‖ );
      · rw [ MeasureTheory.ofReal_integral_eq_lintegral_ofReal ];
        · rw [ MeasureTheory.Measure.restrict_congr_set MeasureTheory.Ioc_ae_eq_Icc ];
          norm_num [ ENNReal.ofReal ];
          rfl;
        · exact Continuous.integrableOn_Icc ( by unfold fourierTerm; continuity );
        · exact Filter.Eventually.of_forall fun x => norm_nonneg _;
      · exact Summable.tsum_ofReal_lt_top h_summable_integral_norm;
  rw [ ← h_integral_sum, intervalIntegral.integral_congr fun x hx => HasSum.tsum_eq ( hasSum_fourier x ) ]

/-
Evaluation of the resulting series (keeping only the odd-index terms).
-/
lemma fourier_sum_eval :
    (∑' n : ℕ, 2 * Real.sin ((n : ℝ) * (π / 2)) / ((n : ℝ) ^ 2 * 2 ^ n)) = 2 * S := by
  rw [ ← tsum_even_add_odd ];
  · norm_num [ add_mul, mul_assoc, mul_left_comm, Real.sin_add ];
    norm_num [ mul_div_cancel₀, S ];
    rw [ ← tsum_mul_left ] ; congr ; ext k ; rw [ show Real.cos ( k * Real.pi ) = ( -1 : ℝ ) ^ k by rw [ ← Real.rpow_natCast, Real.rpow_def_of_nonpos ] <;> norm_num ] ; ring;
  · norm_num [ mul_assoc, mul_left_comm, mul_div_cancel₀ ];
  · norm_num [ add_mul, mul_assoc, mul_left_comm, Real.sin_add ];
    ring_nf;
    refine Summable.mul_right _ <| .of_norm ?_;
    norm_num [ pow_mul' ];
    norm_num [ Real.abs_cos_eq_sqrt_one_sub_sin_sq ];
    exact Summable.of_nonneg_of_le ( fun n => by positivity ) ( fun n => by rw [ inv_le_comm₀ ] <;> norm_num <;> norm_cast <;> induction' n with n ih <;> norm_num [ pow_succ' ] at * ; nlinarith [ pow_pos ( show 0 < 4 by norm_num ) n ] ) ( summable_nat_add_iff 1 |>.2 <| Real.summable_one_div_nat_pow.2 one_lt_two )

/-
The log-integral evaluates to `π log 2 + 2 S`.
-/
lemma log_integral_eq :
    (∫ x in (π / 2)..π, Real.log (5 - 4 * Real.cos x)) = π * Real.log 2 + 2 * S := by
  -- Apply the Fourier series expansion to rewrite the integral.
  have h_fourier : ∫ x in (Real.pi / 2)..Real.pi, Real.log (5 - 4 * Real.cos x) = (∫ x in (Real.pi / 2)..Real.pi, 2 * Real.log 2) + (∑' n : ℕ, ∫ x in (Real.pi / 2)..Real.pi, fourierTerm n x) := by
    rw [ ← fourier_swap, ← intervalIntegral.integral_add ];
    · norm_num;
    · norm_num;
    · exact Continuous.intervalIntegrable ( by exact Continuous.sub ( Continuous.log ( by continuity ) fun x => by nlinarith [ Real.cos_sq' x ] ) continuous_const ) _ _;
  simp_all +decide [ mul_comm ];
  rw [ show ( ∑' n : ℕ, ∫ x in Real.pi / 2..Real.pi, fourierTerm n x ) = 2 * S by rw [ ← fourier_sum_eval ] ; exact tsum_congr fun n => fourier_term_integral n ] ; ring

/-
The inverse tangent integral equals its alternating series.
-/
lemma Ti2half_eq_S : Ti2half = S := by
  -- Apply the theorem that allows term-by-term integration for power series.
  have h_integral_series : ∫ t in (0:ℝ)..(1/2), (∑' k : ℕ, (-1 : ℝ) ^ k * t ^ (2 * k) / (2 * k + 1)) = ∑' k : ℕ, ∫ t in (0:ℝ)..(1/2), (-1 : ℝ) ^ k * t ^ (2 * k) / (2 * k + 1) := by
    rw [ intervalIntegral.integral_of_le, MeasureTheory.integral_tsum ];
    · norm_num [ intervalIntegral.integral_of_le ];
    · exact fun i => Continuous.aestronglyMeasurable ( by continuity );
    · refine' ne_of_lt ( lt_of_le_of_lt ( ENNReal.tsum_le_tsum fun i => _ ) _ );
      use fun i => ENNReal.ofReal ( ( 1 / 2 ) ^ ( 2 * i ) / ( 2 * i + 1 ) ) * ENNReal.ofReal ( 1 / 2 );
      · refine' le_trans ( MeasureTheory.setLIntegral_mono' measurableSet_Ioc fun x hx => _ ) _;
        use fun x => ENNReal.ofReal ( x ^ ( 2 * i ) / ( 2 * i + 1 ) );
        · rw [ ENNReal.le_ofReal_iff_toReal_le ] <;> norm_num;
          · rw [ abs_of_nonneg hx.1.le, abs_of_nonneg ( by positivity ) ];
          · exact div_nonneg ( pow_nonneg hx.1.le _ ) ( by positivity );
        · refine' le_trans ( MeasureTheory.setLIntegral_mono' measurableSet_Ioc fun x hx => ENNReal.ofReal_le_ofReal <| div_le_div_of_nonneg_right ( pow_le_pow_left₀ ( by linarith [ hx.1 ] ) hx.2 _ ) <| by positivity ) _ ; norm_num;
      · rw [ ENNReal.tsum_mul_right ];
        rw [ ← ENNReal.ofReal_tsum_of_nonneg ] <;> norm_num [ pow_mul ];
        · exact ENNReal.mul_lt_top ( ENNReal.ofReal_lt_top ) ( ENNReal.ofReal_lt_top );
        · exact fun n => by positivity;
        · exact Summable.of_nonneg_of_le ( fun i => by positivity ) ( fun i => by exact div_le_self ( by positivity ) ( by linarith ) ) ( summable_geometric_of_lt_one ( by norm_num ) ( by norm_num ) );
    · norm_num;
  convert h_integral_series using 1;
  · refine' intervalIntegral.integral_congr_ae _;
    -- By definition of arctan, we know that $\arctan(x) = \sum_{k=0}^{\infty} (-1)^k \frac{x^{2k+1}}{2k+1}$ for $|x| < 1$.
    have h_arctan_series : ∀ x : ℝ, |x| < 1 → Real.arctan x = ∑' k : ℕ, (-1 : ℝ) ^ k * x ^ (2 * k + 1) / (2 * k + 1) := by
      intro x hx; have := Real.hasSum_arctan hx; have := this.tsum_eq; aesop;
    filter_upwards [ MeasureTheory.measure_eq_zero_iff_ae_notMem.1 ( MeasureTheory.measure_singleton 0 ) ] with x hx using fun hx' => by rw [ h_arctan_series x ( abs_lt.2 ⟨ by cases Set.mem_uIoc.1 hx' <;> linarith, by cases Set.mem_uIoc.1 hx' <;> linarith ⟩ ), div_eq_iff ( by aesop ) ] ; rw [ ← tsum_mul_right ] ; exact tsum_congr fun k => by ring;
  · norm_num [ S ];
    field_simp;
    exact tsum_congr fun n => by rw [ div_mul_eq_div_div ] ; rw [ div_pow ] ; ring;

/-
**Main result.**
-/
theorem integral_eq :
    (∫ x in (π / 2)..π, x * Real.sin x / (5 - 4 * Real.cos x))
      = π / 8 * Real.log (81 / 20) - 1 / 2 * Ti2half := by
  convert ibp using 1;
  rw [Ti2half_eq_S, log_integral_eq]
  rw [show (81 / 20 : ℝ) = 9 ^ 2 / (2 ^ 2 * 5) by norm_num, Real.log_div (by norm_num) (by norm_num),
    Real.log_mul (by norm_num) (by norm_num), Real.log_pow, Real.log_pow]
  ring

end Cleo7