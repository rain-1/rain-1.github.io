import RequestProject.LogRate

/-!
# Admissible approximation sequences and construction quality

This file introduces the two notions from the definition in Section 1 of the paper:
an *admissible approximation sequence* to a real number `α`, and its *construction
quality*
`δ(q,p) = liminf (-log|α - pₙ/qₙ|) / log|qₙ|`.

The liminf is taken in `EReal` so that the definition is meaningful (and the theorem
below is not vacuous) even for sequences along which the ratio is unbounded.

The main result of the file, `CatalanLCM.quality_of_bounds`, converts two-sided
exponential information on a pair of sequences into a lower bound for the construction
quality: if `log|qₙ| ≥ (H - ε)n` and `log|qₙα - pₙ| ≤ (F/H) log|qₙ| + εn` for every
`ε > 0`, then the quality is at least `(H - F)/H`.
-/

namespace CatalanLCM

open Filter Real
open scoped Topology

/-- An *admissible approximation sequence* to `α`: eventually `qₙ ≠ 0` and
`qₙ α - pₙ ≠ 0`, and `|qₙ| → ∞`. -/
def AdmissibleApprox (α : ℝ) (q p : ℕ → ℤ) : Prop :=
  (∀ᶠ n in atTop, q n ≠ 0 ∧ (q n : ℝ) * α - p n ≠ 0) ∧
    Tendsto (fun n => |(q n : ℝ)|) atTop atTop

/-- The *construction quality* of an approximation sequence,
`liminf (-log|α - pₙ/qₙ|)/log|qₙ|`, computed in `EReal`. -/
noncomputable def constructionQuality (α : ℝ) (q p : ℕ → ℤ) : EReal :=
  liminf (fun n : ℕ =>
    (((-Real.log |α - (p n : ℝ) / (q n : ℝ)|) / Real.log |(q n : ℝ)| : ℝ) : EReal)) atTop

/-- The elementary rewriting of the quality ratio in terms of the linear form
`ℓ = qα - p`. -/
lemma quality_ratio_eq {α : ℝ} {q p : ℤ} (hq : (q : ℝ) ≠ 0) (h0 : (q : ℝ) * α - p ≠ 0)
    (hlog : Real.log |(q : ℝ)| ≠ 0) :
    (-Real.log |α - (p : ℝ) / (q : ℝ)|) / Real.log |(q : ℝ)|
      = 1 - Real.log |(q : ℝ) * α - p| / Real.log |(q : ℝ)| := by
  have hrw : α - (p : ℝ) / q = ((q : ℝ) * α - p) / q := by field_simp
  rw [hrw, abs_div, Real.log_div (abs_ne_zero.2 h0) (abs_ne_zero.2 hq)]
  field_simp
  ring

/-- **From exponential bounds to a quality bound.**  If the heights satisfy
`log|qₙ| ≥ (H - ε)n` and the linear forms satisfy
`log|qₙα - pₙ| ≤ (F/H)·log|qₙ| + εn` for every `ε > 0`, then `(qₙ, pₙ)` is an
admissible approximation sequence of construction quality at least `(H - F)/H`. -/
theorem quality_of_bounds {α : ℝ} {q p : ℕ → ℤ} {H F : ℝ} (hF : 0 < F) (hHF : F < H)
    (hq : ∀ ε : ℝ, 0 < ε → ∀ᶠ n : ℕ in atTop, (H - ε) * n ≤ Real.log |(q n : ℝ)|)
    (hne : ∀ᶠ n in atTop, (q n : ℝ) * α - p n ≠ 0)
    (hl : ∀ ε : ℝ, 0 < ε → ∀ᶠ n : ℕ in atTop,
      Real.log |(q n : ℝ) * α - p n| ≤ (F / H) * Real.log |(q n : ℝ)| + ε * n) :
    AdmissibleApprox α q p ∧ (((H - F) / H : ℝ) : EReal) ≤ constructionQuality α q p := by
  have hH : 0 < H := lt_trans hF hHF
  -- a first, crude lower bound for the height
  have hhalf : ∀ᶠ n : ℕ in atTop, Real.exp (H / 2 * n) ≤ |(q n : ℝ)| := by
    filter_upwards [hq (H / 2) (by linarith), eventually_gt_atTop 0] with n hn hn0
    have hnpos : (0 : ℝ) < n := by exact_mod_cast hn0
    have hqne : (q n : ℝ) ≠ 0 := by
      intro h
      rw [h] at hn
      simp only [abs_zero, Real.log_zero] at hn
      nlinarith
    have hmono := Real.exp_le_exp.2 hn
    rw [Real.exp_log (abs_pos.2 hqne)] at hmono
    rwa [show H - H / 2 = H / 2 by ring] at hmono
  have hqne : ∀ᶠ n : ℕ in atTop, (q n : ℝ) ≠ 0 := by
    filter_upwards [hhalf] with n hn
    intro h
    rw [h] at hn
    simpa using lt_of_lt_of_le (Real.exp_pos _) hn
  have htend : Tendsto (fun n : ℕ => |(q n : ℝ)|) atTop atTop := by
    refine tendsto_atTop_mono' _ hhalf ?_
    exact Real.tendsto_exp_atTop.comp
      (Filter.Tendsto.const_mul_atTop (by linarith : (0:ℝ) < H / 2) tendsto_natCast_atTop_atTop)
  refine ⟨⟨?_, htend⟩, ?_⟩
  · filter_upwards [hqne, hne] with n h1 h2
    exact ⟨by exact_mod_cast h1, h2⟩
  -- the quality bound
  refine EReal.ge_of_forall_gt_iff_ge.mp ?_
  intro c hc
  have hclt : c < (H - F) / H := by exact_mod_cast hc
  set d : ℝ := (H - F) / H - c with hd
  have hdpos : 0 < d := by simp only [hd]; linarith
  set ε : ℝ := min (H / 2) (d * H / 4) with hεdef
  have hεpos : 0 < ε := lt_min (by linarith) (by positivity)
  have hε1 : ε ≤ H / 2 := min_le_left _ _
  have hε2 : ε ≤ d * H / 4 := min_le_right _ _
  refine le_liminf_of_le (by isBoundedDefault) ?_
  filter_upwards [hq ε hεpos, hl ε hεpos, hqne, hne, eventually_gt_atTop 0] with
    n hqn hln hq0 hℓ0 hn0
  have hnpos : (0 : ℝ) < n := by exact_mod_cast hn0
  have hlogpos : 0 < Real.log |(q n : ℝ)| := lt_of_lt_of_le (by nlinarith) hqn
  have hratio : Real.log |(q n : ℝ) * α - p n| / Real.log |(q n : ℝ)|
      ≤ F / H + ε * n / Real.log |(q n : ℝ)| := by
    rw [div_le_iff₀ hlogpos]
    have : (F / H + ε * n / Real.log |(q n : ℝ)|) * Real.log |(q n : ℝ)|
        = F / H * Real.log |(q n : ℝ)| + ε * n := by
      field_simp
    rw [this]
    exact hln
  have hsmall : ε * n / Real.log |(q n : ℝ)| ≤ d / 2 := by
    rw [div_le_iff₀ hlogpos]
    have h1 : (H - ε) * n ≤ Real.log |(q n : ℝ)| := hqn
    have h2 : (0:ℝ) < H - ε := by linarith
    have h3 : ε * n ≤ d / 2 * ((H - ε) * n) := by
      have : ε ≤ d / 2 * (H - ε) := by nlinarith
      nlinarith
    nlinarith
  have hfinal : (H - F) / H - d / 2
      ≤ (-Real.log |α - (p n : ℝ) / (q n : ℝ)|) / Real.log |(q n : ℝ)| := by
    rw [quality_ratio_eq hq0 hℓ0 (ne_of_gt hlogpos)]
    have h1 : (H - F) / H = 1 - F / H := by field_simp
    rw [h1]
    linarith
  have : (c : ℝ) ≤ (-Real.log |α - (p n : ℝ) / (q n : ℝ)|) / Real.log |(q n : ℝ)| := by
    have : c = (H - F) / H - d := by simp only [hd]; ring
    rw [this]
    linarith
  exact_mod_cast this

/-- **The irrationality threshold** (the remark of Section "Scope" in the paper).  For a
rational number `α = a/b` every admissible approximation sequence has construction quality
at most `1`. -/
theorem quality_le_one_of_rational {α : ℝ} {a b : ℤ} (hb : 0 < b) (hα : α = (a : ℝ) / b)
    {q p : ℕ → ℤ} (h : AdmissibleApprox α q p) :
    constructionQuality α q p ≤ 1 := by
  have hbR : (0 : ℝ) < b := by exact_mod_cast hb
  -- the linear forms are bounded below
  have hform : ∀ᶠ n : ℕ in atTop, 1 / (b : ℝ) ≤ |(q n : ℝ) * α - p n| := by
    filter_upwards [h.1] with n ⟨hq, hl⟩
    have hid : (q n : ℝ) * α - p n = ((q n * a - p n * b : ℤ) : ℝ) / b := by
      rw [hα]
      field_simp
      push_cast
      ring
    have hne : (q n * a - p n * b : ℤ) ≠ 0 := by
      intro hcon
      apply hl
      rw [hid, hcon]
      simp
    have h1 : (1 : ℝ) ≤ |((q n * a - p n * b : ℤ) : ℝ)| := by
      have := Int.one_le_abs hne
      calc (1 : ℝ) ≤ ((|q n * a - p n * b| : ℤ) : ℝ) := by exact_mod_cast this
        _ = |((q n * a - p n * b : ℤ) : ℝ)| := by push_cast; rfl
    rw [hid, abs_div, abs_of_pos hbR]
    gcongr
  -- the heights tend to infinity
  have hlogq : Tendsto (fun n : ℕ => Real.log |(q n : ℝ)|) atTop atTop :=
    Real.tendsto_log_atTop.comp h.2
  refine EReal.le_of_forall_lt_iff_le.mp ?_
  intro z hz
  have hzR : (1 : ℝ) < z := by exact_mod_cast hz
  refine liminf_le_of_frequently_le ?_
  refine Filter.Eventually.frequently ?_
  have hbig : ∀ᶠ n : ℕ in atTop, max 1 (Real.log b / (z - 1)) ≤ Real.log |(q n : ℝ)| :=
    hlogq.eventually_ge_atTop _
  filter_upwards [h.1, hform, hbig] with n ⟨hq, hl⟩ hf hb'
  have hqR : (q n : ℝ) ≠ 0 := by exact_mod_cast hq
  have hlogpos : (0 : ℝ) < Real.log |(q n : ℝ)| :=
    lt_of_lt_of_le zero_lt_one (le_trans (le_max_left _ _) hb')
  have hlogb : Real.log b / (z - 1) ≤ Real.log |(q n : ℝ)| := le_trans (le_max_right _ _) hb'
  have hlow : -Real.log b ≤ Real.log |(q n : ℝ) * α - p n| := by
    have h1 := Real.log_le_log (by positivity) hf
    rw [Real.log_div (by norm_num) (ne_of_gt hbR), Real.log_one] at h1
    linarith
  have hratio : (-Real.log |α - (p n : ℝ) / (q n : ℝ)|) / Real.log |(q n : ℝ)| ≤ z := by
    rw [quality_ratio_eq hqR hl (ne_of_gt hlogpos)]
    have hstep : Real.log b ≤ (z - 1) * Real.log |(q n : ℝ)| := by
      rw [div_le_iff₀ (by linarith : (0 : ℝ) < z - 1)] at hlogb
      linarith
    have hdiv : -(z - 1) ≤ Real.log |(q n : ℝ) * α - p n| / Real.log |(q n : ℝ)| := by
      rw [le_div_iff₀ hlogpos]
      linarith
    linarith
  exact_mod_cast hratio

end CatalanLCM
