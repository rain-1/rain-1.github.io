import Mathlib

/-!
# The logarithmic rates of the two Catalan rows

This file introduces the constants of the paper
(`φ`, `T`, `T⁻`, `A₁`, `E₁`, `A₂`, `E₂`, `A_*` and `δ₀`) and establishes the elementary
inequalities between them which are used in the proof of the main theorem:

* `CatalanLCM.crossed_gap`  : `A₁ + E₂ < A₂ + E₁` (equation (γ) of the paper);
* `CatalanLCM.E_sum_gt`     : `24 < E₁ + E₂`;
* `CatalanLCM.A₂_sub_E₂_pos`: `0 < A₂ - E₂`;
* `CatalanLCM.Astar_pos`, `CatalanLCM.delta₀_lt_one`.
-/

namespace CatalanLCM

open Real

/-- The golden ratio `φ = (1+√5)/2`. -/
noncomputable def phi : ℝ := (1 + Real.sqrt 5) / 2

/-- `T = (3303 + 437√57)/144`, the larger root controlling the Nesterenko `(4,7)` row. -/
noncomputable def Tplus : ℝ := (3303 + 437 * Real.sqrt 57) / 144

/-- `T⁻ = (3303 - 437√57)/144`, the smaller root controlling the Nesterenko `(4,7)` row. -/
noncomputable def Tminus : ℝ := (3303 - 437 * Real.sqrt 57) / 144

/-- The growth rate of the (integer-normalized) Zudilin row. -/
noncomputable def A₁ : ℝ := 12 * Real.log 2 + 12 + 15 * Real.log phi

/-- The decay rate of the (integer-normalized) Zudilin linear form. -/
noncomputable def E₁ : ℝ := 12 * Real.log 2 + 12 - 15 * Real.log phi

/-- The growth rate of the (integer-normalized) Nesterenko `(4,7)` row. -/
noncomputable def A₂ : ℝ := 14 * Real.log 2 + 12 + 2 * Real.log Tplus

/-- The decay rate of the (integer-normalized) Nesterenko `(4,7)` linear form. -/
noncomputable def E₂ : ℝ := 14 * Real.log 2 + 12 + 2 * Real.log Tminus

/-- `A_* = A₂ - (12 + E₂ - E₁)/2`, the limiting height exponent of the selected row. -/
noncomputable def Astar : ℝ := A₂ - (12 + E₂ - E₁) / 2

/-- The construction quality `δ₀ = (A₂ - E₂)/A_*` proved in the main theorem. -/
noncomputable def delta₀ : ℝ := (A₂ - E₂) / Astar

section Numerics

lemma sqrt5_lt : Real.sqrt 5 < 56 / 25 := by
  rw [show (56:ℝ) / 25 = Real.sqrt ((56 / 25) ^ 2) from (Real.sqrt_sq (by norm_num)).symm]
  exact Real.sqrt_lt_sqrt (by norm_num) (by norm_num)

lemma sqrt57_lt : Real.sqrt 57 < 3303 / 437 := by
  nlinarith [Real.sq_sqrt (by norm_num : (57:ℝ) ≥ 0), Real.sqrt_nonneg 57]

lemma sqrt57_gt : (15 : ℝ) / 2 < Real.sqrt 57 := by
  nlinarith [Real.sq_sqrt (by norm_num : (57:ℝ) ≥ 0), Real.sqrt_nonneg 57]

lemma phi_pos : 0 < phi := by
  have := Real.sqrt_nonneg 5
  unfold phi; linarith

lemma phi_gt_one : 1 < phi := by
  have h : (2 : ℝ) ≤ Real.sqrt 5 := by
    have h4 : Real.sqrt 4 ≤ Real.sqrt 5 := Real.sqrt_le_sqrt (by norm_num)
    have h2 : Real.sqrt 4 = 2 := by
      rw [show (4:ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
    linarith [h4, h2.ge, h2.le]
  unfold phi
  linarith

lemma phi_lt : phi < 81 / 50 := by
  have h := sqrt5_lt
  unfold phi; linarith

lemma Tplus_pos : 0 < Tplus := by
  have := Real.sqrt_nonneg 57
  unfold Tplus; linarith

lemma Tminus_pos : 0 < Tminus := by
  have h := sqrt57_lt
  unfold Tminus
  have h2 : 437 * Real.sqrt 57 < 3303 := by linarith
  linarith

lemma Tplus_gt : (45 : ℝ) < Tplus := by
  have h := sqrt57_gt
  unfold Tplus
  nlinarith

lemma Tprod : Tplus * Tminus = 32 / 27 := by
  unfold Tplus Tminus
  have h : Real.sqrt 57 * Real.sqrt 57 = 57 := Real.mul_self_sqrt (by norm_num)
  field_simp
  nlinarith [h]

lemma Tminus_gt : (2 : ℝ) / 81 < Tminus := by
  have hp := Tplus_pos
  have hm := Tminus_pos
  have hprod := Tprod
  have hT : Tplus < 48 := by
    have h := sqrt57_lt
    unfold Tplus
    nlinarith
  nlinarith

lemma phi_pow_lt : phi ^ 15 < 1400 := by
  have h1 : phi ^ 15 ≤ (81 / 50 : ℝ) ^ 15 :=
    pow_le_pow_left₀ (le_of_lt phi_pos) (le_of_lt phi_lt) 15
  have h2 : ((81 : ℝ) / 50) ^ 15 < 1400 := by norm_num
  linarith

/-- The strict "crossed gap" `A₁ + E₂ < A₂ + E₁` of the paper. -/
theorem crossed_gap : A₁ + E₂ < A₂ + E₁ := by
  have hp := Tplus_pos
  have hm := Tminus_pos
  have hphi := phi_pos
  -- it suffices that `27 T² / 32 > φ ^ 15`
  have hkey : phi ^ 15 < 27 * Tplus ^ 2 / 32 := by
    have h1 : (45 : ℝ) < Tplus := Tplus_gt
    have h2 : phi ^ 15 < 1400 := phi_pow_lt
    nlinarith
  have hlog : 15 * Real.log phi < Real.log 27 + 2 * Real.log Tplus - Real.log 32 := by
    have h := Real.log_lt_log (by positivity) hkey
    rw [Real.log_pow, Real.log_div (by positivity) (by norm_num),
      Real.log_mul (by norm_num) (by positivity), Real.log_pow] at h
    push_cast at h
    linarith
  have hTm : Tminus = 32 / (27 * Tplus) := by
    field_simp
    linear_combination 27 * Tprod
  have hlogTm : Real.log Tminus = Real.log 32 - Real.log 27 - Real.log Tplus := by
    rw [hTm, Real.log_div (by norm_num) (by positivity),
      Real.log_mul (by norm_num) (by positivity)]
    ring
  unfold A₁ A₂ E₁ E₂
  linarith

/-- `24 < E₁ + E₂`; in particular the quantity `F = (E₁+E₂)/2 - 6` of the construction is
positive. -/
theorem E_sum_gt : 24 < E₁ + E₂ := by
  have hm := Tminus_pos
  have hphi := phi_pos
  -- `2^26 (T⁻)^2 > φ^15`
  have hkey : phi ^ 15 < 2 ^ 26 * Tminus ^ 2 := by
    have h1 : (2 : ℝ) / 81 < Tminus := Tminus_gt
    have h2 : phi ^ 15 < 1400 := phi_pow_lt
    nlinarith
  have hlog : 15 * Real.log phi < Real.log (2 ^ 26 * Tminus ^ 2) := by
    have := Real.log_lt_log (by positivity) hkey
    rwa [Real.log_pow] at this
  have hsplit : Real.log ((2:ℝ) ^ 26 * Tminus ^ 2) = 26 * Real.log 2 + 2 * Real.log Tminus := by
    rw [Real.log_mul (by positivity) (by positivity), Real.log_pow, Real.log_pow]
    push_cast
    ring
  rw [hsplit] at hlog
  unfold E₁ E₂
  linarith

lemma Tminus_lt_one : Tminus < 1 := by
  have h1 : (45 : ℝ) < Tplus := Tplus_gt
  have h2 : Tplus * Tminus = 32 / 27 := Tprod
  have h3 : 0 < Tminus := Tminus_pos
  nlinarith

/-- `0 < A₂`. -/
theorem A₂_pos : 0 < A₂ := by
  have h1 : (0 : ℝ) < Real.log Tplus := Real.log_pos (by linarith [Tplus_gt])
  have h2 : (0 : ℝ) < Real.log 2 := Real.log_pos (by norm_num)
  unfold A₂
  linarith

/-- `0 < E₁`: the (rescaled) Zudilin linear form still grows. -/
theorem E₁_pos : 0 < E₁ := by
  have h1 : 15 * Real.log phi < Real.log 1400 := by
    have h := Real.log_lt_log (pow_pos phi_pos 15) phi_pow_lt
    rw [Real.log_pow] at h
    push_cast at h
    linarith
  have h2 : Real.log 1400 < 11 * Real.log 2 := by
    have h := Real.log_lt_log (by norm_num : (0:ℝ) < 1400) (by norm_num : (1400:ℝ) < 2 ^ 11)
    rw [Real.log_pow] at h
    push_cast at h
    linarith
  have h3 : (0 : ℝ) < Real.log 2 := Real.log_pos (by norm_num)
  unfold E₁
  linarith

/-- `0 < A₂ - E₂ = 2 log(T/T⁻)`. -/
theorem A₂_sub_E₂_pos : 0 < A₂ - E₂ := by
  have h : Real.log Tminus < Real.log Tplus := by
    refine Real.log_lt_log Tminus_pos ?_
    have h1 := sqrt57_gt
    unfold Tplus Tminus
    nlinarith
  unfold A₂ E₂
  linarith

/-- `A_*` is positive. -/
theorem Astar_pos : 0 < Astar := by
  have h1 : 24 < E₁ + E₂ := E_sum_gt
  have h2 : 0 < A₂ - E₂ := A₂_sub_E₂_pos
  unfold Astar
  linarith

/-- The quantity `F = (E₁+E₂)/2 - 6` of the construction, i.e. `A_* - (A₂ - E₂)`,
is positive; equivalently `δ₀ < 1`. -/
theorem Astar_sub_pos : 0 < Astar - (A₂ - E₂) := by
  have h1 : 24 < E₁ + E₂ := E_sum_gt
  unfold Astar
  linarith

/-- `δ₀ < 1`: the construction quality proved here stays below the irrationality
threshold. -/
theorem delta₀_lt_one : delta₀ < 1 := by
  have h1 : 0 < Astar := Astar_pos
  have h2 : 0 < Astar - (A₂ - E₂) := Astar_sub_pos
  unfold delta₀
  rw [div_lt_one h1]
  linarith

/-- `0 < δ₀`. -/
theorem delta₀_pos : 0 < delta₀ := div_pos A₂_sub_E₂_pos Astar_pos

end Numerics

end CatalanLCM
