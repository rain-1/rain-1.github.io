import RequestProject.Geometry
import RequestProject.Quality

/-!
# The two-row selection theorem

This is the abstract heart of the paper (Section "A two-successive-minima selection
theorem").  Two integer rows `(Xₙ, Yₙ)` and `(Vₙ, Uₙ)` approximating a real number `α`
are given, together with a positive integer modulus `Sₙ` dividing both first coordinates
`Xₙ` and `Vₙ`.  Integer combinations of the two rows which are divisible by `Sₙ` in the
second coordinate as well produce genuine integer pairs

`qₙ = (c₁Xₙ + c₂Vₙ)/Sₙ`,  `pₙ = (c₁Yₙ + c₂Uₙ)/Sₙ`.

The theorem asserts that, with the six logarithmic rates of the paper and the crossed
gap `A₁ + E₂ < A₂ + E₁`, one can choose the combinations so that the resulting sequence
is admissible with construction quality at least `(A₂ - E₂)/(A₂ - (s + E₂ - E₁)/2)`.

Instead of the maximal congruence lattice used in the paper (of index `dₙ ≤ Sₙ`), we work
throughout with the explicit index-`Sₙ` sublattice spanned by `(e, z)` and `(0, Sₙ/e)`,
where `e = gcd(Uₙ, Sₙ)`.  This is exactly the worst case `κₙ = sₙ` of the paper, and it is
the case which produces the stated constant.  The geometry-of-numbers input is
`CatalanLCM.selection_nondeg` and `CatalanLCM.selection_deg` from `Geometry.lean`.
-/

namespace CatalanLCM

open Filter Real
open scoped Topology

/-- Bézout data for `gcd(U, S)`: a common divisor `e` of `U` and `S` whose cofactors are
coprime. -/
lemma exists_bezout_split {U S : ℤ} (hS : 0 < S) :
    ∃ e u' s' u w : ℤ, 0 < e ∧ U = e * u' ∧ S = e * s' ∧ (1 : ℤ) = u' * u + s' * w := by
  have hepos : (0 : ℤ) < (Int.gcd U S : ℤ) := by
    have h1 : Int.gcd U S ≠ 0 := by
      simp only [ne_eq, Int.gcd_eq_zero_iff, not_and]
      intro _
      exact hS.ne'
    exact_mod_cast Nat.pos_of_ne_zero h1
  obtain ⟨u', hu'⟩ : (Int.gcd U S : ℤ) ∣ U := Int.gcd_dvd_left U S
  obtain ⟨s', hs'⟩ : (Int.gcd U S : ℤ) ∣ S := Int.gcd_dvd_right U S
  refine ⟨(Int.gcd U S : ℤ), u', s', Int.gcdA U S, Int.gcdB U S, hepos, hu', hs', ?_⟩
  refine mul_left_cancel₀ hepos.ne' ?_
  linear_combination (Int.gcd_eq_gcd_ab U S) + Int.gcdA U S * hu' + Int.gcdB U S * hs'

/-- **The divided lattice.**  If the positive integer `S` divides `X` and `V`, then there
is a rank-two integer lattice of "divided rows" `(Q, P)` whose determinant is
`-(XU - VY)/S`; that is, there are integer vectors `(Q₁,P₁)`, `(Q₂,P₂)` with
`S (Q₂P₁ - Q₁P₂) = -(XU - VY)`.

Explicitly these are the images of `(e, z)` and `(0, S/e)` with `e = gcd(U,S)`. -/
lemma exists_divided_rows {X Y V U S : ℤ} (hS : 0 < S) (hSX : S ∣ X) (hSV : S ∣ V) :
    ∃ Q₁ Q₂ P₁ P₂ : ℤ, S * (Q₂ * P₁ - Q₁ * P₂) = -(X * U - V * Y) := by
  obtain ⟨x, hx⟩ := hSX
  obtain ⟨v, hv⟩ := hSV
  obtain ⟨e, u', s', u, w, hepos, hu', hs', hone⟩ := exists_bezout_split (U := U) hS
  exact ⟨e * x - u * Y * v, s' * v, Y * w, u',
    by linear_combination U * hx - Y * hv + (S * x) * hu' - (S * v * Y) * hone⟩

/-- The outcome of the selection step at a single index: a pair `(q, p)` with nonzero
linear form which is either of essentially maximal height (`|q| ≥ D/(2E)` with linear
form at most `E`), or of height at least `M` with linear form at most the lattice
determinant `D`. -/
def GoodPair (α : ℝ) (D E M : ℝ) (c : ℤ × ℤ) : Prop :=
  ((c.1 : ℝ) * α - c.2 ≠ 0) ∧
    ((D / (2 * E) ≤ |(c.1 : ℝ)| ∧ |(c.1 : ℝ) * α - c.2| ≤ E) ∨
      (M ≤ |(c.1 : ℝ)| ∧ |(c.1 : ℝ) * α - c.2| ≤ D))

/-- Choice of a sequence of pairs from an eventual existence statement. -/
lemma exists_seq_of_eventually {P : ℕ → ℤ × ℤ → Prop} (h : ∀ᶠ n in atTop, ∃ c, P n c) :
    ∃ q p : ℕ → ℤ, ∀ᶠ n in atTop, P n (q n, p n) := by
  classical
  refine ⟨fun n => if hn : ∃ c : ℤ × ℤ, P n c then (hn.choose).1 else 1,
          fun n => if hn : ∃ c : ℤ × ℤ, P n c then (hn.choose).2 else 0, ?_⟩
  filter_upwards [h] with n hn
  simp only [dif_pos hn]
  simpa using hn.choose_spec

/-- **The selection step, for a single index.** -/
theorem exists_good_pair (α : ℝ) {X Y V U S : ℤ} (hS : 0 < S) (hSX : S ∣ X) (hSV : S ∣ V)
    (hD : X * U - V * Y ≠ 0) {Eb : ℝ} (hEb : 0 < Eb) (M : ℝ) :
    ∃ c : ℤ × ℤ,
      GoodPair α (|((X * U - V * Y : ℤ) : ℝ)| / (S : ℝ)) Eb M c := by
  obtain ⟨Q₁, Q₂, P₁, P₂, hdetid⟩ := exists_divided_rows hS hSX hSV
  set L₁ : ℝ := (Q₁ : ℝ) * α - P₁ with hL₁
  set L₂ : ℝ := (Q₂ : ℝ) * α - P₂ with hL₂
  have hSR : (0 : ℝ) < S := by exact_mod_cast hS
  have hDR : ((X * U - V * Y : ℤ) : ℝ) ≠ 0 := Int.cast_ne_zero.2 hD
  have hlat : latdet Q₁ Q₂ L₁ L₂ = -(((X * U - V * Y : ℤ) : ℝ)) / S := by
    have hcast : (S : ℝ) * ((Q₂ : ℝ) * P₁ - (Q₁ : ℝ) * P₂) = -(((X * U - V * Y : ℤ) : ℝ)) := by
      exact_mod_cast congrArg (fun z : ℤ => (z : ℝ)) hdetid
    simp only [latdet, hL₁, hL₂]
    field_simp
    linarith [hcast]
  have hdetne : latdet Q₁ Q₂ L₁ L₂ ≠ 0 := by
    rw [hlat]
    exact div_ne_zero (neg_ne_zero.2 hDR) hSR.ne'
  have hlatabs : |latdet Q₁ Q₂ L₁ L₂| = |((X * U - V * Y : ℤ) : ℝ)| / (S : ℝ) := by
    rw [hlat, abs_div, abs_neg, abs_of_pos hSR]
  have key2 : ∀ a b : ℤ, ((qcoord Q₁ Q₂ a b : ℤ) : ℝ) * α - ((a * P₁ + b * P₂ : ℤ) : ℝ)
      = lcoord L₁ L₂ a b := by
    intro a b
    simp only [qcoord, lcoord, hL₁, hL₂]
    push_cast
    ring
  by_cases hnd : ∀ a b : ℤ, lcoord L₁ L₂ a b = 0 → a = 0 ∧ b = 0
  · -- nondegenerate case
    have hQpos : 0 < |((X * U - V * Y : ℤ) : ℝ)| / (S : ℝ) / Eb := by
      have : 0 < |((X * U - V * Y : ℤ) : ℝ)| := abs_pos.2 hDR
      positivity
    have hQE : (|((X * U - V * Y : ℤ) : ℝ)| / (S : ℝ) / Eb) * Eb = |latdet Q₁ Q₂ L₁ L₂| := by
      rw [hlatabs]
      field_simp
    obtain ⟨a, b, hl, hq, hle⟩ := selection_nondeg hQpos hEb hdetne hQE hnd
    refine ⟨(qcoord Q₁ Q₂ a b, a * P₁ + b * P₂), ?_, Or.inl ⟨?_, ?_⟩⟩
    · rw [key2 a b]; exact hl
    · refine le_trans (le_of_eq ?_) hq
      field_simp
    · rw [key2 a b]; exact hle
  · -- degenerate case
    push_neg at hnd
    obtain ⟨a₀, b₀, hl₀, hne₀⟩ := hnd
    have h0 : ¬(a₀ = 0 ∧ b₀ = 0) := fun h => hne₀ h.1 h.2
    obtain ⟨a, b, hl, hle, hq⟩ := selection_deg hdetne h0 hl₀ M
    refine ⟨(qcoord Q₁ Q₂ a b, a * P₁ + b * P₂), ?_, Or.inr ⟨hq, ?_⟩⟩
    · rw [key2 a b]; exact hl
    · rw [key2 a b, ← hlatabs]; exact hle

/-- **Two-minimum selection theorem.**  Under the six logarithmic rates of the paper and
the crossed gap `A₁ + E₂ < A₂ + E₁`, the divided rows contain an admissible approximation
sequence of construction quality at least `(A₂ - E₂)/(A₂ - (s + E₂ - E₁)/2)`.

Here `s` is the logarithmic mass of the modulus `Sₙ`; the hypothesis `0 < (E₁+E₂-s)/2`
is the positivity of the paper's `Fₙ` in the worst case `κₙ = sₙ`, and `E₂ < A₂` is the
positivity of `Hₙ - Fₙ`. -/
theorem selection {α : ℝ} {X Y V U S : ℕ → ℤ} {A₁ E₁ A₂ E₂ s : ℝ}
    (hS : ∀ n, 0 < S n) (hSX : ∀ n, S n ∣ X n) (hSV : ∀ n, S n ∣ V n)
    (hX : LogRate (fun n => (X n : ℝ)) A₁)
    (hV : LogRate (fun n => (V n : ℝ)) A₂)
    (hΛ₁ : LogRate (fun n => (X n : ℝ) * α - Y n) E₁)
    (hΛ₂ : LogRate (fun n => (V n : ℝ) * α - U n) E₂)
    (hSr : LogRate (fun n => (S n : ℝ)) s)
    (hA₂0 : A₂ ≠ 0) (hE₁0 : E₁ ≠ 0)
    (hgap : A₁ + E₂ < A₂ + E₁)
    (hFpos : 0 < (E₁ + E₂ - s) / 2)
    (hAE : E₂ < A₂) :
    ∃ q p : ℕ → ℤ, AdmissibleApprox α q p ∧
      (((A₂ - E₂) / (A₂ - (s + E₂ - E₁) / 2) : ℝ) : EReal) ≤ constructionQuality α q p := by
  classical
  -- the logarithmic mass of the modulus is nonnegative
  have hs0 : 0 ≤ s := by
    refine ge_of_tendsto hSr ?_
    filter_upwards [eventually_gt_atTop 0] with n hn0
    have hSpos : (1 : ℝ) ≤ (S n : ℝ) := by exact_mod_cast hS n
    have hnpos : (0 : ℝ) < n := by exact_mod_cast hn0
    have hlog : 0 ≤ Real.log |(S n : ℝ)| := by
      rw [abs_of_pos (by linarith)]
      exact Real.log_nonneg hSpos
    positivity
  -- rate of the row determinant
  have hV0 : ∀ᶠ n in atTop, (V n : ℝ) ≠ 0 := hV.eventually_ne_zero hA₂0
  have hΛ₁0 : ∀ᶠ n in atTop, ((X n : ℝ) * α - Y n) ≠ 0 := hΛ₁.eventually_ne_zero hE₁0
  have hprod0 : ∀ᶠ n in atTop, ((V n : ℝ) * ((X n : ℝ) * α - Y n)) ≠ 0 := by
    filter_upwards [hV0, hΛ₁0] with n h1 h2
    exact mul_ne_zero h1 h2
  have hDrate : LogRate (fun n => ((X n * U n - V n * Y n : ℤ) : ℝ)) (A₂ + E₁) := by
    have h1 : LogRate (fun n => (V n : ℝ) * ((X n : ℝ) * α - Y n)) (A₂ + E₁) :=
      hV.mul hΛ₁ hV0 hΛ₁0
    have h2 := h1.sub_of_le (b := fun n => (X n : ℝ) * ((V n : ℝ) * α - U n))
      (fun ε hε => hX.mul_le hΛ₂ hε) hgap hprod0
    have hfun : (fun n => ((X n * U n - V n * Y n : ℤ) : ℝ))
        = fun n => (V n : ℝ) * ((X n : ℝ) * α - Y n) - (X n : ℝ) * ((V n : ℝ) * α - U n) := by
      funext n
      push_cast
      ring
    rw [hfun]
    exact h2
  have hA₂E₁ : A₂ + E₁ ≠ 0 := by
    have hpos : 0 < A₂ + E₁ := by
      have h1 : s < E₁ + E₂ := by linarith
      linarith
    exact hpos.ne'
  have hD0R : ∀ᶠ n in atTop, ((X n * U n - V n * Y n : ℤ) : ℝ) ≠ 0 :=
    hDrate.eventually_ne_zero hA₂E₁
  have hD0 : ∀ᶠ n in atTop, X n * U n - V n * Y n ≠ 0 := by
    filter_upwards [hD0R] with n hn
    exact_mod_cast hn
  -- the two rate constants
  obtain ⟨F, hFdef⟩ : ∃ F : ℝ, F = (E₁ + E₂ - s) / 2 := ⟨_, rfl⟩
  obtain ⟨H, hHdef⟩ : ∃ H : ℝ, H = F + (A₂ - E₂) := ⟨_, rfl⟩
  have hFp : 0 < F := by rw [hFdef]; exact hFpos
  have hHF : F < H := by rw [hHdef]; linarith
  have hHp : 0 < H := lt_trans hFp hHF
  have hHFsum : H + F = A₂ + E₁ - s := by rw [hHdef, hFdef]; ring
  obtain ⟨C, hCdef⟩ : ∃ C : ℝ, C = H * (H + F + 1) / F + 1 := ⟨_, rfl⟩
  have hCH : H ≤ C := by
    have h1 : H ≤ H * (H + F + 1) / F := by
      rw [le_div_iff₀ hFp]
      nlinarith
    rw [hCdef]
    linarith
  have hCbig : H + F + 1 ≤ F / H * C := by
    have h1 : F / H * (H * (H + F + 1) / F) = H + F + 1 := by field_simp
    have h2 : 0 < F / H := div_pos hFp hHp
    rw [hCdef]
    nlinarith
  -- two-sided bounds for the lattice determinant `|𝒟ₙ|/Sₙ`
  have hSne : ∀ᶠ n in atTop, (S n : ℝ) ≠ 0 := by
    filter_upwards with n
    have : (0 : ℝ) < S n := by exact_mod_cast hS n
    exact this.ne'
  have hDrlow : ∀ ε : ℝ, 0 < ε → ∀ᶠ n : ℕ in atTop,
      Real.exp ((H + F - ε) * n) ≤ |((X n * U n - V n * Y n : ℤ) : ℝ)| / (S n : ℝ) := by
    intro ε hε
    filter_upwards [hDrate.eventually_ge hD0R (half_pos hε), hSr.eventually_le (half_pos hε)]
      with n hn1 hn2
    have hSpos : (0 : ℝ) < S n := by exact_mod_cast hS n
    rw [abs_of_pos hSpos] at hn2
    rw [le_div_iff₀ hSpos]
    calc Real.exp ((H + F - ε) * n) * (S n : ℝ)
        ≤ Real.exp ((H + F - ε) * n) * Real.exp ((s + ε / 2) * n) := by gcongr
      _ = Real.exp ((A₂ + E₁ - ε / 2) * n) := by
          rw [← Real.exp_add]
          congr 1
          linear_combination (n : ℝ) * hHFsum
      _ ≤ |((X n * U n - V n * Y n : ℤ) : ℝ)| := hn1
  have hDrhigh : ∀ ε : ℝ, 0 < ε → ∀ᶠ n : ℕ in atTop,
      |((X n * U n - V n * Y n : ℤ) : ℝ)| / (S n : ℝ) ≤ Real.exp ((H + F + ε) * n) := by
    intro ε hε
    filter_upwards [hDrate.eventually_le (half_pos hε), hSr.eventually_ge hSne (half_pos hε)]
      with n hn1 hn2
    have hSpos : (0 : ℝ) < S n := by exact_mod_cast hS n
    rw [abs_of_pos hSpos] at hn2
    rw [div_le_iff₀ hSpos]
    calc |((X n * U n - V n * Y n : ℤ) : ℝ)| ≤ Real.exp ((A₂ + E₁ + ε / 2) * n) := hn1
      _ = Real.exp ((H + F + ε) * n) * Real.exp ((s - ε / 2) * n) := by
          rw [← Real.exp_add]
          congr 1
          linear_combination (-(n : ℝ)) * hHFsum
      _ ≤ Real.exp ((H + F + ε) * n) * (S n : ℝ) := by gcongr
  -- the selected pairs
  have hex : ∀ᶠ n : ℕ in atTop, ∃ c : ℤ × ℤ,
      GoodPair α (|((X n * U n - V n * Y n : ℤ) : ℝ)| / (S n : ℝ))
        (Real.exp (F * n)) (Real.exp (C * n)) c := by
    filter_upwards [hD0] with n hn
    exact exists_good_pair α (hS n) (hSX n) (hSV n) hn (Real.exp_pos _) (Real.exp (C * n))
  obtain ⟨q, p, hgood⟩ := exists_seq_of_eventually hex
  -- the main estimates
  have hmain : ∀ ε : ℝ, 0 < ε → ∀ᶠ n : ℕ in atTop,
      (H - ε) * n ≤ Real.log |(q n : ℝ)| ∧
        Real.log |(q n : ℝ) * α - p n| ≤ F / H * Real.log |(q n : ℝ)| + ε * n := by
    intro ε hε
    have hfh : 0 < F / H := div_pos hFp hHp
    obtain ⟨ε', hε'def⟩ : ∃ e : ℝ, e = min (ε / 2) (ε * H / (2 * F)) := ⟨_, rfl⟩
    have hε'pos : 0 < ε' := by
      rw [hε'def]
      exact lt_min (by linarith) (by positivity)
    have hε'1 : ε' ≤ ε / 2 := by rw [hε'def]; exact min_le_left _ _
    have hkey1 : F / H * ε' ≤ ε / 2 := by
      have h2 : ε' ≤ ε * H / (2 * F) := by rw [hε'def]; exact min_le_right _ _
      calc F / H * ε' ≤ F / H * (ε * H / (2 * F)) := by gcongr
        _ = ε / 2 := by field_simp
    have hlog2 : ∀ᶠ n : ℕ in atTop, Real.log 2 * (1 + F / H) ≤ ε / 2 * n := by
      have htend : Tendsto (fun n : ℕ => ε / 2 * n) atTop atTop :=
        Filter.Tendsto.const_mul_atTop (by linarith) tendsto_natCast_atTop_atTop
      exact htend.eventually_ge_atTop _
    filter_upwards [hgood, hDrlow ε' hε'pos, hDrhigh 1 one_pos, hlog2,
      eventually_gt_atTop 0] with n hg hlo hhi hl2 hn0
    have hnpos : (0 : ℝ) < n := by exact_mod_cast hn0
    have hlog2pos : (0 : ℝ) < Real.log 2 := Real.log_pos (by norm_num)
    obtain ⟨hℓne, hcase⟩ := hg
    have hℓpos : (0 : ℝ) < |(q n : ℝ) * α - p n| := abs_pos.2 hℓne
    rcases hcase with ⟨hq1, hl1⟩ | ⟨hq2, hl2⟩
    · -- essentially maximal height
      have hstep : Real.exp ((H - ε') * n) / 2
          = Real.exp ((H + F - ε') * n) / (2 * Real.exp (F * n)) := by
        rw [eq_div_iff (by positivity)]
        field_simp
        rw [← Real.exp_add]
        congr 1
        ring
      have hqge : Real.exp ((H - ε') * n) / 2 ≤ |(q n : ℝ)| := by
        rw [hstep]
        refine le_trans ?_ hq1
        gcongr
      have hqpos : (0 : ℝ) < |(q n : ℝ)| := lt_of_lt_of_le (by positivity) hqge
      have hlogq : (H - ε') * n - Real.log 2 ≤ Real.log |(q n : ℝ)| := by
        have h := Real.log_le_log (by positivity) hqge
        rw [Real.log_div (Real.exp_ne_zero _) (by norm_num), Real.log_exp] at h
        linarith
      have hlogl : Real.log |(q n : ℝ) * α - p n| ≤ F * n := by
        have h := Real.log_le_log hℓpos hl1
        rwa [Real.log_exp] at h
      have hlog2n : Real.log 2 ≤ ε / 2 * n := by
        have hp : 0 ≤ F / H * Real.log 2 := by positivity
        have hexpand : Real.log 2 * (1 + F / H) = Real.log 2 + F / H * Real.log 2 := by ring
        linarith
      have hεn : ε' * n ≤ ε / 2 * n := mul_le_mul_of_nonneg_right hε'1 hnpos.le
      refine ⟨by nlinarith [hεn, hlog2n, hlogq], ?_⟩
      have h1 : F / H * ((H - ε') * n - Real.log 2) ≤ F / H * Real.log |(q n : ℝ)| := by
        gcongr
      have h2 : F / H * ((H - ε') * n - Real.log 2)
          = F * n - F / H * ε' * n - F / H * Real.log 2 := by
        field_simp
      have h3 : F / H * ε' * n ≤ ε / 2 * n := by
        have := mul_le_mul_of_nonneg_right hkey1 (le_of_lt hnpos)
        linarith
      have h4 : F / H * Real.log 2 ≤ ε / 2 * n := by
        have hp : 0 ≤ Real.log 2 := hlog2pos.le
        have hexpand : Real.log 2 * (1 + F / H) = Real.log 2 + F / H * Real.log 2 := by ring
        linarith
      linarith
    · -- huge height
      have hlogq : C * n ≤ Real.log |(q n : ℝ)| := by
        have h := Real.log_le_log (Real.exp_pos _) hq2
        rwa [Real.log_exp] at h
      have hlogl : Real.log |(q n : ℝ) * α - p n| ≤ (H + F + 1) * n := by
        have h := Real.log_le_log hℓpos (le_trans hl2 hhi)
        rwa [Real.log_exp] at h
      have hHC : H * n ≤ C * n := mul_le_mul_of_nonneg_right hCH hnpos.le
      have hεn0 : 0 ≤ ε * n := by positivity
      refine ⟨by nlinarith [hHC, hεn0, hlogq], ?_⟩
      have h1 : (H + F + 1) * n ≤ F / H * C * n := by
        have := mul_le_mul_of_nonneg_right hCbig (le_of_lt hnpos)
        linarith
      have h2 : F / H * (C * n) ≤ F / H * Real.log |(q n : ℝ)| := by
        gcongr
      linarith [hεn0]
  -- conclusion
  refine ⟨q, p, ?_⟩
  have hfinal := quality_of_bounds (α := α) (q := q) (p := p) (H := H) (F := F) hFp hHF
    (fun ε hε => (hmain ε hε).mono fun n h => h.1)
    (hgood.mono fun n h => h.1)
    (fun ε hε => (hmain ε hε).mono fun n h => h.2)
  refine ⟨hfinal.1, ?_⟩
  have h1 : H - F = A₂ - E₂ := by rw [hHdef]; ring
  have h2 : H = A₂ - (s + E₂ - E₁) / 2 := by rw [hHdef, hFdef]; ring
  rw [← h1, ← h2]
  exact hfinal.2

end CatalanLCM
