import RequestProject.Arithmetic
import RequestProject.Rates
import RequestProject.Selection

/-!
# Combining two Apéry-like constructions for Catalan's constant

This file assembles the main theorem of the paper: the Zudilin row at index `3n` and
Nesterenko's `(4,7)` row have a *common* factor `D_{6n}²` in their first coordinates, and
after removing it a two-dimensional lattice selection produces an admissible approximation
sequence for Catalan's constant `G` of construction quality at least

`δ₀ = (A₂ - E₂)/A_* = 0.65887…`.

The inputs which are quoted from the literature (Zudilin's and Nesterenko's integrality
statements and asymptotics, and the prime number theorem in the form
`log D_m = m + o(m)`) appear as explicit hypotheses of `CatalanLCM.catalan_two_row_full_lcm`;
everything else — Lemma 4.1, Proposition 4.2 (the full LCM-square), the rate bookkeeping,
the selection theorem and the final quality bound — is proved here.
-/

namespace CatalanLCM

open Filter Real
open scoped Topology

/-- Catalan's constant `G = ∑ (-1)^k/(2k+1)²`. -/
noncomputable def Catalan : ℝ := ∑' k : ℕ, (-1 : ℝ) ^ k / (2 * k + 1) ^ 2

/-- The exponent `e_m = min{6m, 4m+3+⌊log₂(2m-1)⌋}` of Lemma 3.1. -/
def ezud (m : ℕ) : ℕ := min (6 * m) (4 * m + 3 + Nat.log 2 (2 * m - 1))

lemma tendsto_log_div_nat : Tendsto (fun n : ℕ => Real.log n / n) atTop (𝓝 0) := by
  have h : Tendsto (fun x : ℝ => Real.log x ^ 1 / (1 * x + 0)) atTop (𝓝 0) :=
    Real.tendsto_pow_log_div_mul_add_atTop 1 0 1 one_ne_zero
  have := h.comp tendsto_natCast_atTop_atTop
  simpa using this

/-- `⌊log₂(2m-1)⌋ = o(m)`. -/
lemma tendsto_natLog_div : Tendsto (fun m : ℕ => (Nat.log 2 (2 * m - 1) : ℝ) / m) atTop (𝓝 0) := by
  have hlog2 : (0 : ℝ) < Real.log 2 := Real.log_pos (by norm_num)
  have hupper : Tendsto
      (fun m : ℕ => 1 / (m : ℝ) + Real.log m / m / Real.log 2) atTop (𝓝 0) := by
    have h1 : Tendsto (fun m : ℕ => 1 / (m : ℝ)) atTop (𝓝 0) :=
      tendsto_one_div_atTop_nhds_zero_nat
    have h2 : Tendsto (fun m : ℕ => Real.log m / m / Real.log 2) atTop (𝓝 0) := by
      have := tendsto_log_div_nat.div_const (Real.log 2)
      simpa using this
    simpa using h1.add h2
  refine squeeze_zero' (Eventually.of_forall fun m => by positivity) ?_ hupper
  filter_upwards [eventually_gt_atTop 0] with m hm
  have hmpos : (0 : ℝ) < m := by exact_mod_cast hm
  have hne : 2 * m - 1 ≠ 0 := by omega
  have hpow : (2 : ℕ) ^ Nat.log 2 (2 * m - 1) ≤ 2 * m - 1 := Nat.pow_log_le_self 2 hne
  have hpowR : (2 : ℝ) ^ Nat.log 2 (2 * m - 1) ≤ 2 * m := by
    have h1 : (2 : ℝ) ^ Nat.log 2 (2 * m - 1) ≤ ((2 * m - 1 : ℕ) : ℝ) := by
      exact_mod_cast hpow
    have h2 : ((2 * m - 1 : ℕ) : ℝ) ≤ 2 * m := by
      have h3 : (2 * m - 1 : ℕ) ≤ 2 * m := by omega
      calc ((2 * m - 1 : ℕ) : ℝ) ≤ ((2 * m : ℕ) : ℝ) := by exact_mod_cast h3
        _ = 2 * m := by push_cast; ring
    linarith
  have hlogle : (Nat.log 2 (2 * m - 1) : ℝ) * Real.log 2 ≤ Real.log 2 + Real.log m := by
    have h := Real.log_le_log (by positivity) hpowR
    rw [Real.log_pow, Real.log_mul (by norm_num) (by positivity)] at h
    linarith
  rw [div_le_iff₀ hmpos]
  have hstep : (Nat.log 2 (2 * m - 1) : ℝ) ≤ (Real.log 2 + Real.log m) / Real.log 2 := by
    rw [le_div_iff₀ hlog2]
    linarith
  calc (Nat.log 2 (2 * m - 1) : ℝ) ≤ (Real.log 2 + Real.log m) / Real.log 2 := hstep
    _ = (1 / (m : ℝ) + Real.log m / m / Real.log 2) * m := by
        field_simp

/-- `e_m = 4m + o(m)`, the last assertion of Lemma 3.1. -/
theorem ezud_tendsto : Tendsto (fun m : ℕ => (ezud m : ℝ) / m) atTop (𝓝 4) := by
  have hupper : Tendsto (fun m : ℕ => 4 + (3 / (m : ℝ) + (Nat.log 2 (2 * m - 1) : ℝ) / m))
      atTop (𝓝 4) := by
    have h1 : Tendsto (fun m : ℕ => 3 / (m : ℝ)) atTop (𝓝 0) := by
      have := tendsto_one_div_atTop_nhds_zero_nat.const_mul (3 : ℝ)
      simpa using this
    have := (h1.add tendsto_natLog_div).const_add (4 : ℝ)
    simpa using this
  refine tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds hupper ?_ ?_
  · filter_upwards [eventually_gt_atTop 0] with m hm
    have hmpos : (0 : ℝ) < m := by exact_mod_cast hm
    rw [le_div_iff₀ hmpos]
    have h1 : 4 * m ≤ ezud m := by
      simp only [ezud, le_min_iff]
      omega
    calc (4 : ℝ) * m = ((4 * m : ℕ) : ℝ) := by push_cast; ring
      _ ≤ (ezud m : ℝ) := by exact_mod_cast h1
  · filter_upwards [eventually_gt_atTop 0] with m hm
    have hmpos : (0 : ℝ) < m := by exact_mod_cast hm
    rw [div_le_iff₀ hmpos]
    have h1 : ezud m ≤ 4 * m + 3 + Nat.log 2 (2 * m - 1) := min_le_right _ _
    have h2 : (ezud m : ℝ) ≤ 4 * m + 3 + (Nat.log 2 (2 * m - 1) : ℝ) := by
      calc (ezud m : ℝ) ≤ ((4 * m + 3 + Nat.log 2 (2 * m - 1) : ℕ) : ℝ) := by exact_mod_cast h1
        _ = 4 * m + 3 + (Nat.log 2 (2 * m - 1) : ℝ) := by push_cast; ring
    have h3 : (4 + (3 / (m : ℝ) + (Nat.log 2 (2 * m - 1) : ℝ) / m)) * m
        = 4 * m + 3 + (Nat.log 2 (2 * m - 1) : ℝ) := by
      field_simp
      ring
    linarith [h2, h3.ge]

/-- A convenient elementary limit: `(a n + b)/n → a`. -/
lemma tendsto_linear_div (a b : ℕ) :
    Tendsto (fun n : ℕ => ((a * n + b : ℕ) : ℝ) / n) atTop (𝓝 a) := by
  have h : Tendsto (fun n : ℕ => (a : ℝ) + (b : ℝ) * (1 / n)) atTop (𝓝 ((a : ℝ) + b * 0)) :=
    tendsto_const_nhds.add (tendsto_one_div_atTop_nhds_zero_nat.const_mul _)
  rw [mul_zero, add_zero] at h
  refine h.congr' ?_
  filter_upwards [eventually_gt_atTop 0] with n hn
  have hnpos : (0 : ℝ) < n := by exact_mod_cast hn
  push_cast
  field_simp

/-- **Proposition 4.2, Zudilin part.**  `D_{6n}²` divides the first coordinate of the
Zudilin row at index `3n`. -/
theorem lcm_square_dvd_zudilin {n : ℕ} {Q : ℚ} {z X : ℤ} (e : ℕ)
    (hz : (2 : ℚ) ^ e * Q = z)
    (hX : (X : ℚ) = 2 ^ e * (Dlcm (6 * n - 1) : ℚ) ^ 2 * Q) :
    ((Dlcm (6 * n) : ℤ)) ^ 2 ∣ X := by
  refine ⟨z, ?_⟩
  have hD : Dlcm (6 * n) = Dlcm (6 * n - 1) := by
    rcases Nat.eq_zero_or_pos n with rfl | hn
    · norm_num
    · exact Dlcm_six_mul n hn
  have hcast : (X : ℚ) = (((Dlcm (6 * n) : ℤ) ^ 2 * z : ℤ) : ℚ) := by
    push_cast
    rw [hX, hD]
    linear_combination ((Dlcm (6 * n - 1) : ℚ)) ^ 2 * hz
  exact_mod_cast hcast

/-- **Proposition 4.2, Nesterenko part.**  `D_{6n}²` divides the first coordinate of the
Nesterenko row. -/
theorem lcm_square_dvd_nesterenko {n : ℕ} {B : ℚ} {z V : ℤ}
    (hz : (4 : ℚ) ^ (7 * n) * B = z)
    (hV : (V : ℚ) = 4 ^ (7 * n + 1) * (Dlcm (6 * n) : ℚ) ^ 2 * B) :
    ((Dlcm (6 * n) : ℤ)) ^ 2 ∣ V := by
  refine ⟨4 * z, ?_⟩
  have hcast : (V : ℚ) = (((Dlcm (6 * n) : ℤ) ^ 2 * (4 * z) : ℤ) : ℚ) := by
    push_cast
    rw [hV]
    linear_combination (4 * (Dlcm (6 * n) : ℚ) ^ 2) * hz
  exact_mod_cast hcast

/-- **Main theorem** (Theorem 1.2 of the paper).  Combining the Zudilin row at index `3n`
with Nesterenko's `(4,7)` row and removing the full common modulus `Sₙ = D_{6n}²` yields an
admissible approximation sequence for Catalan's constant of construction quality at least
`δ₀ = (A₂ - E₂)/A_* = 0.65887…`.

The hypotheses are exactly the facts quoted from the literature:

* `hX`, `hY`, `hQzint`: Zudilin's row at index `3n` together with the denominator bound of
  Lemma 3.1 (`2^{e_m} Q_m ∈ ℤ`);
* `hV`, `hU`, `hBint`, `hNid`: Nesterenko's `(4,7)` row, the integrality `4^{7n}Bₙ ∈ ℤ`, and
  his partial-fraction identity `Jₙ = 4BₙG - Cₙ`;
* `hQzrate`, `hLZrate`, `hBrate`, `hJrate`: the asymptotics of Zudilin and Nesterenko;
* `hPNT`: the prime number theorem in the form `log D_m = m + o(m)`. -/
theorem catalan_two_row_full_lcm
    (Qz Pz Bn Cn : ℕ → ℚ) (Jn : ℕ → ℝ) (X Y V U : ℕ → ℤ)
    (hX : ∀ n, (X n : ℚ) = 2 ^ ezud (3 * n) * (Dlcm (6 * n - 1) : ℚ) ^ 2 * Qz (3 * n))
    (hY : ∀ n, (Y n : ℚ) = 2 ^ ezud (3 * n) * (Dlcm (6 * n - 1) : ℚ) ^ 2 * Pz (3 * n))
    (hQzint : ∀ m, ∃ z : ℤ, (2 : ℚ) ^ ezud m * Qz m = z)
    (hV : ∀ n, (V n : ℚ) = 4 ^ (7 * n + 1) * (Dlcm (6 * n) : ℚ) ^ 2 * Bn n)
    (hU : ∀ n, (U n : ℚ) = 4 ^ (7 * n) * (Dlcm (6 * n) : ℚ) ^ 2 * Cn n)
    (hBint : ∀ n, ∃ z : ℤ, (4 : ℚ) ^ (7 * n) * Bn n = z)
    (hNid : ∀ n, Jn n = 4 * (Bn n : ℝ) * Catalan - (Cn n : ℝ))
    (hQzrate : LogRate (fun m => (Qz m : ℝ)) (5 * Real.log phi))
    (hLZrate : LogRate (fun m => (Qz m : ℝ) * Catalan - (Pz m : ℝ)) (-(5 * Real.log phi)))
    (hBrate : LogRate (fun n => (Bn n : ℝ)) (2 * Real.log Tplus))
    (hJrate : LogRate Jn (2 * Real.log Tminus))
    (hPNT : LogRate (fun m => (Dlcm m : ℝ)) 1) :
    ∃ q p : ℕ → ℤ, AdmissibleApprox Catalan q p ∧
      ((delta₀ : ℝ) : EReal) ≤ constructionQuality Catalan q p := by
  -- the common modulus `Sₙ = D_{6n}²` and Proposition 4.2
  have hDposR : ∀ m : ℕ, (0 : ℝ) < (Dlcm m : ℝ) := fun m => by exact_mod_cast Dlcm_pos m
  have hSpos : ∀ n : ℕ, (0 : ℤ) < (Dlcm (6 * n) : ℤ) ^ 2 := by
    intro n
    have h : (0 : ℤ) < (Dlcm (6 * n) : ℤ) := by exact_mod_cast Dlcm_pos (6 * n)
    positivity
  have hSX : ∀ n, ((Dlcm (6 * n) : ℤ)) ^ 2 ∣ X n := by
    intro n
    obtain ⟨z, hz⟩ := hQzint (3 * n)
    exact lcm_square_dvd_zudilin (ezud (3 * n)) hz (hX n)
  have hSV : ∀ n, ((Dlcm (6 * n) : ℤ)) ^ 2 ∣ V n := by
    intro n
    obtain ⟨z, hz⟩ := hBint n
    exact lcm_square_dvd_nesterenko hz (hV n)
  -- rate of the modulus
  have hD6 : LogRate (fun n => (Dlcm (6 * n) : ℝ)) 6 := by
    have h := hPNT.comp_mul (k := 6) (by norm_num)
    simpa using h
  have hD6ne : ∀ᶠ n : ℕ in atTop, (Dlcm (6 * n) : ℝ) ≠ 0 :=
    Eventually.of_forall fun n => (hDposR _).ne'
  have hD6sq : LogRate (fun n => (Dlcm (6 * n) : ℝ) ^ 2) 12 := by
    have h := hD6.mul hD6 hD6ne hD6ne
    norm_num at h
    exact h.congr_ev (Eventually.of_forall fun n => (pow_two _).symm)
  have hD6sqne : ∀ᶠ n : ℕ in atTop, (Dlcm (6 * n) : ℝ) ^ 2 ≠ 0 :=
    Eventually.of_forall fun n => pow_ne_zero 2 (hDposR _).ne'
  have hSrate : LogRate (fun n => (((Dlcm (6 * n) : ℤ) ^ 2 : ℤ) : ℝ)) 12 :=
    hD6sq.congr_ev (Eventually.of_forall fun n => by push_cast; ring)
  -- rate of the power of two coming from Lemma 3.1
  have hezud3 : Tendsto (fun n : ℕ => (ezud (3 * n) : ℝ) / n) atTop (𝓝 12) := by
    have h := LogRate.tendsto_div_comp_mul (k := 3) (by norm_num) ezud_tendsto
    norm_num at h
    exact h
  have hpow2 : LogRate (fun n => (2 : ℝ) ^ ezud (3 * n)) (12 * Real.log 2) :=
    LogRate.pow_of_tendsto (by norm_num) hezud3
  have hpow2ne : ∀ᶠ n : ℕ in atTop, (2 : ℝ) ^ ezud (3 * n) ≠ 0 :=
    Eventually.of_forall fun n => by positivity
  -- rates of the Zudilin data at index `3n`
  have hlogphi : 0 < Real.log phi := Real.log_pos phi_gt_one
  have hQ3 : LogRate (fun n => (Qz (3 * n) : ℝ)) (15 * Real.log phi) := by
    have h := hQzrate.comp_mul (k := 3) (by norm_num)
    have he : ((3 : ℕ) : ℝ) * (5 * Real.log phi) = 15 * Real.log phi := by push_cast; ring
    rw [he] at h
    exact h
  have hQ3ne : ∀ᶠ n : ℕ in atTop, (Qz (3 * n) : ℝ) ≠ 0 :=
    hQ3.eventually_ne_zero (by positivity)
  have hLZ3 : LogRate (fun n => (Qz (3 * n) : ℝ) * Catalan - (Pz (3 * n) : ℝ))
      (-(15 * Real.log phi)) := by
    have h := hLZrate.comp_mul (k := 3) (by norm_num)
    have he : ((3 : ℕ) : ℝ) * (-(5 * Real.log phi)) = -(15 * Real.log phi) := by
      push_cast; ring
    rw [he] at h
    exact h
  have hLZ3ne : ∀ᶠ n : ℕ in atTop, (Qz (3 * n) : ℝ) * Catalan - (Pz (3 * n) : ℝ) ≠ 0 :=
    hLZ3.eventually_ne_zero (by intro h; nlinarith)
  -- the Zudilin row
  have hXrate : LogRate (fun n => (X n : ℝ)) A₁ := by
    have hmul2 : LogRate (fun n => (Dlcm (6 * n) : ℝ) ^ 2 * (Qz (3 * n) : ℝ))
        (12 + 15 * Real.log phi) := hD6sq.mul hQ3 hD6sqne hQ3ne
    have hmul3 : LogRate
        (fun n => (2 : ℝ) ^ ezud (3 * n) * ((Dlcm (6 * n) : ℝ) ^ 2 * (Qz (3 * n) : ℝ)))
        (12 * Real.log 2 + (12 + 15 * Real.log phi)) := by
      refine hpow2.mul hmul2 hpow2ne ?_
      filter_upwards [hQ3ne] with n hn
      exact mul_ne_zero (pow_ne_zero 2 (hDposR _).ne') hn
    have hrate : 12 * Real.log 2 + (12 + 15 * Real.log phi) = A₁ := by unfold A₁; ring
    rw [hrate] at hmul3
    refine hmul3.congr_ev ?_
    filter_upwards [eventually_gt_atTop 0] with n hn
    have hD : Dlcm (6 * n) = Dlcm (6 * n - 1) := Dlcm_six_mul n hn
    have hR : (X n : ℝ)
        = 2 ^ ezud (3 * n) * (Dlcm (6 * n - 1) : ℝ) ^ 2 * (Qz (3 * n) : ℝ) := by
      exact_mod_cast congrArg (fun r : ℚ => (r : ℝ)) (hX n)
    rw [hR, hD]
    ring
  have hL1rate : LogRate (fun n => (X n : ℝ) * Catalan - (Y n : ℝ)) E₁ := by
    have hmul2 : LogRate
        (fun n => (Dlcm (6 * n) : ℝ) ^ 2 * ((Qz (3 * n) : ℝ) * Catalan - (Pz (3 * n) : ℝ)))
        (12 + -(15 * Real.log phi)) := hD6sq.mul hLZ3 hD6sqne hLZ3ne
    have hmul3 : LogRate
        (fun n => (2 : ℝ) ^ ezud (3 * n) *
          ((Dlcm (6 * n) : ℝ) ^ 2 * ((Qz (3 * n) : ℝ) * Catalan - (Pz (3 * n) : ℝ))))
        (12 * Real.log 2 + (12 + -(15 * Real.log phi))) := by
      refine hpow2.mul hmul2 hpow2ne ?_
      filter_upwards [hLZ3ne] with n hn
      exact mul_ne_zero (pow_ne_zero 2 (hDposR _).ne') hn
    have hrate : 12 * Real.log 2 + (12 + -(15 * Real.log phi)) = E₁ := by unfold E₁; ring
    rw [hrate] at hmul3
    refine hmul3.congr_ev ?_
    filter_upwards [eventually_gt_atTop 0] with n hn
    have hD : Dlcm (6 * n) = Dlcm (6 * n - 1) := Dlcm_six_mul n hn
    have hRX : (X n : ℝ)
        = 2 ^ ezud (3 * n) * (Dlcm (6 * n - 1) : ℝ) ^ 2 * (Qz (3 * n) : ℝ) := by
      exact_mod_cast congrArg (fun r : ℚ => (r : ℝ)) (hX n)
    have hRY : (Y n : ℝ)
        = 2 ^ ezud (3 * n) * (Dlcm (6 * n - 1) : ℝ) ^ 2 * (Pz (3 * n) : ℝ) := by
      exact_mod_cast congrArg (fun r : ℚ => (r : ℝ)) (hY n)
    rw [hRX, hRY, hD]
    ring
  -- the Nesterenko row
  have hlog4 : Real.log 4 = 2 * Real.log 2 := by
    rw [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.log_pow]
    push_cast
    ring
  have hpow4 : LogRate (fun n => (4 : ℝ) ^ (7 * n + 1)) (14 * Real.log 2) := by
    have h := LogRate.pow_of_tendsto (c := (4 : ℝ)) (by norm_num) (tendsto_linear_div 7 1)
    have he : ((7 : ℕ) : ℝ) * Real.log 4 = 14 * Real.log 2 := by
      rw [hlog4]; push_cast; ring
    rw [he] at h
    exact h
  have hpow4' : LogRate (fun n => (4 : ℝ) ^ (7 * n)) (14 * Real.log 2) := by
    have h := LogRate.pow_of_tendsto (c := (4 : ℝ)) (by norm_num) (tendsto_linear_div 7 0)
    have he : ((7 : ℕ) : ℝ) * Real.log 4 = 14 * Real.log 2 := by
      rw [hlog4]; push_cast; ring
    rw [he] at h
    exact h.congr_ev (Eventually.of_forall fun n => by norm_num)
  have hBne : ∀ᶠ n : ℕ in atTop, (Bn n : ℝ) ≠ 0 := by
    refine hBrate.eventually_ne_zero ?_
    have h : 0 < Real.log Tplus := Real.log_pos (by linarith [Tplus_gt])
    positivity
  have hJne : ∀ᶠ n : ℕ in atTop, Jn n ≠ 0 := by
    refine hJrate.eventually_ne_zero ?_
    have h : Real.log Tminus < 0 := Real.log_neg Tminus_pos Tminus_lt_one
    intro hcon
    linarith
  have hVrate : LogRate (fun n => (V n : ℝ)) A₂ := by
    have hmul2 : LogRate (fun n => (Dlcm (6 * n) : ℝ) ^ 2 * (Bn n : ℝ))
        (12 + 2 * Real.log Tplus) := hD6sq.mul hBrate hD6sqne hBne
    have hmul3 : LogRate
        (fun n => (4 : ℝ) ^ (7 * n + 1) * ((Dlcm (6 * n) : ℝ) ^ 2 * (Bn n : ℝ)))
        (14 * Real.log 2 + (12 + 2 * Real.log Tplus)) := by
      refine hpow4.mul hmul2 (Eventually.of_forall fun n => by positivity) ?_
      filter_upwards [hBne] with n hn
      exact mul_ne_zero (pow_ne_zero 2 (hDposR _).ne') hn
    have hrate : 14 * Real.log 2 + (12 + 2 * Real.log Tplus) = A₂ := by unfold A₂; ring
    rw [hrate] at hmul3
    refine hmul3.congr_ev (Eventually.of_forall fun n => ?_)
    have hR : (V n : ℝ) = 4 ^ (7 * n + 1) * (Dlcm (6 * n) : ℝ) ^ 2 * (Bn n : ℝ) := by
      exact_mod_cast congrArg (fun r : ℚ => (r : ℝ)) (hV n)
    rw [hR]
    ring
  have hL2rate : LogRate (fun n => (V n : ℝ) * Catalan - (U n : ℝ)) E₂ := by
    have hmul2 : LogRate (fun n => (Dlcm (6 * n) : ℝ) ^ 2 * Jn n)
        (12 + 2 * Real.log Tminus) := hD6sq.mul hJrate hD6sqne hJne
    have hmul3 : LogRate (fun n => (4 : ℝ) ^ (7 * n) * ((Dlcm (6 * n) : ℝ) ^ 2 * Jn n))
        (14 * Real.log 2 + (12 + 2 * Real.log Tminus)) := by
      refine hpow4'.mul hmul2 (Eventually.of_forall fun n => by positivity) ?_
      filter_upwards [hJne] with n hn
      exact mul_ne_zero (pow_ne_zero 2 (hDposR _).ne') hn
    have hrate : 14 * Real.log 2 + (12 + 2 * Real.log Tminus) = E₂ := by unfold E₂; ring
    rw [hrate] at hmul3
    refine hmul3.congr_ev (Eventually.of_forall fun n => ?_)
    have hRV : (V n : ℝ) = 4 ^ (7 * n + 1) * (Dlcm (6 * n) : ℝ) ^ 2 * (Bn n : ℝ) := by
      exact_mod_cast congrArg (fun r : ℚ => (r : ℝ)) (hV n)
    have hRU : (U n : ℝ) = 4 ^ (7 * n) * (Dlcm (6 * n) : ℝ) ^ 2 * (Cn n : ℝ) := by
      exact_mod_cast congrArg (fun r : ℚ => (r : ℝ)) (hU n)
    rw [hRV, hRU, hNid n]
    ring
  -- apply the selection theorem
  obtain ⟨q, p, hadm, hqual⟩ := selection (α := Catalan) (X := X) (Y := Y) (V := V) (U := U)
    (S := fun n => (Dlcm (6 * n) : ℤ) ^ 2) (A₁ := A₁) (E₁ := E₁) (A₂ := A₂) (E₂ := E₂)
    (s := 12) hSpos hSX hSV hXrate hVrate hL1rate hL2rate hSrate (ne_of_gt A₂_pos)
    (ne_of_gt E₁_pos) crossed_gap (by have h := E_sum_gt; linarith)
    (by have h := A₂_sub_E₂_pos; linarith)
  refine ⟨q, p, hadm, ?_⟩
  have hdelta : delta₀ = (A₂ - E₂) / (A₂ - (12 + E₂ - E₁) / 2) := by
    unfold delta₀ Astar
    ring
  rw [hdelta]
  exact hqual

end CatalanLCM
