import Mathlib

/-!
# Two-dimensional geometry of numbers

This file contains the elementary geometry-of-numbers input for the
"two-successive-minima selection theorem" of the paper.

We work with a lattice in `ℝ²` spanned by two vectors
`w₁ = (Q₁, L₁)` and `w₂ = (Q₂, L₂)`, whose *first* coordinates are integers
(in the application the first coordinate of a lattice point is the denominator
`q` of a rational approximation and the second is the linear form `qα - p`).

The main results are:

* `CatalanLCM.hermite`: a nonzero *primitive* lattice point which is short for
  the (scaled) Euclidean norm - a two-dimensional Hermite bound, proved by an
  infimum/descent argument (no discreteness or Minkowski theory needed);
* `CatalanLCM.selection_nondeg`: if the linear form does not vanish on any
  nonzero lattice point, then there is a lattice point whose first coordinate is
  *at least* `Q/2` while its second coordinate is at most `E` in absolute value
  (here `Q * E = |det|`).  This is the quantitative heart of the selection
  theorem: it guarantees that no accidental cancellation destroys the height;
* `CatalanLCM.selection_deg`: in the degenerate case where the linear form does
  vanish on a nonzero lattice point, one can find lattice points with arbitrarily
  large first coordinate whose linear form is nonzero and bounded by `|det|`.
-/

namespace CatalanLCM

section Lattice

variable (Q₁ Q₂ : ℤ) (L₁ L₂ : ℝ)

/-- First (integral) coordinate of the lattice point with coefficients `(a, b)`. -/
def qcoord (a b : ℤ) : ℤ := a * Q₁ + b * Q₂

/-- Second (real) coordinate of the lattice point with coefficients `(a, b)`. -/
def lcoord (a b : ℤ) : ℝ := a * L₁ + b * L₂

/-- The determinant of the two spanning vectors. -/
def latdet : ℝ := Q₁ * L₂ - Q₂ * L₁

variable {Q₁ Q₂ L₁ L₂}

lemma qcoord_linear (a b c d k : ℤ) :
    qcoord Q₁ Q₂ (c - k * a) (d - k * b)
      = qcoord Q₁ Q₂ c d - k * qcoord Q₁ Q₂ a b := by
  simp only [qcoord]; ring

lemma lcoord_linear (a b c d k : ℤ) :
    lcoord L₁ L₂ (c - k * a) (d - k * b)
      = lcoord L₁ L₂ c d - k * lcoord L₁ L₂ a b := by
  simp only [lcoord]; push_cast; ring

lemma qcoord_smul (g a b : ℤ) :
    qcoord Q₁ Q₂ (g * a) (g * b) = g * qcoord Q₁ Q₂ a b := by
  simp only [qcoord]; ring

lemma lcoord_smul (g a b : ℤ) :
    lcoord L₁ L₂ (g * a) (g * b) = g * lcoord L₁ L₂ a b := by
  simp only [lcoord]; push_cast; ring

/-- The basic determinant identity: the determinant of two lattice points is the
determinant of their coefficient matrix times the determinant of the lattice. -/
lemma det_eval (a b c d : ℤ) :
    (qcoord Q₁ Q₂ a b : ℝ) * lcoord L₁ L₂ c d
        - (qcoord Q₁ Q₂ c d : ℝ) * lcoord L₁ L₂ a b
      = ((a * d - b * c : ℤ) : ℝ) * latdet Q₁ Q₂ L₁ L₂ := by
  simp only [qcoord, lcoord, latdet]
  push_cast
  ring

/-- A nonzero coefficient vector gives a nonzero lattice point (as soon as the
lattice is nondegenerate). -/
lemma ne_zero_of_coeff_ne_zero (hdet : latdet Q₁ Q₂ L₁ L₂ ≠ 0) {a b : ℤ}
    (hab : ¬(a = 0 ∧ b = 0)) :
    ¬((qcoord Q₁ Q₂ a b : ℝ) = 0 ∧ lcoord L₁ L₂ a b = 0) := by
  rintro ⟨h1, h2⟩
  -- complete `(a,b)` to a basis after dividing by the content
  have hg : (Int.gcd a b : ℤ) ≠ 0 := by
    simp only [ne_eq, Int.natCast_eq_zero, Int.gcd_eq_zero_iff]
    exact hab
  obtain ⟨c, d, hcd⟩ : ∃ c d : ℤ, a * d - b * c = Int.gcd a b := by
    refine ⟨-Int.gcdB a b, Int.gcdA a b, ?_⟩
    have := Int.gcd_eq_gcd_ab a b
    linarith [this]
  have key := det_eval (Q₁ := Q₁) (Q₂ := Q₂) (L₁ := L₁) (L₂ := L₂) a b c d
  rw [h1, h2, hcd] at key
  have key' : ((Int.gcd a b : ℤ) : ℝ) * latdet Q₁ Q₂ L₁ L₂ = 0 := by linarith
  rcases mul_eq_zero.1 key' with h | h
  · exact hg (by exact_mod_cast h)
  · exact hdet h

lemma qcoord_smul' (g a b : ℤ) :
    qcoord Q₁ Q₂ (a * g) (b * g) = g * qcoord Q₁ Q₂ a b := by
  simp only [qcoord]; ring

lemma lcoord_smul' (g a b : ℤ) :
    lcoord L₁ L₂ (a * g) (b * g) = g * lcoord L₁ L₂ a b := by
  simp only [lcoord]; push_cast; ring

/-- The quadratic inequality underlying the Hermite bound. -/
private lemma quad_bound {X Z I : ℝ} (hX : 0 < X) (h1 : X < Z + 1 / 10)
    (h2 : (1 : ℝ) = X * Z - I ^ 2) (h3 : I ^ 2 ≤ (X / 2) ^ 2) : X ≤ 3 / 2 := by
  nlinarith [hX, h1, h2, h3]

/-- **Two-dimensional Hermite bound.**  If `Q * E = |det|`, then the lattice contains a
nonzero *primitive* point `(q, ℓ)` with `(q/Q)^2 + (ℓ/E)^2 ≤ 3/2`.

The proof is a descent argument: pick an almost-minimal vector for the scaled Euclidean
norm, complete it to a basis, reduce the second basis vector against it, and apply
Lagrange's identity.  In particular no discreteness (or Minkowski theory) is needed. -/
lemma hermite {Q E : ℝ} (hQ : 0 < Q) (hE : 0 < E)
    (hdet : latdet Q₁ Q₂ L₁ L₂ ≠ 0) (hQE : Q * E = |latdet Q₁ Q₂ L₁ L₂|) :
    ∃ a b : ℤ, Int.gcd a b = 1 ∧
      ((qcoord Q₁ Q₂ a b : ℝ) / Q) ^ 2 + (lcoord L₁ L₂ a b / E) ^ 2 ≤ 3 / 2 := by
  classical
  -- the determinant of two lattice points with unimodular coefficient matrix
  have hdetsq : ∀ x y z w : ℤ, x * w - y * z = 1 →
      ((qcoord Q₁ Q₂ x y : ℝ) / Q) * (lcoord L₁ L₂ z w / E)
        - ((qcoord Q₁ Q₂ z w : ℝ) / Q) * (lcoord L₁ L₂ x y / E)
        = latdet Q₁ Q₂ L₁ L₂ / |latdet Q₁ Q₂ L₁ L₂| := by
    intro x y z w hxy
    have h := det_eval (Q₁ := Q₁) (Q₂ := Q₂) (L₁ := L₁) (L₂ := L₂) x y z w
    rw [hxy] at h
    have hsplit : ((qcoord Q₁ Q₂ x y : ℝ) / Q) * (lcoord L₁ L₂ z w / E)
        - ((qcoord Q₁ Q₂ z w : ℝ) / Q) * (lcoord L₁ L₂ x y / E)
        = ((qcoord Q₁ Q₂ x y : ℝ) * lcoord L₁ L₂ z w
            - (qcoord Q₁ Q₂ z w : ℝ) * lcoord L₁ L₂ x y) / (Q * E) := by
      field_simp
    rw [hsplit, h, hQE]
    push_cast
    ring
  have habs : (latdet Q₁ Q₂ L₁ L₂ / |latdet Q₁ Q₂ L₁ L₂|) ^ 2 = 1 := by
    rw [div_pow, sq_abs]
    field_simp
  -- the infimum of the scaled norms of nonzero lattice points
  set 𝒮 : Set ℝ := {r | ∃ a b : ℤ, ¬(a = 0 ∧ b = 0) ∧
      r = ((qcoord Q₁ Q₂ a b : ℝ) / Q) ^ 2 + (lcoord L₁ L₂ a b / E) ^ 2} with h𝒮
  have hne : 𝒮.Nonempty := ⟨_, 1, 0, by simp, rfl⟩
  have hbdd : BddBelow 𝒮 := ⟨0, by rintro r ⟨a, b, -, rfl⟩; positivity⟩
  set s := sInf 𝒮 with hs
  have hs_le : ∀ a b : ℤ, ¬(a = 0 ∧ b = 0) →
      s ≤ ((qcoord Q₁ Q₂ a b : ℝ) / Q) ^ 2 + (lcoord L₁ L₂ a b / E) ^ 2 :=
    fun a b hab => csInf_le hbdd ⟨a, b, hab, rfl⟩
  obtain ⟨r, hr_mem, hr_lt⟩ : ∃ r ∈ 𝒮, r < s + 1 / 10 :=
    exists_lt_of_csInf_lt hne (by linarith)
  obtain ⟨a, b, hab, rfl⟩ := hr_mem
  -- divide by the content to get a primitive vector
  have hgpos : 0 < Int.gcd a b := Nat.pos_of_ne_zero (fun h => hab (Int.gcd_eq_zero_iff.1 h))
  obtain ⟨g, a', b', hg, hcop, ha', hb'⟩ := Int.exists_gcd_one' hgpos
  have hab' : ¬(a' = 0 ∧ b' = 0) := by
    rintro ⟨rfl, rfl⟩
    exact hab ⟨by simp [ha'], by simp [hb']⟩
  have hg1 : (1 : ℝ) ≤ (g : ℝ) := by exact_mod_cast hg
  have hexp : ((qcoord Q₁ Q₂ a b : ℝ) / Q) ^ 2 + (lcoord L₁ L₂ a b / E) ^ 2
      = (g : ℝ) ^ 2 * (((qcoord Q₁ Q₂ a' b' : ℝ) / Q) ^ 2
          + (lcoord L₁ L₂ a' b' / E) ^ 2) := by
    rw [ha', hb', qcoord_smul', lcoord_smul']
    push_cast
    ring
  refine ⟨a', b', hcop, ?_⟩
  -- complete the primitive vector to a basis
  obtain ⟨c, d, hcd⟩ : ∃ c d : ℤ, a' * d - b' * c = 1 := by
    refine ⟨-Int.gcdB a' b', Int.gcdA a' b', ?_⟩
    have h := Int.gcd_eq_gcd_ab a' b'
    rw [hcop] at h
    push_cast at h
    linarith
  set U₁ : ℝ := (qcoord Q₁ Q₂ a' b' : ℝ) / Q with hU₁
  set W₁ : ℝ := lcoord L₁ L₂ a' b' / E with hW₁
  set U₂ : ℝ := (qcoord Q₁ Q₂ c d : ℝ) / Q with hU₂
  set W₂ : ℝ := lcoord L₁ L₂ c d / E with hW₂
  have hXv : 0 < U₁ ^ 2 + W₁ ^ 2 := by
    rcases not_and_or.1 (ne_zero_of_coeff_ne_zero hdet hab') with h | h
    · have h1 : U₁ ≠ 0 := by rw [hU₁]; exact div_ne_zero h hQ.ne'
      have h2 : 0 < U₁ ^ 2 := by positivity
      nlinarith [sq_nonneg W₁]
    · have h1 : W₁ ≠ 0 := by rw [hW₁]; exact div_ne_zero h hE.ne'
      have h2 : 0 < W₁ ^ 2 := by positivity
      nlinarith [sq_nonneg U₁]
  have hlt : U₁ ^ 2 + W₁ ^ 2 < s + 1 / 10 := by
    rw [hexp] at hr_lt
    have hg2 : (1 : ℝ) ≤ (g : ℝ) ^ 2 := by nlinarith
    nlinarith [hr_lt, hXv, hg2]
  -- reduce the second basis vector against the first one
  set k : ℤ := round ((U₁ * U₂ + W₁ * W₂) / (U₁ ^ 2 + W₁ ^ 2)) with hk
  have hcd' : a' * (d - k * b') - b' * (c - k * a') = 1 := by linear_combination hcd
  have hc'd'ne : ¬(c - k * a' = 0 ∧ d - k * b' = 0) := by
    rintro ⟨h1, h2⟩; rw [h1, h2] at hcd'; simp at hcd'
  have hU₂' : (qcoord Q₁ Q₂ (c - k * a') (d - k * b') : ℝ) / Q = U₂ - (k : ℝ) * U₁ := by
    rw [qcoord_linear, hU₁, hU₂]; push_cast; ring
  have hW₂' : lcoord L₁ L₂ (c - k * a') (d - k * b') / E = W₂ - (k : ℝ) * W₁ := by
    rw [lcoord_linear, hW₁, hW₂]; ring
  have hz'ge : s ≤ (U₂ - (k : ℝ) * U₁) ^ 2 + (W₂ - (k : ℝ) * W₁) ^ 2 := by
    have h := hs_le (c - k * a') (d - k * b') hc'd'ne
    rwa [hU₂', hW₂'] at h
  have hinner : |U₁ * (U₂ - (k : ℝ) * U₁) + W₁ * (W₂ - (k : ℝ) * W₁)|
      ≤ (U₁ ^ 2 + W₁ ^ 2) / 2 := by
    have hne0 : U₁ ^ 2 + W₁ ^ 2 ≠ 0 := ne_of_gt hXv
    have hround := abs_sub_round ((U₁ * U₂ + W₁ * W₂) / (U₁ ^ 2 + W₁ ^ 2))
    rw [← hk] at hround
    have heq : U₁ * (U₂ - (k : ℝ) * U₁) + W₁ * (W₂ - (k : ℝ) * W₁)
        = (U₁ ^ 2 + W₁ ^ 2)
          * ((U₁ * U₂ + W₁ * W₂) / (U₁ ^ 2 + W₁ ^ 2) - (k : ℝ)) := by
      field_simp
      ring
    rw [heq, abs_mul, abs_of_pos hXv]
    calc (U₁ ^ 2 + W₁ ^ 2) * |(U₁ * U₂ + W₁ * W₂) / (U₁ ^ 2 + W₁ ^ 2) - (k : ℝ)|
        ≤ (U₁ ^ 2 + W₁ ^ 2) * (1 / 2) := mul_le_mul_of_nonneg_left hround (le_of_lt hXv)
      _ = (U₁ ^ 2 + W₁ ^ 2) / 2 := by ring
  have hdet1 : U₁ * (W₂ - (k : ℝ) * W₁) - (U₂ - (k : ℝ) * U₁) * W₁
      = latdet Q₁ Q₂ L₁ L₂ / |latdet Q₁ Q₂ L₁ L₂| := by
    rw [hU₁, hW₁, ← hU₂', ← hW₂']
    exact hdetsq a' b' (c - k * a') (d - k * b') hcd'
  have hkey : (1 : ℝ) = (U₁ ^ 2 + W₁ ^ 2)
        * ((U₂ - (k : ℝ) * U₁) ^ 2 + (W₂ - (k : ℝ) * W₁) ^ 2)
      - (U₁ * (U₂ - (k : ℝ) * U₁) + W₁ * (W₂ - (k : ℝ) * W₁)) ^ 2 := by
    have hlag : (U₁ * (W₂ - (k : ℝ) * W₁) - (U₂ - (k : ℝ) * U₁) * W₁) ^ 2
        = (U₁ ^ 2 + W₁ ^ 2) * ((U₂ - (k : ℝ) * U₁) ^ 2 + (W₂ - (k : ℝ) * W₁) ^ 2)
          - (U₁ * (U₂ - (k : ℝ) * U₁) + W₁ * (W₂ - (k : ℝ) * W₁)) ^ 2 := by ring
    rw [← hlag, hdet1, habs]
  have habs2 : (U₁ * (U₂ - (k : ℝ) * U₁) + W₁ * (W₂ - (k : ℝ) * W₁)) ^ 2
      ≤ ((U₁ ^ 2 + W₁ ^ 2) / 2) ^ 2 := by
    have h := abs_le.1 hinner
    exact sq_le_sq' h.1 h.2
  exact quad_bound hXv (by linarith) hkey habs2

/-- **Selection theorem, nondegenerate case.**  Suppose the linear form `ℓ` does not vanish
at any nonzero lattice point, and `Q * E = |det|`.  Then there is a lattice point whose
first coordinate is *at least* `Q/2` in absolute value while its linear form is nonzero and
at most `E` in absolute value.

This is the quantitative heart of the selection theorem: dividing a row by a large common
modulus creates a lattice whose first minimum may be exponentially short, but reducing a
second basis vector against a short vector recovers a point of essentially maximal
height. -/
theorem selection_nondeg {Q E : ℝ} (hQ : 0 < Q) (hE : 0 < E)
    (hdet : latdet Q₁ Q₂ L₁ L₂ ≠ 0) (hQE : Q * E = |latdet Q₁ Q₂ L₁ L₂|)
    (hnd : ∀ a b : ℤ, lcoord L₁ L₂ a b = 0 → a = 0 ∧ b = 0) :
    ∃ a b : ℤ, lcoord L₁ L₂ a b ≠ 0 ∧ Q / 2 ≤ |(qcoord Q₁ Q₂ a b : ℝ)|
      ∧ |lcoord L₁ L₂ a b| ≤ E := by
  obtain ⟨a, b, hcop, hnorm⟩ := hermite hQ hE hdet hQE
  have hab : ¬(a = 0 ∧ b = 0) := by
    rintro ⟨rfl, rfl⟩
    simp at hcop
  have hl₁ : lcoord L₁ L₂ a b ≠ 0 := fun h => hab (hnd a b h)
  -- bounds coming from the Hermite estimate
  have hu : ((qcoord Q₁ Q₂ a b : ℝ) / Q) ^ 2 + (lcoord L₁ L₂ a b / E) ^ 2 ≤ 3 / 2 := hnorm
  have hprod : |(qcoord Q₁ Q₂ a b : ℝ)| * |lcoord L₁ L₂ a b| ≤ 3 / 4 * (Q * E) := by
    have h1 : |(qcoord Q₁ Q₂ a b : ℝ) / Q| * |lcoord L₁ L₂ a b / E| ≤ 3 / 4 := by
      nlinarith [sq_abs ((qcoord Q₁ Q₂ a b : ℝ) / Q), sq_abs (lcoord L₁ L₂ a b / E),
        sq_nonneg (|(qcoord Q₁ Q₂ a b : ℝ) / Q| - |lcoord L₁ L₂ a b / E|),
        abs_nonneg ((qcoord Q₁ Q₂ a b : ℝ) / Q), abs_nonneg (lcoord L₁ L₂ a b / E)]
    rw [abs_div, abs_div, abs_of_pos hQ, abs_of_pos hE] at h1
    rw [div_mul_div_comm, div_le_iff₀ (by positivity)] at h1
    linarith
  have hlbnd : |lcoord L₁ L₂ a b| ≤ 5 / 4 * E := by
    have h1 : (lcoord L₁ L₂ a b / E) ^ 2 ≤ 3 / 2 := by
      nlinarith [sq_nonneg ((qcoord Q₁ Q₂ a b : ℝ) / Q)]
    have h2 : |lcoord L₁ L₂ a b / E| ≤ 5 / 4 := by
      nlinarith [sq_abs (lcoord L₁ L₂ a b / E), abs_nonneg (lcoord L₁ L₂ a b / E)]
    rw [abs_div, abs_of_pos hE, div_le_iff₀ hE] at h2
    linarith
  -- complete to a basis and reduce
  obtain ⟨c, d, hcd⟩ : ∃ c d : ℤ, a * d - b * c = 1 := by
    refine ⟨-Int.gcdB a b, Int.gcdA a b, ?_⟩
    have h := Int.gcd_eq_gcd_ab a b
    rw [hcop] at h
    push_cast at h
    linarith
  set k : ℤ := round (lcoord L₁ L₂ c d / lcoord L₁ L₂ a b) with hk
  have habs' : |lcoord L₁ L₂ (c - k * a) (d - k * b)| ≤ |lcoord L₁ L₂ a b| / 2 := by
      rw [lcoord_linear]
      have heq : lcoord L₁ L₂ c d - (k : ℝ) * lcoord L₁ L₂ a b
          = lcoord L₁ L₂ a b * (lcoord L₁ L₂ c d / lcoord L₁ L₂ a b - (k : ℝ)) := by
        field_simp
      rw [heq, abs_mul]
      have hround := abs_sub_round (lcoord L₁ L₂ c d / lcoord L₁ L₂ a b)
      rw [← hk] at hround
      calc |lcoord L₁ L₂ a b| * |lcoord L₁ L₂ c d / lcoord L₁ L₂ a b - (k : ℝ)|
          ≤ |lcoord L₁ L₂ a b| * (1 / 2) :=
            mul_le_mul_of_nonneg_left hround (abs_nonneg _)
        _ = |lcoord L₁ L₂ a b| / 2 := by ring
  refine ⟨c - k * a, d - k * b, ?_, ?_, ?_⟩
  · -- the reduced point still has nonvanishing linear form
    intro h
    have := hnd _ _ h
    have hcd' : a * (d - k * b) - b * (c - k * a) = 1 := by linear_combination hcd
    rw [this.1, this.2] at hcd'
    simp at hcd'
  ·
    have hdetid : (qcoord Q₁ Q₂ a b : ℝ) * lcoord L₁ L₂ (c - k * a) (d - k * b)
        - (qcoord Q₁ Q₂ (c - k * a) (d - k * b) : ℝ) * lcoord L₁ L₂ a b
        = latdet Q₁ Q₂ L₁ L₂ := by
      have h := det_eval (Q₁ := Q₁) (Q₂ := Q₂) (L₁ := L₁) (L₂ := L₂) a b (c - k * a) (d - k * b)
      have hcd' : a * (d - k * b) - b * (c - k * a) = 1 := by linear_combination hcd
      rw [hcd'] at h
      simpa using h
    have hlpos : 0 < |lcoord L₁ L₂ a b| := abs_pos.2 hl₁
    have hQE' : |latdet Q₁ Q₂ L₁ L₂| = Q * E := hQE.symm
    have hbig : (5 / 8) * (Q * E)
        ≤ |(qcoord Q₁ Q₂ (c - k * a) (d - k * b) : ℝ)| * |lcoord L₁ L₂ a b| := by
      have h1 : |latdet Q₁ Q₂ L₁ L₂|
          ≤ |(qcoord Q₁ Q₂ a b : ℝ)| * |lcoord L₁ L₂ (c - k * a) (d - k * b)|
            + |(qcoord Q₁ Q₂ (c - k * a) (d - k * b) : ℝ)| * |lcoord L₁ L₂ a b| := by
        rw [← hdetid, ← abs_mul, ← abs_mul]
        exact abs_sub _ _
      have h2 : |(qcoord Q₁ Q₂ a b : ℝ)| * |lcoord L₁ L₂ (c - k * a) (d - k * b)|
          ≤ 3 / 8 * (Q * E) := by
        have h3 : |(qcoord Q₁ Q₂ a b : ℝ)| * |lcoord L₁ L₂ (c - k * a) (d - k * b)|
            ≤ |(qcoord Q₁ Q₂ a b : ℝ)| * (|lcoord L₁ L₂ a b| / 2) :=
          mul_le_mul_of_nonneg_left habs' (abs_nonneg _)
        linarith
      rw [hQE'] at h1
      linarith
    -- the height bound
    have hq' : 0 ≤ |(qcoord Q₁ Q₂ (c - k * a) (d - k * b) : ℝ)| := abs_nonneg _
    nlinarith [hbig, hlbnd, hq', hE, hQ]
  · -- the linear form bound
    calc |lcoord L₁ L₂ (c - k * a) (d - k * b)| ≤ |lcoord L₁ L₂ a b| / 2 := habs'
      _ ≤ 5 / 4 * E / 2 := by linarith
      _ ≤ E := by linarith

/-- **Selection theorem, degenerate case.**  If the linear form vanishes at some nonzero
lattice point, then there are lattice points with arbitrarily large first coordinate whose
linear form is nonzero and bounded by `|det|` in absolute value. -/
theorem selection_deg (hdet : latdet Q₁ Q₂ L₁ L₂ ≠ 0) {a₀ b₀ : ℤ}
    (h0 : ¬(a₀ = 0 ∧ b₀ = 0)) (hl : lcoord L₁ L₂ a₀ b₀ = 0) (M : ℝ) :
    ∃ a b : ℤ, lcoord L₁ L₂ a b ≠ 0 ∧ |lcoord L₁ L₂ a b| ≤ |latdet Q₁ Q₂ L₁ L₂|
      ∧ M ≤ |(qcoord Q₁ Q₂ a b : ℝ)| := by
  -- make the vanishing vector primitive
  have hgpos : 0 < Int.gcd a₀ b₀ := Nat.pos_of_ne_zero (fun h => h0 (Int.gcd_eq_zero_iff.1 h))
  obtain ⟨g, a, b, hg, hcop, ha, hb⟩ := Int.exists_gcd_one' hgpos
  have hgne : ((g : ℤ) : ℝ) ≠ 0 := by
    simp only [ne_eq, Int.cast_natCast, Nat.cast_eq_zero]
    omega
  have hlab : lcoord L₁ L₂ a b = 0 := by
    rw [ha, hb, lcoord_smul'] at hl
    exact (mul_eq_zero.1 hl).resolve_left (by exact_mod_cast hgne)
  obtain ⟨c, d, hcd⟩ : ∃ c d : ℤ, a * d - b * c = 1 := by
    refine ⟨-Int.gcdB a b, Int.gcdA a b, ?_⟩
    have h := Int.gcd_eq_gcd_ab a b
    rw [hcop] at h
    push_cast at h
    linarith
  have hdetid : (qcoord Q₁ Q₂ a b : ℝ) * lcoord L₁ L₂ c d = latdet Q₁ Q₂ L₁ L₂ := by
    have h := det_eval (Q₁ := Q₁) (Q₂ := Q₂) (L₁ := L₁) (L₂ := L₂) a b c d
    rw [hcd, hlab] at h
    simpa using h
  have hq₀ : qcoord Q₁ Q₂ a b ≠ 0 := by
    intro h
    rw [h] at hdetid
    simp at hdetid
    exact hdet hdetid.symm
  have hq₀abs : (1 : ℝ) ≤ |(qcoord Q₁ Q₂ a b : ℝ)| := by
    have : (1 : ℤ) ≤ |qcoord Q₁ Q₂ a b| := Int.one_le_abs hq₀
    calc (1 : ℝ) ≤ ((|qcoord Q₁ Q₂ a b| : ℤ) : ℝ) := by exact_mod_cast this
      _ = |(qcoord Q₁ Q₂ a b : ℝ)| := by push_cast; rfl
  have hlcd : lcoord L₁ L₂ c d ≠ 0 := by
    intro h; rw [h, mul_zero] at hdetid; exact hdet hdetid.symm
  have hlcdle : |lcoord L₁ L₂ c d| ≤ |latdet Q₁ Q₂ L₁ L₂| := by
    rw [← hdetid, abs_mul]
    nlinarith [abs_nonneg (lcoord L₁ L₂ c d), hq₀abs]
  -- shift by a large multiple of the primitive vector
  set N : ℤ := max ⌈M⌉ 0 with hN
  have hNnonneg : (0 : ℤ) ≤ N := le_max_right _ _
  set t : ℤ := N + |qcoord Q₁ Q₂ c d| with ht
  have htnonneg : (0 : ℤ) ≤ t := by positivity
  obtain ⟨k, hk⟩ : ∃ k : ℤ, N ≤ qcoord Q₁ Q₂ c d - k * qcoord Q₁ Q₂ a b := by
    have habs1 : (1 : ℤ) ≤ |qcoord Q₁ Q₂ a b| := Int.one_le_abs hq₀
    have hneg := neg_abs_le (qcoord Q₁ Q₂ c d)
    rcases lt_or_gt_of_ne hq₀ with hlt | hgt
    · refine ⟨t, ?_⟩
      have h1 : 1 ≤ -qcoord Q₁ Q₂ a b := by omega
      nlinarith [htnonneg, hneg, h1]
    · refine ⟨-t, ?_⟩
      have h1 : 1 ≤ qcoord Q₁ Q₂ a b := by omega
      nlinarith [htnonneg, hneg, h1]
  refine ⟨c - k * a, d - k * b, ?_, ?_, ?_⟩
  · rw [lcoord_linear, hlab]; simpa using hlcd
  · rw [lcoord_linear, hlab]; simpa using hlcdle
  · rw [qcoord_linear]
    have h1 : (M : ℝ) ≤ (N : ℝ) := by
      have : M ≤ (⌈M⌉ : ℝ) := Int.le_ceil M
      have h2 : ((⌈M⌉ : ℤ) : ℝ) ≤ (N : ℝ) := by exact_mod_cast le_max_left ⌈M⌉ (0 : ℤ)
      linarith
    have h3 : ((N : ℤ) : ℝ) ≤ ((qcoord Q₁ Q₂ c d - k * qcoord Q₁ Q₂ a b : ℤ) : ℝ) := by
      exact_mod_cast hk
    push_cast at h3 ⊢
    calc M ≤ (N : ℝ) := h1
      _ ≤ (qcoord Q₁ Q₂ c d : ℝ) - (k : ℝ) * (qcoord Q₁ Q₂ a b : ℝ) := h3
      _ ≤ |(qcoord Q₁ Q₂ c d : ℝ) - (k : ℝ) * (qcoord Q₁ Q₂ a b : ℝ)| := le_abs_self _

end Lattice

end CatalanLCM
