import Mathlib

/-!
# Logarithmic rates

A sequence `a : ℕ → ℝ` has *logarithmic rate* `r` when `log |a n| = r n + o(n)`.
This is the notion in which all the growth and decay hypotheses of the paper are stated
(equation (4.1) there).  We develop the small amount of API that is needed:
two-sided exponential bounds, and the behaviour of rates under products, quotients and
differences with a strictly dominant term.
-/

namespace CatalanLCM

open Filter Real
open scoped Topology

/-- `a` has logarithmic rate `r`, i.e. `log |a n| = r n + o(n)`. -/
def LogRate (a : ℕ → ℝ) (r : ℝ) : Prop :=
  Tendsto (fun n : ℕ => Real.log |a n| / n) atTop (𝓝 r)

namespace LogRate

variable {a b : ℕ → ℝ} {r r' : ℝ}

/-- Rescaling the index in a Cesàro-type limit. -/
lemma tendsto_div_comp_mul {u : ℕ → ℝ} {r : ℝ} {k : ℕ} (hk : 0 < k)
    (h : Tendsto (fun m : ℕ => u m / m) atTop (𝓝 r)) :
    Tendsto (fun n : ℕ => u (k * n) / n) atTop (𝓝 (k * r)) := by
  have hmul : Tendsto (fun n : ℕ => k * n) atTop atTop := by
    refine tendsto_atTop_mono (fun n => ?_) tendsto_id
    exact Nat.le_mul_of_pos_left n hk
  have h2 : Tendsto (fun n : ℕ => u (k * n) / (k * n : ℕ)) atTop (𝓝 r) := h.comp hmul
  have h3 : Tendsto (fun n : ℕ => (k : ℝ) * (u (k * n) / (k * n : ℕ))) atTop (𝓝 (k * r)) :=
    h2.const_mul _
  refine h3.congr' ?_
  filter_upwards [eventually_gt_atTop 0] with n hn
  have hnpos : (0 : ℝ) < n := by exact_mod_cast hn
  have hkpos : (0 : ℝ) < k := by exact_mod_cast hk
  push_cast
  field_simp

/-- A sequence with a nonzero logarithmic rate is eventually nonzero. -/
lemma eventually_ne_zero (h : LogRate a r) (hr : r ≠ 0) : ∀ᶠ n : ℕ in atTop, a n ≠ 0 := by
  have h0 : ∀ᶠ n : ℕ in atTop, Real.log |a n| / n ≠ 0 := by
    have : ∀ᶠ n : ℕ in atTop, Real.log |a n| / n ∈ {x : ℝ | x ≠ 0} :=
      h.eventually (by
        refine IsOpen.eventually_mem ?_ hr
        exact isOpen_ne)
    exact this
  filter_upwards [h0] with n hn hcon
  apply hn
  rw [hcon]
  simp

/-- Eventual upper bound: `|a n| ≤ exp ((r + ε) n)`. -/
lemma eventually_le (h : LogRate a r) {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ n : ℕ in atTop, |a n| ≤ Real.exp ((r + ε) * n) := by
  have h1 : ∀ᶠ n : ℕ in atTop, Real.log |a n| / n < r + ε :=
    h.eventually_lt_const (by linarith)
  filter_upwards [h1, eventually_gt_atTop 0] with n hn hn0
  have hnpos : (0 : ℝ) < n := by exact_mod_cast hn0
  have hlog : Real.log |a n| ≤ (r + ε) * n := by
    rw [div_lt_iff₀ hnpos] at hn
    linarith
  rcases eq_or_ne (a n) 0 with h0 | h0
  · simp [h0, (Real.exp_pos _).le]
  · have : (0 : ℝ) < |a n| := abs_pos.2 h0
    calc |a n| = Real.exp (Real.log |a n|) := (Real.exp_log this).symm
      _ ≤ Real.exp ((r + ε) * n) := Real.exp_le_exp.2 hlog

/-- Eventual lower bound: `exp ((r - ε) n) ≤ |a n|`, for eventually nonvanishing `a`. -/
lemma eventually_ge (h : LogRate a r) (h0 : ∀ᶠ n : ℕ in atTop, a n ≠ 0) {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ n : ℕ in atTop, Real.exp ((r - ε) * n) ≤ |a n| := by
  have h1 : ∀ᶠ n : ℕ in atTop, r - ε < Real.log |a n| / n :=
    h.eventually_const_lt (by linarith)
  filter_upwards [h1, h0, eventually_gt_atTop 0] with n hn hne hn0
  have hnpos : (0 : ℝ) < n := by exact_mod_cast hn0
  have hlog : (r - ε) * n ≤ Real.log |a n| := by
    rw [lt_div_iff₀ hnpos] at hn
    linarith
  have hpos : (0 : ℝ) < |a n| := abs_pos.2 hne
  calc Real.exp ((r - ε) * n) ≤ Real.exp (Real.log |a n|) := Real.exp_le_exp.2 hlog
    _ = |a n| := Real.exp_log hpos

/-- Rates add along products. -/
lemma mul (ha : LogRate a r) (hb : LogRate b r')
    (ha0 : ∀ᶠ n : ℕ in atTop, a n ≠ 0) (hb0 : ∀ᶠ n : ℕ in atTop, b n ≠ 0) :
    LogRate (fun n => a n * b n) (r + r') := by
  have hcongr : (fun n : ℕ => Real.log |a n * b n| / n)
      =ᶠ[atTop] fun n : ℕ => Real.log |a n| / n + Real.log |b n| / n := by
    filter_upwards [ha0, hb0] with n hna hnb
    rw [abs_mul, Real.log_mul (abs_ne_zero.2 hna) (abs_ne_zero.2 hnb)]
    ring
  exact Tendsto.congr' hcongr.symm (ha.add hb)

/-- Rates subtract along quotients. -/
lemma div (ha : LogRate a r) (hb : LogRate b r')
    (ha0 : ∀ᶠ n : ℕ in atTop, a n ≠ 0) (hb0 : ∀ᶠ n : ℕ in atTop, b n ≠ 0) :
    LogRate (fun n => a n / b n) (r - r') := by
  have hcongr : (fun n : ℕ => Real.log |a n / b n| / n)
      =ᶠ[atTop] fun n : ℕ => Real.log |a n| / n - Real.log |b n| / n := by
    filter_upwards [ha0, hb0] with n hna hnb
    rw [abs_div, Real.log_div (abs_ne_zero.2 hna) (abs_ne_zero.2 hnb)]
    ring
  exact Tendsto.congr' hcongr.symm (ha.sub hb)

/-- An upper bound for a product, valid without any nonvanishing hypothesis. -/
lemma mul_le (ha : LogRate a r) (hb : LogRate b r') {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ n : ℕ in atTop, |a n * b n| ≤ Real.exp ((r + r' + ε) * n) := by
  filter_upwards [ha.eventually_le (half_pos hε), hb.eventually_le (half_pos hε)] with n h1 h2
  rw [abs_mul]
  calc |a n| * |b n| ≤ Real.exp ((r + ε / 2) * n) * Real.exp ((r' + ε / 2) * n) :=
        mul_le_mul h1 h2 (abs_nonneg _) (Real.exp_pos _).le
    _ = Real.exp ((r + r' + ε) * n) := by rw [← Real.exp_add]; ring_nf

/-- A difference is dominated by its larger term; here the subtracted sequence is only
assumed to satisfy eventual upper bounds. -/
lemma sub_of_le (ha : LogRate a r) (hb : ∀ ε : ℝ, 0 < ε →
      ∀ᶠ n : ℕ in atTop, |b n| ≤ Real.exp ((r' + ε) * n)) (hlt : r' < r)
    (ha0 : ∀ᶠ n : ℕ in atTop, a n ≠ 0) :
    LogRate (fun n => a n - b n) r := by
  set ε : ℝ := (r - r') / 3 with hε
  have hεpos : 0 < ε := by rw [hε]; linarith
  -- eventually `|b n| ≤ |a n| / 2`
  have hkey : ∀ᶠ n : ℕ in atTop, |b n| ≤ |a n| / 2 := by
    have hc : 0 < (r - ε) - (r' + ε) := by rw [hε]; linarith
    have hlin : Tendsto (fun n : ℕ => ((r - ε) - (r' + ε)) * n) atTop atTop :=
      Filter.Tendsto.const_mul_atTop hc tendsto_natCast_atTop_atTop
    filter_upwards [ha.eventually_ge ha0 hεpos, hb ε hεpos,
      hlin.eventually_ge_atTop (Real.log 2)] with n hga hlb hbig
    have hstep : Real.exp ((r' + ε) * n) * 2 ≤ Real.exp ((r - ε) * n) := by
      calc Real.exp ((r' + ε) * n) * 2 = Real.exp ((r' + ε) * n + Real.log 2) := by
            rw [Real.exp_add, Real.exp_log (by norm_num)]
        _ ≤ Real.exp ((r - ε) * n) := Real.exp_le_exp.2 (by nlinarith [hbig])
    linarith
  -- hence `|a n|/2 ≤ |a n - b n| ≤ 2 |a n|`, so the logarithms differ by at most `log 2`
  have hdiff : ∀ᶠ n : ℕ in atTop,
      |Real.log |a n - b n| / n - Real.log |a n| / n| ≤ Real.log 2 / n := by
    filter_upwards [hkey, ha0, eventually_gt_atTop 0] with n hb2 hane hn0
    have hnpos : (0 : ℝ) < n := by exact_mod_cast hn0
    have hapos : (0 : ℝ) < |a n| := abs_pos.2 hane
    have hlow : |a n| / 2 ≤ |a n - b n| := by
      have := abs_sub_abs_le_abs_sub (a n) (b n)
      linarith
    have hhigh : |a n - b n| ≤ 2 * |a n| := by
      have := abs_sub (a n) (b n)
      linarith
    have hcpos : (0 : ℝ) < |a n - b n| := lt_of_lt_of_le (by linarith) hlow
    have hlog1 : Real.log |a n - b n| - Real.log |a n| ≤ Real.log 2 := by
      have h := Real.log_le_log hcpos hhigh
      rw [Real.log_mul (by norm_num) (ne_of_gt hapos)] at h
      linarith
    have hlog2 : Real.log |a n| - Real.log |a n - b n| ≤ Real.log 2 := by
      have h := Real.log_le_log (by linarith : (0:ℝ) < |a n| / 2) hlow
      rw [Real.log_div (ne_of_gt hapos) (by norm_num)] at h
      linarith
    have habs : abs (Real.log |a n - b n| - Real.log |a n|) ≤ Real.log 2 :=
      abs_le.2 ⟨by linarith, hlog1⟩
    rw [div_sub_div_same, abs_div, abs_of_pos hnpos]
    gcongr
  -- conclude
  have hzero : Tendsto (fun n : ℕ => Real.log |a n - b n| / n - Real.log |a n| / n)
      atTop (𝓝 0) := by
    refine squeeze_zero_norm' ?_ (tendsto_const_div_atTop_nhds_zero_nat (Real.log 2))
    filter_upwards [hdiff] with n hn
    simpa [Real.norm_eq_abs] using hn
  have hsum := ha.add hzero
  rw [add_zero] at hsum
  exact hsum.congr fun n => by ring

/-- Logarithmic rates only depend on the eventual behaviour of the sequence. -/
lemma congr_ev (h : LogRate a r) (hab : ∀ᶠ n : ℕ in atTop, a n = b n) : LogRate b r := by
  refine h.congr' ?_
  filter_upwards [hab] with n hn
  rw [hn]

/-- Rescaling the index multiplies the logarithmic rate. -/
lemma comp_mul (h : LogRate a r) {k : ℕ} (hk : 0 < k) :
    LogRate (fun n => a (k * n)) (k * r) :=
  tendsto_div_comp_mul hk h

/-- The logarithmic rate of `c ^ f n` when `f n / n → r`. -/
lemma pow_of_tendsto {c : ℝ} (hc : 0 < c) {f : ℕ → ℕ} {r : ℝ}
    (h : Tendsto (fun n : ℕ => (f n : ℝ) / n) atTop (𝓝 r)) :
    LogRate (fun n => c ^ f n) (r * Real.log c) := by
  have h2 : Tendsto (fun n : ℕ => (f n : ℝ) / n * Real.log c) atTop (𝓝 (r * Real.log c)) :=
    h.mul_const _
  refine h2.congr fun n => ?_
  rw [abs_of_pos (by positivity), Real.log_pow]
  ring

/-- A difference is dominated by its larger term. -/
lemma sub_of_lt (ha : LogRate a r) (hb : LogRate b r') (hlt : r' < r)
    (ha0 : ∀ᶠ n : ℕ in atTop, a n ≠ 0) :
    LogRate (fun n => a n - b n) r :=
  ha.sub_of_le (fun _ hε => hb.eventually_le hε) hlt ha0

end LogRate

end CatalanLCM
