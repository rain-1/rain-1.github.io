import Mathlib

/-!
# Arithmetic lemmas: the least common multiple `D_m` and denominator clearing

This file contains the elementary arithmetic of the paper:

* `CatalanLCM.Dlcm m = lcm(1, …, m)`;
* `CatalanLCM.Dlcm_six_mul` (Lemma 4.1 of the paper): `D_{6n} = D_{6n-1}`;
* `CatalanLCM.factorial_dvd_Dlcm_mul` (the arithmetic core of Lemma 3.2):
  `(2ν+1)! ∣ D_m · 4^ν · (ν!)²` whenever `2ν+1 ≤ m`;
* `CatalanLCM.pochhammer_three_halves` : `(3/2)_ν = (2ν+1)! / (4^ν ν!)`, hence
  `CatalanLCM.Dlcm_mul_hyper_isInt` : `D_m·ν!/(3/2)_ν ∈ ℤ` for `2ν+1 ≤ m`;
* `CatalanLCM.two_power_denominator` : the denominator argument of Lemma 3.1.
-/

namespace CatalanLCM

open Finset

/-- `D m = lcm (1, 2, …, m)`. -/
def Dlcm (m : ℕ) : ℕ := (Finset.Icc 1 m).lcm id

lemma Dlcm_ne_zero (m : ℕ) : Dlcm m ≠ 0 := by
  rw [Dlcm, Ne, Finset.lcm_eq_zero_iff]
  intro h
  simp only [Finset.mem_Icc, id_eq] at h
  obtain ⟨x, hx, hx0⟩ := h
  omega

lemma Dlcm_pos (m : ℕ) : 0 < Dlcm m := Nat.pos_of_ne_zero (Dlcm_ne_zero m)

/-- Every `k` with `1 ≤ k ≤ m` divides `D m`. -/
lemma dvd_Dlcm {k m : ℕ} (hk : 1 ≤ k) (hkm : k ≤ m) : k ∣ Dlcm m := by
  have hmem : k ∈ Finset.Icc 1 m := Finset.mem_Icc.2 ⟨hk, hkm⟩
  exact Finset.dvd_lcm hmem

/-- `D m = lcm (m, D (m-1))` for `m ≥ 1`. -/
lemma Dlcm_succ (m : ℕ) (hm : 1 ≤ m) : Dlcm m = Nat.lcm m (Dlcm (m - 1)) := by
  have h : Finset.Icc 1 m = insert m (Finset.Icc 1 (m - 1)) := by
    ext x
    simp only [Finset.mem_Icc, Finset.mem_insert]
    omega
  rw [Dlcm, h, Finset.lcm_insert]
  rfl

/-- **Lemma 4.1.**  `D_{6n} = D_{6n-1}` for `n ≥ 1`: the integer `6n` is not a prime
power, hence contributes nothing new to the least common multiple. -/
theorem Dlcm_six_mul (n : ℕ) (hn : 1 ≤ n) : Dlcm (6 * n) = Dlcm (6 * n - 1) := by
  have hm0 : (6 * n) ≠ 0 := by omega
  have hm1 : 1 ≤ 6 * n := by omega
  set a := 2 ^ ((6 * n).factorization 2) with ha
  set b := (6 * n) / 2 ^ ((6 * n).factorization 2) with hb
  have hab : a * b = 6 * n := Nat.ordProj_mul_ordCompl_eq_self (6 * n) 2
  have hcop : Nat.Coprime a b :=
    Nat.Coprime.pow_left _ (Nat.coprime_ordCompl Nat.prime_two hm0)
  have h2 : 2 ∣ 6 * n := ⟨3 * n, by ring⟩
  have h3 : 3 ∣ 6 * n := ⟨2 * n, by ring⟩
  have hav : 2 ≤ a := by
    have h1v : 1 ≤ (6 * n).factorization 2 :=
      (Nat.Prime.dvd_iff_one_le_factorization Nat.prime_two hm0).1 h2
    calc (2 : ℕ) = 2 ^ 1 := (pow_one 2).symm
      _ ≤ a := Nat.pow_le_pow_right (by norm_num) h1v
  have hb0 : 0 < b := Nat.ordCompl_pos 2 hm0
  have hb3 : 3 ∣ b := by
    have hcop3 : Nat.Coprime 3 a := Nat.Coprime.pow_right _ (by decide)
    exact hcop3.dvd_of_dvd_mul_left (by rw [hab]; exact h3)
  have hb3' : 3 ≤ b := Nat.le_of_dvd hb0 hb3
  have h4 : 3 * a ≤ 6 * n := by
    calc 3 * a ≤ b * a := Nat.mul_le_mul_right a hb3'
      _ = 6 * n := by rw [mul_comm]; exact hab
  have h5 : 2 * b ≤ 6 * n := by
    calc 2 * b ≤ a * b := Nat.mul_le_mul_right b hav
      _ = 6 * n := hab
  have haltm : a ≤ 6 * n - 1 := by omega
  have hbltm : b ≤ 6 * n - 1 := by omega
  have hdvd : a * b ∣ Dlcm (6 * n - 1) :=
    Nat.Coprime.mul_dvd_of_dvd_of_dvd hcop (dvd_Dlcm (by omega) haltm) (dvd_Dlcm hb0 hbltm)
  rw [hab] at hdvd
  rw [Dlcm_succ (6 * n) hm1, Nat.lcm_eq_right hdvd]

section FactorialDivisibility

/-- Termwise Legendre estimate: `⌊(2ν+1)/k⌋ ≤ 2⌊ν/k⌋ + 1`. -/
lemma div_two_mul_add_one_le (ν k : ℕ) (hk : 0 < k) :
    (2 * ν + 1) / k ≤ 2 * (ν / k) + 1 := by
  have h1 : k * (ν / k) + ν % k = ν := Nat.div_add_mod ν k
  have h2 : ν % k < k := Nat.mod_lt _ hk
  have h3 : (2 * ν + 1) / k < 2 * (ν / k) + 2 := by
    rw [Nat.div_lt_iff_lt_mul hk]
    have h4 : (2 * (ν / k) + 2) * k = 2 * (k * (ν / k)) + 2 * k := by ring
    omega
  omega

/-- **The arithmetic core of Lemma 3.2.**  If `2ν+1 ≤ m` then `(2ν+1)!` divides
`D_m · 4^ν · (ν!)²`. -/
theorem factorial_dvd_Dlcm_mul (m ν : ℕ) (hm : 2 * ν + 1 ≤ m) :
    Nat.factorial (2 * ν + 1) ∣ Dlcm m * 4 ^ ν * (Nat.factorial ν) ^ 2 := by
  have h4ne : (4 : ℕ) ^ ν ≠ 0 := pow_ne_zero _ (by norm_num)
  have hfacne : (Nat.factorial ν) ^ 2 ≠ 0 := pow_ne_zero _ (Nat.factorial_ne_zero ν)
  have hne : Dlcm m * 4 ^ ν * (Nat.factorial ν) ^ 2 ≠ 0 :=
    mul_ne_zero (mul_ne_zero (Dlcm_ne_zero m) h4ne) hfacne
  rw [← Nat.factorization_le_iff_dvd (Nat.factorial_ne_zero _) hne]
  refine Finsupp.le_def.2 fun p => ?_
  by_cases hp : p.Prime
  · -- Legendre's formula
    set b := Nat.log p (2 * ν + 1) + 1 with hb
    have hlt1 : Nat.log p (2 * ν + 1) < b := by omega
    have hlt2 : Nat.log p ν < b := by
      have : Nat.log p ν ≤ Nat.log p (2 * ν + 1) := Nat.log_mono_right (by omega)
      omega
    have hL1 : (Nat.factorial (2 * ν + 1)).factorization p
        = ∑ i ∈ Finset.Ico 1 b, (2 * ν + 1) / p ^ i :=
      Nat.factorization_factorial hp hlt1
    have hL2 : (Nat.factorial ν).factorization p = ∑ i ∈ Finset.Ico 1 b, ν / p ^ i :=
      Nat.factorization_factorial hp hlt2
    have hsum : ∑ i ∈ Finset.Ico 1 b, (2 * ν + 1) / p ^ i
        ≤ ∑ i ∈ Finset.Ico 1 b, (2 * (ν / p ^ i) + 1) :=
      Finset.sum_le_sum fun i _ => div_two_mul_add_one_le ν (p ^ i) (pow_pos hp.pos i)
    have hcard : ∑ i ∈ Finset.Ico 1 b, (2 * (ν / p ^ i) + 1)
        = 2 * (∑ i ∈ Finset.Ico 1 b, ν / p ^ i) + Nat.log p (2 * ν + 1) := by
      rw [Finset.sum_add_distrib, ← Finset.mul_sum]
      simp [hb]
    -- the least common multiple absorbs the extra `log p (2ν+1)`
    have hlog : Nat.log p (2 * ν + 1) ≤ (Dlcm m).factorization p := by
      rw [← Nat.Prime.pow_dvd_iff_le_factorization hp (Dlcm_ne_zero m)]
      refine dvd_Dlcm (Nat.one_le_pow _ _ hp.pos) ?_
      calc p ^ Nat.log p (2 * ν + 1) ≤ 2 * ν + 1 := Nat.pow_log_le_self p (by omega)
        _ ≤ m := hm
    have hfact : (Dlcm m * 4 ^ ν * (Nat.factorial ν) ^ 2).factorization p
        = (Dlcm m).factorization p + (4 ^ ν).factorization p
          + 2 * (Nat.factorial ν).factorization p := by
      rw [Nat.factorization_mul (mul_ne_zero (Dlcm_ne_zero m) h4ne) hfacne,
        Nat.factorization_mul (Dlcm_ne_zero m) h4ne]
      simp [Nat.factorization_pow, two_mul]
    rw [hL1, hfact, hL2]
    have hstep : ∑ i ∈ Finset.Ico 1 b, (2 * ν + 1) / p ^ i
        ≤ 2 * (∑ i ∈ Finset.Ico 1 b, ν / p ^ i) + Nat.log p (2 * ν + 1) := hcard ▸ hsum
    omega
  · simp [Nat.factorization_eq_zero_of_not_prime _ hp]

end FactorialDivisibility

section Pochhammer

/-- `(3/2)_ν = (2ν+1)! / (4^ν ν!)`. -/
theorem pochhammer_three_halves (ν : ℕ) :
    ((ascPochhammer ℚ ν).eval (3 / 2 : ℚ))
      = (Nat.factorial (2 * ν + 1) : ℚ) / (4 ^ ν * Nat.factorial ν) := by
  induction ν with
  | zero => simp
  | succ k ih =>
      have hk : (Nat.factorial k : ℚ) ≠ 0 := by exact_mod_cast Nat.factorial_ne_zero k
      rw [ascPochhammer_succ_eval, ih]
      have h1 : Nat.factorial (2 * (k + 1) + 1)
          = (2 * k + 3) * ((2 * k + 2) * Nat.factorial (2 * k + 1)) := by
        have h : 2 * (k + 1) + 1 = (2 * k + 1) + 1 + 1 := by ring
        rw [h, Nat.factorial_succ, Nat.factorial_succ]
      have h2 : Nat.factorial (k + 1) = (k + 1) * Nat.factorial k := Nat.factorial_succ k
      rw [h1, h2]
      push_cast
      field_simp
      ring

/-- The clearing statement of Lemma 3.2: `D_m · ν!/(3/2)_ν` is an integer whenever
`2ν+1 ≤ m`. -/
theorem Dlcm_mul_hyper_isInt (m ν : ℕ) (hm : 2 * ν + 1 ≤ m) :
    ∃ k : ℤ, (Dlcm m : ℚ) * ((Nat.factorial ν : ℚ) / ((ascPochhammer ℚ ν).eval (3 / 2 : ℚ)))
      = (k : ℚ) := by
  obtain ⟨c, hc⟩ := factorial_dvd_Dlcm_mul m ν hm
  refine ⟨(c : ℤ), ?_⟩
  have hfac : ((Nat.factorial (2 * ν + 1) : ℚ)) ≠ 0 := by
    exact_mod_cast Nat.factorial_ne_zero _
  have hnu : ((Nat.factorial ν : ℚ)) ≠ 0 := by exact_mod_cast Nat.factorial_ne_zero _
  have hcast : ((Dlcm m : ℚ)) * 4 ^ ν * (Nat.factorial ν : ℚ) ^ 2
      = (Nat.factorial (2 * ν + 1) : ℚ) * (c : ℚ) := by
    exact_mod_cast congrArg (fun t : ℕ => (t : ℚ)) hc
  rw [pochhammer_three_halves]
  field_simp
  linear_combination hcast

end Pochhammer

section Denominators

/-- **Lemma 3.1 (denominator step).**  If `2^a x` is an integer and `2^b d x` is an integer
for some *odd* `d`, then `2^(min a b) x` is an integer. -/
theorem two_power_denominator (x : ℚ) (a b d : ℕ) (hd : Odd d)
    (h1 : ∃ k : ℤ, (2 : ℚ) ^ a * x = (k : ℚ))
    (h2 : ∃ k : ℤ, (2 : ℚ) ^ b * (d : ℚ) * x = (k : ℚ)) :
    ∃ k : ℤ, (2 : ℚ) ^ (min a b) * x = (k : ℚ) := by
  rcases le_total a b with hab | hab
  · rw [min_eq_left hab]; exact h1
  · rw [min_eq_right hab]
    obtain ⟨K₁, hK₁⟩ := h1
    obtain ⟨K₂, hK₂⟩ := h2
    have hpow : (2 : ℚ) ^ (a - b) * (2 : ℚ) ^ b = 2 ^ a := by
      rw [← pow_add, show a - b + b = a by omega]
    -- `d * K₁ = 2^(a-b) * K₂`
    have hkey : (d : ℤ) * K₁ = 2 ^ (a - b) * K₂ := by
      have hq : ((d : ℤ) * K₁ : ℚ) = ((2 ^ (a - b) * K₂ : ℤ) : ℚ) := by
        push_cast
        rw [← hK₁, ← hK₂, ← hpow]
        ring
      exact_mod_cast hq
    have hcop : IsCoprime ((2 : ℤ) ^ (a - b)) (d : ℤ) := by
      refine IsCoprime.pow_left ?_
      rw [show ((2 : ℤ)) = ((2 : ℕ) : ℤ) by norm_num, Int.isCoprime_iff_gcd_eq_one,
        Int.gcd_natCast_natCast]
      exact Nat.coprime_two_left.mpr hd
    have hdvd : (2 : ℤ) ^ (a - b) ∣ K₁ := hcop.dvd_of_dvd_mul_left ⟨K₂, hkey⟩
    obtain ⟨K, hK⟩ := hdvd
    refine ⟨K, ?_⟩
    have h2b : ((2 : ℚ) ^ (a - b)) ≠ 0 := by positivity
    refine mul_left_cancel₀ h2b ?_
    rw [← mul_assoc, hpow, hK₁, hK]
    push_cast
    ring

end Denominators

end CatalanLCM
