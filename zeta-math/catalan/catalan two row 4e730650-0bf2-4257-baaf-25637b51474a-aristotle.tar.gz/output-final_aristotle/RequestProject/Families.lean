import RequestProject.Bridge
import RequestProject.Certificate

/-!
# The twelve families as genuine `q`-expansions

For each row of the table of eta parametrisations this file introduces the
honest power series

* `tPS r`  — the eta quotient `t = ∏_d η(dτ)^{e_d}`,
* `FPS r`  — the eta quotient `F`,
* `EPS r`  — the Eisenstein series of the source table,

and converts the finite checks of `RequestProject/Certificate.lean` (which are
statements about the *truncated* model) into statements about the Fourier
coefficients of these power series, using the correctness proofs of
`RequestProject/Bridge.lean`.

Together with `RequestProject/ModularInput.lean` this closes every gap in the
paper's argument except the two classical modular inputs themselves (Ligozat's
criterion and Sturm's theorem), which remain explicit hypotheses.
-/

set_option maxHeartbeats 1000000

namespace Eisenstein
namespace Families

open QS Certificate Bridge PowerSeries

/-! ### Cancelling `t` from an identity of `q`-expansions -/

/-- If `u` has invertible constant term and the coefficients of `u * D` vanish
below `m`, then so do those of `D`. -/
lemma coeff_eq_zero_of_mul_unit {u D : PowerSeries ℚ} (hu : constantCoeff u = 1) {m : ℕ}
    (h : ∀ i < m, coeff i (u * D) = 0) : ∀ i < m, coeff i D = 0 := by
  intro i
  induction i using Nat.strong_induction_on with
  | _ i IH =>
    intro hi
    have hcm := h i hi
    rw [PowerSeries.coeff_mul, Finset.Nat.sum_antidiagonal_eq_sum_range_succ_mk,
      Finset.sum_range_succ'] at hcm
    have hzero : ∀ j ∈ Finset.range i, coeff (j + 1) u * coeff (i - (j + 1)) D = 0 := by
      intro j hj
      rw [Finset.mem_range] at hj
      rw [IH (i - (j + 1)) (by omega) (by omega), mul_zero]
    rw [Finset.sum_eq_zero hzero, zero_add] at hcm
    simpa [PowerSeries.coeff_zero_eq_constantCoeff_apply, hu] using hcm

/-- Coefficients can be cancelled through multiplication by `X^k · u` with `u`
a unit: this is how the certificate's Wronskian identity (an identity for
`θ_q t = t·P·F²`) becomes the modular identity for `K = θ_q t / t`. -/
lemma coeff_eq_of_mul_shift_unit {u A B : PowerSeries ℚ} (hu : constantCoeff u = 1) {k m : ℕ}
    (h : ∀ i < m, coeff i (X ^ k * u * A) = coeff i (X ^ k * u * B)) :
    ∀ i < m - k, coeff i A = coeff i B := by
  have h1 : ∀ i < m, coeff i (X ^ k * (u * (A - B))) = 0 := by
    intro i hi
    have e : X ^ k * (u * (A - B)) = X ^ k * u * A - X ^ k * u * B := by ring
    rw [e, map_sub, h i hi, sub_self]
  have h2 : ∀ i < m - k, coeff i (u * (A - B)) = 0 := by
    intro i hi
    have := h1 (i + k) (by omega)
    rwa [mul_comm, PowerSeries.coeff_mul_X_pow', if_pos (by omega),
      Nat.add_sub_cancel] at this
  intro i hi
  have := coeff_eq_zero_of_mul_unit hu h2 i hi
  rw [map_sub] at this
  linarith [sub_eq_zero.mp this]

/-! ### The power series attached to a row -/

variable (r : EtaRow)

/-- The eta quotient `t` of the row, as a power series. -/
noncomputable def tPS : PowerSeries ℚ := etaQPS r.tExp

/-- The eta quotient `F` of the row, as a power series. -/
noncomputable def FPS : PowerSeries ℚ := etaQPS r.fExp

/-- The Eisenstein series of the source table, as a power series. -/
noncomputable def EPS : PowerSeries ℚ := eisPS r.eis

/-- `P₂(t) = 1 - a t + c t²` for the row. -/
noncomputable def P2PS : PowerSeries ℚ := Modular.P2 (r.a : ℚ) (r.c : ℚ) (tPS r)

/-- `P₃(t) = 1 - 2a t + c t²` for the row. -/
noncomputable def P3PS : PowerSeries ℚ := Modular.P3 (r.a : ℚ) (r.c : ℚ) (tPS r)

/-- `H₂` for the row. -/
noncomputable def H2PS : PowerSeries ℚ :=
  Modular.H2 (r.a : ℚ) (r.b : ℚ) (r.c : ℚ) (tPS r) (FPS r)

/-- `H₃` for the row. -/
noncomputable def H3PS : PowerSeries ℚ :=
  Modular.H3 (r.b : ℚ) (r.c : ℚ) (tPS r) (FPS r)

/-! ### The certificate, transported to the power series -/

lemma pos_of_ligozat {N : ℕ} {exps : List (ℕ × ℤ)} (h : QS.ligozat N exps = true) :
    ∀ de ∈ exps, 0 < de.1 := by
  rw [QS.ligozat, Bool.and_eq_true, Bool.and_eq_true] at h
  intro de hde
  have := (List.all_eq_true.mp h.1.1) de hde
  simp only [Bool.and_eq_true, decide_eq_true_eq] at this
  exact this.1

/-- The hypotheses on a row that are needed to identify the truncated
computation with the power series: the eta exponents are indexed by positive
divisors, `t` has `q`-order one and `F` has non-negative `q`-order. -/
structure Good (r : EtaRow) : Prop where
  ligozat : r.ligozatOK = true
  ordT : QS.etaOrd r.tExp = 1
  ordF : 0 ≤ QS.etaOrd r.fExp

namespace Good

variable {r : EtaRow} (hr : Good r)
include hr

lemma posT : ∀ de ∈ r.tExp, 0 < de.1 := by
  have h := hr.ligozat
  rw [EtaRow.ligozatOK, Bool.and_eq_true] at h
  exact pos_of_ligozat h.1

lemma posF : ∀ de ∈ r.fExp, 0 < de.1 := by
  have h := hr.ligozat
  rw [EtaRow.ligozatOK, Bool.and_eq_true] at h
  exact pos_of_ligozat h.2

lemma approx_t : Approx prec r.tSer (tPS r) :=
  approx_etaQ prec r.tExp hr.posT (by rw [hr.ordT]; norm_num)

lemma approx_F : Approx prec r.fSer (FPS r) :=
  approx_etaQ prec r.fExp hr.posF hr.ordF

/-- `t = q · (unit)`. -/
lemma tPS_eq : tPS r = X * etaUnitPS r.tExp := by
  rw [tPS, etaQPS, hr.ordT]
  norm_num

lemma constantCoeff_unit : constantCoeff (etaUnitPS r.tExp) = 1 :=
  constantCoeff_etaUnitPS r.tExp hr.posT

lemma approx_p2 : Approx prec r.p2 (P2PS r) := by
  have h := approx_sub (approx_add (approx_one prec)
      (approx_smul r.c (approx_mul hr.approx_t hr.approx_t))) (approx_smul r.a hr.approx_t)
  have e : (1 + C ((r.c : ℤ) : ℚ) * (tPS r * tPS r) - C ((r.a : ℤ) : ℚ) * tPS r) = P2PS r := by
    rw [P2PS, Modular.P2]; ring
  rwa [e] at h

lemma approx_p3 : Approx prec r.p3 (P3PS r) := by
  have h := approx_sub (approx_add (approx_one prec)
      (approx_smul r.c (approx_mul hr.approx_t hr.approx_t))) (approx_smul (2 * r.a) hr.approx_t)
  have e : (1 + C ((r.c : ℤ) : ℚ) * (tPS r * tPS r) - C (((2 * r.a : ℤ)) : ℚ) * tPS r)
      = P3PS r := by
    rw [P3PS, Modular.P3]
    push_cast
    ring
  rwa [e] at h

lemma approx_h2 : Approx prec r.h2 (H2PS r) := by
  have h := approx_add
    (approx_sub (approx_mul hr.approx_F (approx_theta (approx_theta hr.approx_F)))
      (approx_smul 2 (approx_mul (approx_theta hr.approx_F) (approx_theta hr.approx_F))))
    (approx_mul (approx_mul hr.approx_t
        (approx_add (approx_const prec (-r.b)) (approx_smul r.c hr.approx_t)))
      (approx_mul hr.approx_p2 (approx_npow hr.approx_F 6)))
  have e : (FPS r * Modular.theta (Modular.theta (FPS r))
        - C ((2 : ℤ) : ℚ) * (Modular.theta (FPS r) * Modular.theta (FPS r))
      + tPS r * (C (((-r.b : ℤ)) : ℚ) + C ((r.c : ℤ) : ℚ) * tPS r) * (P2PS r * FPS r ^ 6))
      = H2PS r := by
    rw [H2PS, Modular.H2, P2PS]
    push_cast
    simp only [map_ofNat, map_neg]
    ring
  rwa [e] at h

lemma approx_h3 : Approx prec r.h3 (H3PS r) := by
  have h := approx_add
    (approx_sub (approx_smul 2 (approx_mul hr.approx_F (approx_theta (approx_theta hr.approx_F))))
      (approx_smul 3 (approx_mul (approx_theta hr.approx_F) (approx_theta hr.approx_F))))
    (approx_mul (approx_mul hr.approx_t
        (approx_add (approx_const prec (-2 * r.b)) (approx_smul r.c hr.approx_t)))
      (approx_npow hr.approx_F 4))
  have e : (C ((2 : ℤ) : ℚ) * (FPS r * Modular.theta (Modular.theta (FPS r)))
        - C ((3 : ℤ) : ℚ) * (Modular.theta (FPS r) * Modular.theta (FPS r))
      + tPS r * (C (((-2 * r.b : ℤ)) : ℚ) + C ((r.c : ℤ) : ℚ) * tPS r) * FPS r ^ 4)
      = H3PS r := by
    rw [H3PS, Modular.H3]
    push_cast
    simp only [map_ofNat, map_neg, map_mul]
    ring
  rwa [e] at h

end Good

/-! ### The finite checks as statements about Fourier coefficients -/

namespace Good

variable {r : EtaRow} (hr : Good r)
include hr

/-- The Wronskian identity of the certificate, transported: with `K` defined by
`θ_q t = K t`, the coefficients of `K` and of `P₂(t)F²` agree below `63`. -/
lemma coeff_wronskian_R2 (hc : r.wronskian2OK = true) (K : PowerSeries ℚ)
    (hKt : Modular.theta (tPS r) = K * tPS r) :
    ∀ i < 63, coeff i K = coeff i (P2PS r * FPS r ^ 2) := by
  have h0 := coeff_eq_of_eqUpTo (approx_theta hr.approx_t)
    (approx_mul hr.approx_t (approx_mul hr.approx_p2 (approx_npow hr.approx_F 2)))
    (le_refl cmp) hc
  have h1 : ∀ i < 64, PowerSeries.coeff i (X ^ 1 * etaUnitPS r.tExp * K)
      = PowerSeries.coeff i (X ^ 1 * etaUnitPS r.tExp * (P2PS r * FPS r ^ 2)) := by
    intro i hi
    have := h0 i hi
    rw [hKt] at this
    rw [show X ^ 1 * etaUnitPS r.tExp * K = K * tPS r by rw [hr.tPS_eq]; ring,
      show X ^ 1 * etaUnitPS r.tExp * (P2PS r * FPS r ^ 2)
        = tPS r * (P2PS r * FPS r ^ 2) by rw [hr.tPS_eq]; ring]
    exact this
  exact coeff_eq_of_mul_shift_unit hr.constantCoeff_unit h1

/-- The Wronskian identity of the certificate for a third-order row. -/
lemma coeff_wronskian_R3 (hc : r.wronskian3OK = true) (K : PowerSeries ℚ)
    (hKt : Modular.theta (tPS r) = K * tPS r) :
    ∀ i < 62, coeff i (K ^ 2) = coeff i (P3PS r * FPS r ^ 2) := by
  have h0 := coeff_eq_of_eqUpTo (approx_npow (approx_theta hr.approx_t) 2)
    (approx_mul (approx_npow hr.approx_t 2) (approx_mul hr.approx_p3 (approx_npow hr.approx_F 2)))
    (le_refl cmp) hc
  have hu : constantCoeff (etaUnitPS r.tExp ^ 2) = 1 := by
    rw [map_pow, hr.constantCoeff_unit, one_pow]
  have h1 : ∀ i < 64, PowerSeries.coeff i (X ^ 2 * etaUnitPS r.tExp ^ 2 * K ^ 2)
      = PowerSeries.coeff i (X ^ 2 * etaUnitPS r.tExp ^ 2 * (P3PS r * FPS r ^ 2)) := by
    intro i hi
    have := h0 i hi
    rw [hKt] at this
    rw [show X ^ 2 * etaUnitPS r.tExp ^ 2 * K ^ 2 = (K * tPS r) ^ 2 by rw [hr.tPS_eq]; ring,
      show X ^ 2 * etaUnitPS r.tExp ^ 2 * (P3PS r * FPS r ^ 2)
        = tPS r ^ 2 * (P3PS r * FPS r ^ 2) by rw [hr.tPS_eq]; ring]
    exact this
  exact coeff_eq_of_mul_shift_unit hu h1

/-- The ODE identity of the certificate, transported. -/
lemma coeff_ode_R2 (hc : r.ode2OK = true) : ∀ i < 64, coeff i (H2PS r) = 0 :=
  coeff_eq_zero_of_isZeroUpTo hr.approx_h2 (le_refl cmp) hc

/-- The ODE identity of the certificate for a third-order row. -/
lemma coeff_ode_R3 (hc : r.ode3OK = true) : ∀ i < 64, coeff i (H3PS r) = 0 :=
  coeff_eq_zero_of_isZeroUpTo hr.approx_h3 (le_refl cmp) hc

/-- The source identity of the certificate, transported. -/
lemma coeff_source (hc : r.sourceOK = true) :
    ∀ i < 64, coeff i (FPS r * Modular.theta (tPS r)) = coeff i (EPS r) :=
  coeff_eq_of_eqUpTo (approx_mul hr.approx_F (approx_theta hr.approx_t))
    (approx_eisSeries prec r.eis) (le_refl cmp) hc

end Good

/-! ### The Eisenstein-source theorem for a row, from Ligozat + Sturm

The theorems below are the paper's argument, complete except for the two
classical modular inputs.  Everything computational is discharged by the
certificate; what remains as hypotheses is exactly:

* `S : Modular.SturmSetup` — Sturm's theorem with an effective bound;
* `hK`, `hPF`, `hH`, `hFt`, `hE` — Ligozat's criterion: the listed
  `q`-expansions are those of holomorphic modular forms of the stated weights
  (for `P_r(t)F²` and `F θ_q t` this uses the cusp-order computation, i.e. the
  cancellation `ord F = -ord t` at the poles of `t`, which the certificate
  verifies numerically);
* `hE` — the Eisenstein series of the source table is a holomorphic form of the
  same weight.
-/

namespace Good

variable {r : EtaRow} (hr : Good r)
include hr

/-- **The Wronskian identity `K = P₂(t)F²`** for a second-order row. -/
theorem wronskian_eq_R2 (hcert : r.certR2 = true) (S : Modular.SturmSetup)
    (hb : S.bound 2 < 63) (K : PowerSeries ℚ) (hKt : Modular.theta (tPS r) = K * tPS r)
    (hK : S.IsMF 2 K) (hPF : S.IsMF 2 (P2PS r * FPS r ^ 2)) :
    K = P2PS r * FPS r ^ 2 := by
  rw [EtaRow.certR2] at hcert
  simp only [Bool.and_eq_true] at hcert
  exact S.eq_of_coeff_eq 2 _ _ hK hPF
    (fun i hi => hr.coeff_wronskian_R2 hcert.1.1.2 K hKt i (by omega))

/-- **The Wronskian identity `K² = P₃(t)F²`** for a third-order row. -/
theorem wronskian_eq_R3 (hcert : r.certR3 = true) (S : Modular.SturmSetup)
    (hb : S.bound 4 < 62) (K : PowerSeries ℚ) (hKt : Modular.theta (tPS r) = K * tPS r)
    (hK : S.IsMF 4 (K ^ 2)) (hPF : S.IsMF 4 (P3PS r * FPS r ^ 2)) :
    K ^ 2 = P3PS r * FPS r ^ 2 := by
  rw [EtaRow.certR3] at hcert
  simp only [Bool.and_eq_true] at hcert
  exact S.eq_of_coeff_eq 4 _ _ hK hPF
    (fun i hi => hr.coeff_wronskian_R3 hcert.1.1.2 K hKt i (by omega))

/-- **The ODE identity `H₂ = 0`** for a second-order row. -/
theorem ode_eq_zero_R2 (hcert : r.certR2 = true) (S : Modular.SturmSetup)
    (hb : S.bound 6 < 64) (hH : S.IsMF 6 (H2PS r)) : H2PS r = 0 := by
  rw [EtaRow.certR2] at hcert
  simp only [Bool.and_eq_true] at hcert
  exact S.sturm 6 _ hH (fun i hi => hr.coeff_ode_R2 hcert.1.2 i (by omega))

/-- **The ODE identity `H₃ = 0`** for a third-order row. -/
theorem ode_eq_zero_R3 (hcert : r.certR3 = true) (S : Modular.SturmSetup)
    (hb : S.bound 8 < 64) (hH : S.IsMF 8 (H3PS r)) : H3PS r = 0 := by
  rw [EtaRow.certR3] at hcert
  simp only [Bool.and_eq_true] at hcert
  exact S.sturm 8 _ hH (fun i hi => hr.coeff_ode_R3 hcert.1.2 i (by omega))

/-- **The source identity `F θ_q t = E`** for a row. -/
theorem source_eq (hcert : r.sourceOK = true) (S : Modular.SturmSetup) (w : ℤ)
    (hb : S.bound w < 64) (hFt : S.IsMF w (FPS r * Modular.theta (tPS r)))
    (hE : S.IsMF w (EPS r)) :
    FPS r * Modular.theta (tPS r) = EPS r :=
  S.eq_of_coeff_eq w _ _ hFt hE (fun i hi => hr.coeff_source hcert i (by omega))

/-- **The Eisenstein-source theorem for a second-order row**: the normalised
companion source is the Eisenstein series of the source table. -/
theorem source_eq_eisenstein_R2 {R : Type*} [Field R] (ι : PowerSeries ℚ →+* R)
    (hcert : r.certR2 = true) (S : Modular.SturmSetup) (w : ℤ)
    (hb2 : S.bound 2 < 63) (hbw : S.bound w < 64)
    (K : PowerSeries ℚ) (hKt : Modular.theta (tPS r) = K * tPS r)
    (hK : S.IsMF 2 K) (hPF : S.IsMF 2 (P2PS r * FPS r ^ 2))
    (hFt : S.IsMF w (FPS r * Modular.theta (tPS r))) (hE : S.IsMF w (EPS r))
    (hFne : ι (FPS r) ≠ 0) (hPne : ι (P2PS r) ≠ 0)
    (Phi : R) (hPhi : Phi = ι (tPS r) * ι K ^ 2 / (ι (P2PS r) * ι (FPS r))) :
    Phi = ι (EPS r) := by
  have hw := hr.wronskian_eq_R2 hcert S hb2 K hKt hK hPF
  have hs : FPS r * Modular.theta (tPS r) = EPS r := by
    rw [EtaRow.certR2] at hcert
    simp only [Bool.and_eq_true] at hcert
    exact hr.source_eq hcert.2 S w hbw hFt hE
  have hcol : Phi = ι (FPS r) * (ι K * ι (tPS r)) := by
    refine collapse_R2 (ι (tPS r)) (ι (FPS r)) (ι K) (ι (P2PS r)) Phi hFne hPne ?_ hPhi
    rw [hw, map_mul, map_pow]
  rw [hcol, ← hs, map_mul, hKt, map_mul]

/-- **The Eisenstein-source theorem for a third-order row.** -/
theorem source_eq_eisenstein_R3 {R : Type*} [Field R] (ι : PowerSeries ℚ →+* R)
    (hcert : r.certR3 = true) (S : Modular.SturmSetup) (w : ℤ)
    (hb4 : S.bound 4 < 62) (hbw : S.bound w < 64)
    (K : PowerSeries ℚ) (hKt : Modular.theta (tPS r) = K * tPS r)
    (hK : S.IsMF 4 (K ^ 2)) (hPF : S.IsMF 4 (P3PS r * FPS r ^ 2))
    (hFt : S.IsMF w (FPS r * Modular.theta (tPS r))) (hE : S.IsMF w (EPS r))
    (hFne : ι (FPS r) ≠ 0) (hPne : ι (P3PS r) ≠ 0)
    (Phi : R) (hPhi : Phi = ι (tPS r) * ι K ^ 3 / (ι (P3PS r) * ι (FPS r))) :
    Phi = ι (EPS r) := by
  have hw := hr.wronskian_eq_R3 hcert S hb4 K hKt hK hPF
  have hs : FPS r * Modular.theta (tPS r) = EPS r := by
    rw [EtaRow.certR3] at hcert
    simp only [Bool.and_eq_true] at hcert
    exact hr.source_eq hcert.2 S w hbw hFt hE
  have hcol : Phi = ι (FPS r) * (ι K * ι (tPS r)) := by
    refine collapse_R3 (ι (tPS r)) (ι (FPS r)) (ι K) (ι (P3PS r)) Phi hFne hPne ?_ hPhi
    rw [← map_pow, hw, map_mul, map_pow]
  rw [hcol, ← hs, map_mul, hKt, map_mul]

end Good

/-! ### The eleven eta rows satisfy the hypotheses -/

lemma good_rowA : Good rowA := ⟨by decide, by decide, by decide⟩
lemma good_rowB : Good rowB := ⟨by decide, by decide, by decide⟩
lemma good_rowC : Good rowC := ⟨by decide, by decide, by decide⟩
lemma good_rowE : Good rowE := ⟨by decide, by decide, by decide⟩
lemma good_rowF : Good rowF := ⟨by decide, by decide, by decide⟩
lemma good_rowAlpha : Good rowAlpha := ⟨by decide, by decide, by decide⟩
lemma good_rowGamma : Good rowGamma := ⟨by decide, by decide, by decide⟩
lemma good_rowDelta : Good rowDelta := ⟨by decide, by decide, by decide⟩
lemma good_rowEpsilon : Good rowEpsilon := ⟨by decide, by decide, by decide⟩
lemma good_rowZeta : Good rowZeta := ⟨by decide, by decide, by decide⟩
lemma good_rowEta : Good rowEta := ⟨by decide, by decide, by decide⟩

/-- The five second-order eta rows, with their certificates. -/
lemma good_and_cert_R2 {r : EtaRow} (hr : r ∈ [rowA, rowB, rowC, rowE, rowF]) :
    Good r ∧ r.certR2 = true := by
  fin_cases hr
  exacts [⟨good_rowA, cert_A⟩, ⟨good_rowB, cert_B⟩, ⟨good_rowC, cert_C⟩,
    ⟨good_rowE, cert_E⟩, ⟨good_rowF, cert_F⟩]

/-- The six third-order eta rows, with their certificates. -/
lemma good_and_cert_R3 {r : EtaRow}
    (hr : r ∈ [rowAlpha, rowGamma, rowDelta, rowEpsilon, rowZeta, rowEta]) :
    Good r ∧ r.certR3 = true := by
  fin_cases hr
  exacts [⟨good_rowAlpha, cert_alpha⟩, ⟨good_rowGamma, cert_gamma⟩,
    ⟨good_rowDelta, cert_delta⟩, ⟨good_rowEpsilon, cert_epsilon⟩,
    ⟨good_rowZeta, cert_zeta⟩, ⟨good_rowEta, cert_eta⟩]

/-- **Eisenstein-source theorem for the five second-order eta families**
`A, B, C, E, F` (weight of `F θ_q t` equal to `3`), conditional only on the
classical modular input. -/
theorem source_eq_eisenstein_R2_of_mem {R : Type*} [Field R] (ι : PowerSeries ℚ →+* R)
    {r : EtaRow} (hr : r ∈ [rowA, rowB, rowC, rowE, rowF]) (S : Modular.SturmSetup)
    (hb2 : S.bound 2 < 63) (hb3 : S.bound 3 < 64)
    (K : PowerSeries ℚ) (hKt : Modular.theta (tPS r) = K * tPS r)
    (hK : S.IsMF 2 K) (hPF : S.IsMF 2 (P2PS r * FPS r ^ 2))
    (hFt : S.IsMF 3 (FPS r * Modular.theta (tPS r))) (hE : S.IsMF 3 (EPS r))
    (hFne : ι (FPS r) ≠ 0) (hPne : ι (P2PS r) ≠ 0)
    (Phi : R) (hPhi : Phi = ι (tPS r) * ι K ^ 2 / (ι (P2PS r) * ι (FPS r))) :
    Phi = ι (EPS r) :=
  (good_and_cert_R2 hr).1.source_eq_eisenstein_R2 ι (good_and_cert_R2 hr).2 S 3 hb2 hb3
    K hKt hK hPF hFt hE hFne hPne Phi hPhi

/-- **Eisenstein-source theorem for the six third-order eta families**
`α, γ, δ, ε, ζ, η` (weight of `F θ_q t` equal to `4`), conditional only on the
classical modular input. -/
theorem source_eq_eisenstein_R3_of_mem {R : Type*} [Field R] (ι : PowerSeries ℚ →+* R)
    {r : EtaRow} (hr : r ∈ [rowAlpha, rowGamma, rowDelta, rowEpsilon, rowZeta, rowEta])
    (S : Modular.SturmSetup) (hb4 : S.bound 4 < 62)
    (K : PowerSeries ℚ) (hKt : Modular.theta (tPS r) = K * tPS r)
    (hK : S.IsMF 4 (K ^ 2)) (hPF : S.IsMF 4 (P3PS r * FPS r ^ 2))
    (hFt : S.IsMF 4 (FPS r * Modular.theta (tPS r))) (hE : S.IsMF 4 (EPS r))
    (hFne : ι (FPS r) ≠ 0) (hPne : ι (P3PS r) ≠ 0)
    (Phi : R) (hPhi : Phi = ι (tPS r) * ι K ^ 3 / (ι (P3PS r) * ι (FPS r))) :
    Phi = ι (EPS r) :=
  (good_and_cert_R3 hr).1.source_eq_eisenstein_R3 ι (good_and_cert_R3 hr).2 S 4 hb4
    (by omega) K hKt hK hPF hFt hE hFne hPne Phi hPhi

end Families
end Eisenstein
