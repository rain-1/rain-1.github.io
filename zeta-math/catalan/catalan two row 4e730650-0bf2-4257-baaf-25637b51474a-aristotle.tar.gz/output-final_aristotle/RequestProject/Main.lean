import Mathlib
import RequestProject.AlgebraicCore
import RequestProject.Certificate
import RequestProject.Families
import RequestProject.DFamily

open scoped BigOperators
open scoped Real
open scoped Nat
open scoped Classical
open scoped Pointwise

set_option maxHeartbeats 8000000
set_option maxRecDepth 4000
set_option synthInstance.maxHeartbeats 20000
set_option synthInstance.maxSize 128

set_option relaxedAutoImplicit false
set_option autoImplicit false

set_option grind.warning false

/-!
# Eisenstein sources for the twelve modular sporadic Apéry companions

This file assembles the formalisation of the paper.  What is proved here, and
how it is split, is as follows.

## Fully formalised, unconditionally

* `Eisenstein.source_general`: with `C = P_r/K^r` and `Φ = tK^r/(P_rF)`, the
  rectified equation gives `L_r y_B = C F Φ = t`, i.e. `Φ` is the source of the
  normalised companion.
* `Eisenstein.collapse_R2`, `Eisenstein.collapse_R3`
  (*Proposition: collapse of the source*): in the canonical nome coordinate the
  companion source `Φ = t K^r/(P_r F)` equals `F · θ_q t`, for `r = 2` from the
  Wronskian relation `K = P₂F²`, and for `r = 3` from `K² = P₃F²`.
* `Eisenstein.L2_certificate`, `Eisenstein.L3_certificate` and their corollaries
  `Eisenstein.L2_solution`, `Eisenstein.L3_solution` (*Lemma: Wronskian–ODE
  certificate*): the exact differential-algebra identities
  `K³ L₂F = P₂² F H₂` and `u K³ (4 L̃u) = s³ H₃`, hence the vanishing of the
  Rankin–Cohen expressions `H₂`, `H₃` forces `L₂F = 0`, resp. `L̃u = 0`.
* `Eisenstein.D_square`: the `D`-family square identity `Φ² = t η₁⁹η₅³` from
  Zagier's parametrisation, together with the sign determination
  `Eisenstein.eq_of_sq_eq_sq_of_coeff_one` and the resulting
  `Eisenstein.D_source_eq_eisenstein`.
* `Eisenstein.Certificate.cert_A, …, cert_eta, cert_D` (*the exact
  certificate*): with exact integer arithmetic on truncated `q`-expansions,
  Ligozat's congruences, the normalisations `t = q+O(q²)`, `F = 1+O(q)`, the
  Wronskian identities, the ODE identities `H₂ = 0`/`H₃ = 0`, the source
  identities `F θ_q t = E`, and Ligozat's cusp orders (the pole table of `t`,
  the holomorphy of `F` at every cusp, and the cancellation
  `ord F = -ord t` at every pole of `t`) are verified through `q^63` for the eleven eta
  families, and Zagier's relation, the Wronskian and ODE identities, the square
  identity `Φ² = t η₁⁹η₅³` and `E_D² = t η₁⁹η₅³` are verified through `q^61`
  for the `D` family.  These bounds exceed every Sturm bound of the paper (the
  largest of which is `36`).
* `Eisenstein.source_eq_eisenstein_R2`, `Eisenstein.source_eq_eisenstein_R3`:
  the resulting form of the main theorem — once the source identity
  `F θ_q t = E` is known, the normalised companion source `Φ` *is* the
  Eisenstein series `E`.

## Not formalised (classical input used by the paper)

The two ingredients that convert the finite computations into identities of
modular forms are used as classical black boxes and are *not* formalised:
Ligozat's criterion (that the displayed eta quotients are modular of the stated
weight, level, character and cusp orders) and Sturm's theorem (that a
holomorphic modular form vanishing to sufficiently high order vanishes).
Mathlib does not currently contain either statement in the required generality.
Consequently the modular hypotheses appear explicitly as hypotheses in
`source_eq_eisenstein_R2` / `source_eq_eisenstein_R3` rather than being
discharged.
-/

namespace Eisenstein

section MainTheorem

variable {R : Type*} [Field R]

/-- **Eisenstein-source theorem, second-order families** (`A`, `B`, `C`, `D`,
`E`, `F`).  Let `t` be the canonical coordinate, `K = θ_q t / t`, `F` the
analytic solution pulled back to the nome, `P₂` the leading polynomial, and let
`Φ = t K²/(P₂F)` be the source of the normalised companion.  Given the
Wronskian relation `K = P₂F²` and the Eisenstein source identity
`F θ_q t = E` (the identity certified by Sturm's theorem), the source is the
Eisenstein series: `Φ = E`. -/
theorem source_eq_eisenstein_R2 (D : R → R) (t F K P Phi E : R)
    (hF : F ≠ 0) (hP : P ≠ 0)
    (hK : K = P * F ^ 2)
    (hDt : D t = K * t)
    (hPhi : Phi = t * K ^ 2 / (P * F))
    (hE : F * D t = E) :
    Phi = E := by
  rw [collapse_R2 t F K P Phi hF hP hK hPhi, ← hE, hDt]

/-- **Eisenstein-source theorem, third-order families** (`α`, `γ`, `δ`, `ε`,
`ζ`, `η`).  Same statement with `Φ = t K³/(P₃F)` and the Wronskian relation
`K² = P₃F²`. -/
theorem source_eq_eisenstein_R3 (D : R → R) (t F K P Phi E : R)
    (hF : F ≠ 0) (hP : P ≠ 0)
    (hK : K ^ 2 = P * F ^ 2)
    (hDt : D t = K * t)
    (hPhi : Phi = t * K ^ 3 / (P * F))
    (hE : F * D t = E) :
    Phi = E := by
  rw [collapse_R3 t F K P Phi hF hP hK hPhi, ← hE, hDt]

/-- **Eisenstein-source theorem, the `D` family.**  If the source `Φ` and the
weight-three Eisenstein series `E_D` have equal squares (the identity certified
through the weight-six square identity `Φ² = t η₁⁹η₅³ = E_D²`) and both begin
with `q`, then `Φ = E_D`. -/
theorem D_source_eq_eisenstein (Phi ED : PowerSeries ℚ)
    (hsq : Phi ^ 2 = ED ^ 2)
    (hPhi : PowerSeries.coeff 1 Phi = 1) (hED : PowerSeries.coeff 1 ED = 1) :
    Phi = ED :=
  eq_of_sq_eq_sq_of_coeff_one Phi ED hsq hPhi hED

end MainTheorem

/-- **The exact certificate of the paper**, for all twelve families, verified
inside Lean with exact integer arithmetic on truncated `q`-expansions.  For the
eleven eta families this bundles Ligozat's congruences, the normalisations, the
Wronskian identity, the ODE identity and the source identity `F θ_q t = E`; for
the `D` family it bundles Zagier's relation `P(t) = tη₁⁶/η₅⁶`, the Wronskian and
ODE identities, the square identity `Φ² = tη₁⁹η₅³`, the Eisenstein identity
`E_D² = tη₁⁹η₅³` and the leading-coefficient normalisation fixing the sign. -/
theorem finite_certificate :
    Certificate.rowA.certR2 = true ∧
    Certificate.rowB.certR2 = true ∧
    Certificate.rowC.certR2 = true ∧
    Certificate.rowE.certR2 = true ∧
    Certificate.rowF.certR2 = true ∧
    Certificate.rowAlpha.certR3 = true ∧
    Certificate.rowGamma.certR3 = true ∧
    Certificate.rowDelta.certR3 = true ∧
    Certificate.rowEpsilon.certR3 = true ∧
    Certificate.rowZeta.certR3 = true ∧
    Certificate.rowEta.certR3 = true ∧
    Certificate.D.certD = true :=
  ⟨Certificate.cert_A, Certificate.cert_B, Certificate.cert_C, Certificate.cert_E,
    Certificate.cert_F, Certificate.cert_alpha, Certificate.cert_gamma,
    Certificate.cert_delta, Certificate.cert_epsilon, Certificate.cert_zeta,
    Certificate.cert_eta, Certificate.D.cert_D⟩

/-! ## The twelve families, conditional on Ligozat's criterion and Sturm's theorem

* `Eisenstein.Families.source_eq_eisenstein_R2_of_mem` — families
  `A, B, C, E, F`;
* `Eisenstein.Families.source_eq_eisenstein_R3_of_mem` — families
  `α, γ, δ, ε, ζ, η`;
* `Eisenstein.DFamily.source_eq_eisenstein` — the family `D` on `Γ₁(5)`.

Together with `Eisenstein.Families.Good.wronskian_eq_R2`,
`Eisenstein.Families.Good.wronskian_eq_R3`,
`Eisenstein.Families.Good.ode_eq_zero_R2`,
`Eisenstein.Families.Good.ode_eq_zero_R3` and
`Eisenstein.Families.Good.source_eq`, these are the twelve cases of the main
theorem of the paper. -/

end Eisenstein
