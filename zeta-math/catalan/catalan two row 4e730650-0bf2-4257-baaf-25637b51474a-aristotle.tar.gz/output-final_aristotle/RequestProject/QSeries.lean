import Mathlib

/-!
# Truncated `q`-expansions with exact integer arithmetic

A tiny library of truncated power series over `ℤ`, used to run the *finite*
checks of the paper (the Ligozat congruences and the Wronskian, ODE and source
identities through their Sturm bounds) inside Lean, with exact arithmetic.

A series is stored as an `Array ℤ` of coefficients `a₀, a₁, …, a_{n-1}`
representing `a₀ + a₁ q + ⋯ + a_{n-1} q^{n-1} + O(q^n)`; the truncation order
`n` is passed explicitly to every operation.  All operations preserve validity
up to order `n`, except `shiftDown k` (division by `q^k`), which is valid only
up to order `n - k`; the certificate file therefore always compares
coefficients strictly below the internal precision.
-/

namespace Eisenstein
namespace QS

/-- A truncated `q`-expansion: the array of its first coefficients. -/
abbrev S : Type := Array ℤ

/-- Coefficient of `q^i`; out of range it is `0`. -/
def coeff (a : S) (i : ℕ) : ℤ := a.getD i 0

/-- Build the truncation of order `n` of the series with coefficients `f`. -/
def mk (n : ℕ) (f : ℕ → ℤ) : S := ((List.range n).map f).toArray

/-- The constant series `1`. -/
def one (n : ℕ) : S := mk n fun i => if i = 0 then 1 else 0

/-- The constant series `k`. -/
def const (n : ℕ) (k : ℤ) : S := mk n fun i => if i = 0 then k else 0

def add (n : ℕ) (a b : S) : S := mk n fun i => coeff a i + coeff b i

def sub (n : ℕ) (a b : S) : S := mk n fun i => coeff a i - coeff b i

def smul (n : ℕ) (k : ℤ) (a : S) : S := mk n fun i => k * coeff a i

def mul (n : ℕ) (a b : S) : S :=
  mk n fun i => ∑ j ∈ Finset.range (i + 1), coeff a j * coeff b (i - j)

/-- Multiplication by `q^k`. -/
def shift (n k : ℕ) (a : S) : S := mk n fun i => if i < k then 0 else coeff a (i - k)

/-- Division by `q^k` (only meaningful when the first `k` coefficients vanish);
the result is valid only up to order `n - k`. -/
def shiftDown (n k : ℕ) (a : S) : S := mk n fun i => coeff a (i + k)

/-- The Euler operator `θ_q = q d/dq`. -/
def theta (n : ℕ) (a : S) : S := mk n fun i => (i : ℤ) * coeff a i

/-- The array `[b₀, …, b_i]` of the first coefficients of the inverse of a
series with constant coefficient `1`, built by the usual recursion
`b_{i+1} = -∑_{j=0}^{i} a_{j+1} b_{i-j}`. -/
def invArr (a : S) : ℕ → Array ℤ
  | 0 => #[1]
  | (i + 1) =>
      let prev := invArr a i
      prev.push (-∑ j ∈ Finset.range (i + 1), coeff a (j + 1) * prev.getD (i - j) 0)

/-- Inverse of a series with constant coefficient `1`. -/
def inv (n : ℕ) (a : S) : S := if n = 0 then #[] else invArr a (n - 1)

def npow (n : ℕ) (a : S) : ℕ → S
  | 0 => one n
  | k + 1 => mul n (npow n a k) a

/-- Integer power; negative exponents use `inv`. -/
def zpow (n : ℕ) (a : S) (e : ℤ) : S :=
  if 0 ≤ e then npow n a e.toNat else inv n (npow n a (-e).toNat)

/-- Equality of the coefficients of `q^i` for all `i < m`. -/
def eqUpTo (m : ℕ) (a b : S) : Bool := (List.range m).all fun i => coeff a i == coeff b i

/-- Vanishing of the coefficients of `q^i` for all `i < m`. -/
def isZeroUpTo (m : ℕ) (a : S) : Bool := (List.range m).all fun i => coeff a i == 0

/-! ### Eta products -/

/-- One step of the eta product: `r ↦ r · (1 - q^{d m})`, truncated. -/
def etaStep (n d : ℕ) (r : S) (m : ℕ) : S :=
  if d * m < n then sub n r (shift n (d * m) r) else r

/-- The truncation of `∏_{m ≥ 1} (1 - q^{d m})`, i.e. of `q^{-d/24} η(dτ)`. -/
def etaFactor (n d : ℕ) : S := (List.range' 1 n).foldl (etaStep n d) (one n)

/-- The unit part `∏_{d} (q^{-d/24} η(dτ))^{e_d}` of an eta quotient
`∏_d η(dτ)^{e_d}`, described by the list of pairs `(d, e_d)`. -/
def etaUnit (n : ℕ) (exps : List (ℕ × ℤ)) : S :=
  exps.foldl (fun acc de => mul n acc (zpow n (etaFactor n de.1) de.2)) (one n)

/-- The `q`-order `(∑_d d e_d)/24` of the eta quotient. -/
def etaOrd (exps : List (ℕ × ℤ)) : ℤ := (exps.map fun de => (de.1 : ℤ) * de.2).sum / 24

/-- The truncated `q`-expansion of the eta quotient `∏_d η(dτ)^{e_d}`. -/
def etaQ (n : ℕ) (exps : List (ℕ × ℤ)) : S :=
  let k := etaOrd exps
  if 0 ≤ k then shift n k.toNat (etaUnit n exps) else shiftDown n (-k).toNat (etaUnit n exps)

/-- Ligozat's two congruences `∑ d e_d ≡ ∑ (N/d) e_d ≡ 0 (mod 24)`, together
with the requirement that every `d` occurring divides the level `N`. -/
def ligozat (N : ℕ) (exps : List (ℕ × ℤ)) : Bool :=
  (exps.all fun de => 0 < de.1 && N % de.1 == 0) &&
  ((exps.map fun de => (de.1 : ℤ) * de.2).sum % 24 == 0) &&
  ((exps.map fun de => ((N / de.1 : ℕ) : ℤ) * de.2).sum % 24 == 0)

/-! ### Divisor sums and Dirichlet characters -/

def divisorsList (m : ℕ) : List ℕ := (List.range (m + 1)).filter fun d => 0 < d && m % d == 0

/-- `σ_k(m) = ∑_{d ∣ m} d^k`. -/
def sigmaK (k m : ℕ) : ℤ := ((divisorsList m).map fun d => (d : ℤ) ^ k).sum

/-- `σ̃_χ^{(k)}(m) = ∑_{d ∣ m} χ(d) d^k`. -/
def sigmaOut (chi : ℕ → ℤ) (k m : ℕ) : ℤ :=
  ((divisorsList m).map fun d => chi d * (d : ℤ) ^ k).sum

/-- `σ_χ^{(k)}(m) = ∑_{d ∣ m} χ(m/d) d^k`. -/
def sigmaIn (chi : ℕ → ℤ) (k m : ℕ) : ℤ :=
  ((divisorsList m).map fun d => chi (m / d) * (d : ℤ) ^ k).sum

/-- `f(m/r)`, understood as `0` unless `r ∣ m`. -/
def scaled (f : ℕ → ℤ) (r m : ℕ) : ℤ := if m % r = 0 then f (m / r) else 0

/-- The odd quadratic character modulo `3`. -/
def chiM3 (n : ℕ) : ℤ := if n % 3 == 1 then 1 else if n % 3 == 2 then -1 else 0

/-- The odd quadratic character modulo `4`. -/
def chiM4 (n : ℕ) : ℤ := if n % 4 == 1 then 1 else if n % 4 == 3 then -1 else 0

/-- The even quadratic character modulo `5`. -/
def chi5 (n : ℕ) : ℤ :=
  if n % 5 == 1 || n % 5 == 4 then 1 else if n % 5 == 2 || n % 5 == 3 then -1 else 0

/-- `ψ₁ - 2ψ₂` for the quartic character `χ` modulo `5` with `χ(2) = i`,
where `ψ₁ = Re χ` and `ψ₂ = Im χ`. -/
def psiD (n : ℕ) : ℤ :=
  if n % 5 == 1 then 1 else if n % 5 == 2 then -2
  else if n % 5 == 3 then 2 else if n % 5 == 4 then -1 else 0

/-- The series `∑_{m ≥ 1} c(m) q^m`. -/
def eisSeries (n : ℕ) (c : ℕ → ℤ) : S := mk n fun m => if m = 0 then 0 else c m

end QS
end Eisenstein
