import Mathlib
import RequestProject.QSeries
import RequestProject.ModularInput

/-!
# From the truncated certificate to genuine `q`-expansions

`RequestProject/QSeries.lean` computes with truncated `q`-expansions stored as
arrays of integers, and `RequestProject/Certificate.lean` runs all the finite
checks of the paper in that model.  This file proves that model *correct*:
every operation of the truncated library agrees, up to the truncation order,
with the corresponding operation on honest formal power series over `ℚ`.

The central notion is `Approx n a f`: the array `a` gives the first `n` Fourier
coefficients of the power series `f`.
-/

namespace Eisenstein
namespace Bridge

open QS PowerSeries

/-- `Approx n a f`: the truncated series `a` represents the first `n`
coefficients of the power series `f`. -/
def Approx (n : ℕ) (a : S) (f : PowerSeries ℚ) : Prop :=
  ∀ i < n, ((QS.coeff a i : ℤ) : ℚ) = coeff i f

lemma coeff_mk (n i : ℕ) (f : ℕ → ℤ) :
    QS.coeff (QS.mk n f) i = if i < n then f i else 0 := by
  unfold QS.coeff QS.mk
  by_cases h : i < n <;> simp [Array.getD, h]

lemma coeff_mk_of_lt {n i : ℕ} (h : i < n) (f : ℕ → ℤ) :
    QS.coeff (QS.mk n f) i = f i := by
  simp [coeff_mk, h]

lemma Approx.mono {n m : ℕ} {a : S} {f : PowerSeries ℚ} (h : Approx n a f) (hm : m ≤ n) :
    Approx m a f := fun i hi => h i (lt_of_lt_of_le hi hm)

/-! ### The ring operations -/

lemma approx_one (n : ℕ) : Approx n (QS.one n) 1 := by
  intro i hi
  simp [QS.one, coeff_mk_of_lt hi, PowerSeries.coeff_one]

lemma approx_const (n : ℕ) (k : ℤ) : Approx n (QS.const n k) (C (k : ℚ)) := by
  intro i hi
  rw [QS.const, coeff_mk_of_lt hi, PowerSeries.coeff_C]
  by_cases h : i = 0 <;> simp [h]

lemma approx_add {n : ℕ} {a b : S} {f g : PowerSeries ℚ}
    (ha : Approx n a f) (hb : Approx n b g) : Approx n (QS.add n a b) (f + g) := by
  intro i hi
  simp [QS.add, coeff_mk_of_lt hi, ha i hi, hb i hi]

lemma approx_sub {n : ℕ} {a b : S} {f g : PowerSeries ℚ}
    (ha : Approx n a f) (hb : Approx n b g) : Approx n (QS.sub n a b) (f - g) := by
  intro i hi
  simp [QS.sub, coeff_mk_of_lt hi, ha i hi, hb i hi]

lemma approx_smul {n : ℕ} {a : S} {f : PowerSeries ℚ} (k : ℤ)
    (ha : Approx n a f) : Approx n (QS.smul n k a) (C (k : ℚ) * f) := by
  intro i hi
  rw [QS.smul, coeff_mk_of_lt hi, PowerSeries.coeff_C_mul, ← ha i hi]
  push_cast
  ring

lemma approx_mul {n : ℕ} {a b : S} {f g : PowerSeries ℚ}
    (ha : Approx n a f) (hb : Approx n b g) : Approx n (QS.mul n a b) (f * g) := by
  intro i hi
  rw [QS.mul, coeff_mk_of_lt hi, PowerSeries.coeff_mul,
    Finset.Nat.sum_antidiagonal_eq_sum_range_succ_mk]
  push_cast
  refine Finset.sum_congr rfl fun j hj => ?_
  rw [Finset.mem_range] at hj
  rw [ha j (lt_of_lt_of_le (Nat.lt_succ_iff.mp hj |>.trans_lt (Nat.lt_succ_self i)) hi),
    hb (i - j) (lt_of_le_of_lt (Nat.sub_le _ _) hi)]

lemma approx_theta {n : ℕ} {a : S} {f : PowerSeries ℚ} (ha : Approx n a f) :
    Approx n (QS.theta n a) (Modular.theta f) := by
  intro i hi
  simp [QS.theta, coeff_mk_of_lt hi, ha i hi]

lemma approx_npow {n : ℕ} {a : S} {f : PowerSeries ℚ} (ha : Approx n a f) :
    ∀ k, Approx n (QS.npow n a k) (f ^ k)
  | 0 => by simpa [QS.npow] using approx_one n
  | (k + 1) => by
      simpa [QS.npow, pow_succ] using approx_mul (approx_npow ha k) ha

lemma approx_shift {n k : ℕ} {a : S} {f : PowerSeries ℚ} (ha : Approx n a f) :
    Approx n (QS.shift n k a) (X ^ k * f) := by
  intro i hi
  rw [QS.shift, coeff_mk_of_lt hi]
  by_cases h : i < k
  · simp only [h, if_pos]
    rw [PowerSeries.coeff_X_pow_mul']
    simp [Nat.not_le.mpr h]
  · simp only [h, if_false]
    rw [PowerSeries.coeff_X_pow_mul']
    simp only [Nat.not_lt] at h
    simp only [h, if_pos]
    exact ha (i - k) (lt_of_le_of_lt (Nat.sub_le _ _) hi)


/-! ### Series inversion -/

lemma getD_push_lt (a : Array ℤ) (x : ℤ) (k : ℕ) (h : k < a.size) :
    (a.push x).getD k 0 = a.getD k 0 := by
  simp [Array.getD, h, Array.getElem_push_lt h, Nat.not_lt.mpr h.le]

lemma getD_push_eq (a : Array ℤ) (x : ℤ) : (a.push x).getD a.size 0 = x := by
  simp [Array.getD]

lemma size_invArr (a : S) : ∀ i, (QS.invArr a i).size = i + 1
  | 0 => rfl
  | (i + 1) => by simp [QS.invArr, size_invArr a i]

/-- The `i`-th coefficient of the inverse series computed by `QS.invArr`. -/
def binv (a : S) (i : ℕ) : ℤ := (QS.invArr a i).getD i 0

lemma invArr_getD (a : S) : ∀ j k, k ≤ j → (QS.invArr a j).getD k 0 = binv a k
  | 0, k, hk => by
      interval_cases k
      rfl
  | (j + 1), k, hk => by
      rcases Nat.lt_or_ge k (j + 1) with h | h
      · have hs : k < (QS.invArr a j).size := by rw [size_invArr]; exact h
        rw [QS.invArr, getD_push_lt _ _ _ hs, invArr_getD a j k (Nat.lt_succ_iff.mp h)]
      · have hk' : k = j + 1 := le_antisymm hk h
        subst hk'
        rfl

lemma binv_zero (a : S) : binv a 0 = 1 := rfl

lemma binv_succ (a : S) (i : ℕ) :
    binv a (i + 1) = -∑ j ∈ Finset.range (i + 1), QS.coeff a (j + 1) * binv a (i - j) := by
  have h : binv a (i + 1) = -∑ j ∈ Finset.range (i + 1), QS.coeff a (j + 1) *
      (QS.invArr a i).getD (i - j) 0 := by
    show (QS.invArr a (i + 1)).getD (i + 1) 0 = _
    rw [QS.invArr, show i + 1 = (QS.invArr a i).size by rw [size_invArr], getD_push_eq,
      size_invArr]
  rw [h]
  congr 1
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [invArr_getD a i (i - j) (Nat.sub_le _ _)]

lemma coeff_inv_eq_binv {n : ℕ} (a : S) {i : ℕ} (hi : i < n) :
    QS.coeff (QS.inv n a) i = binv a i := by
  have hn : n ≠ 0 := by omega
  rw [QS.inv, if_neg hn]
  exact invArr_getD a (n - 1) i (by omega)

lemma approx_inv {n : ℕ} {a : S} {f : PowerSeries ℚ} (ha : Approx n a f)
    (hcf : constantCoeff f = 1) : Approx n (QS.inv n a) f⁻¹ := by
  have key : ∀ i, i < n → ((binv a i : ℤ) : ℚ) = coeff i f⁻¹ := by
    intro i
    induction i using Nat.strong_induction_on with
    | _ i IH =>
      intro hi
      match i with
      | 0 => simp [binv_zero, PowerSeries.coeff_inv, hcf]
      | (m + 1) =>
        rw [PowerSeries.coeff_inv]
        simp only [Nat.succ_ne_zero, if_false, hcf, inv_one, neg_mul, one_mul]
        rw [Finset.Nat.sum_antidiagonal_eq_sum_range_succ_mk, Finset.sum_range_succ']
        norm_num
        rw [binv_succ]
        push_cast
        rw [neg_inj]
        refine Finset.sum_congr rfl fun j hj => ?_
        rw [Finset.mem_range] at hj
        have hij : m - j = m + 1 - (j + 1) := by omega
        rw [hij, ← ha (j + 1) (by omega), ← IH (m + 1 - (j + 1)) (by omega) (by omega)]
  intro i hi
  rw [coeff_inv_eq_binv a hi]
  exact key i hi

/-! ### Division by `q`, integer powers, Eisenstein series -/

lemma approx_shiftDown {n k : ℕ} {a : S} {g : PowerSeries ℚ} (ha : Approx n a (X ^ k * g)) :
    Approx (n - k) (QS.shiftDown n k a) g := by
  intro i hi
  have hik : i + k < n := by omega
  rw [QS.shiftDown, coeff_mk_of_lt (by omega), ha (i + k) hik, mul_comm,
    PowerSeries.coeff_mul_X_pow']
  simp

/-- Integer powers of a power series with invertible constant term. -/
noncomputable def zpowPS (f : PowerSeries ℚ) (e : ℤ) : PowerSeries ℚ :=
  if 0 ≤ e then f ^ e.toNat else (f ^ (-e).toNat)⁻¹

lemma approx_zpow {n : ℕ} {a : S} {f : PowerSeries ℚ} (ha : Approx n a f)
    (hcf : constantCoeff f = 1) (e : ℤ) : Approx n (QS.zpow n a e) (zpowPS f e) := by
  rw [QS.zpow, zpowPS]
  split
  · exact approx_npow ha _
  · exact approx_inv (approx_npow ha _) (by simp [hcf])

/-- The series `∑_{m ≥ 1} c(m) q^m`. -/
noncomputable def eisPS (c : ℕ → ℤ) : PowerSeries ℚ :=
  PowerSeries.mk fun m => if m = 0 then 0 else ((c m : ℤ) : ℚ)

lemma approx_eisSeries (n : ℕ) (c : ℕ → ℤ) : Approx n (QS.eisSeries n c) (eisPS c) := by
  intro i hi
  rw [QS.eisSeries, coeff_mk_of_lt hi, eisPS, PowerSeries.coeff_mk]
  split <;> simp

/-! ### Eta products -/

/-- The partial product `∏_{m=1}^{N} (1 - q^{d m})`. -/
noncomputable def etaPartial (d N : ℕ) : PowerSeries ℚ :=
  ((List.range' 1 N).map fun m => (1 - (X : PowerSeries ℚ) ^ (d * m))).prod

/-- The eta product `∏_{m ≥ 1} (1 - q^{d m})`, i.e. `q^{-d/24} η(dτ)`, defined
as the (coefficientwise stable) limit of its partial products. -/
noncomputable def etaFactorPS (d : ℕ) : PowerSeries ℚ :=
  PowerSeries.mk fun i => coeff i (etaPartial d (i + 1))

lemma etaPartial_zero (d : ℕ) : etaPartial d 0 = 1 := rfl

lemma etaPartial_succ (d N : ℕ) :
    etaPartial d (N + 1) = etaPartial d N * (1 - X ^ (d * (1 + N))) := by
  rw [etaPartial, etaPartial, List.range'_1_concat]
  simp

/-- Multiplying by `1 - q^k` does not change the coefficients below `k`. -/
lemma coeff_mul_one_sub_X_pow {i k : ℕ} (h : i < k) (f : PowerSeries ℚ) :
    coeff i (f * (1 - X ^ k)) = coeff i f := by
  rw [mul_sub, mul_one, map_sub, PowerSeries.coeff_mul_X_pow']
  simp [Nat.not_le.mpr h]

lemma coeff_etaPartial_stable (d : ℕ) (hd : 0 < d) (i : ℕ) :
    ∀ N, i < N → coeff i (etaPartial d N) = coeff i (etaPartial d (i + 1))
  | 0, h => by omega
  | (N + 1), h => by
      rcases Nat.lt_or_ge i N with h' | h'
      · rw [etaPartial_succ, coeff_mul_one_sub_X_pow (by nlinarith),
          coeff_etaPartial_stable d hd i N h']
      · have : N + 1 = i + 1 := by omega
        rw [this]

lemma coeff_etaFactorPS (d : ℕ) (hd : 0 < d) {i N : ℕ} (h : i < N) :
    coeff i (etaFactorPS d) = coeff i (etaPartial d N) := by
  rw [etaFactorPS, PowerSeries.coeff_mk, coeff_etaPartial_stable d hd i N h]

lemma constantCoeff_etaFactorPS (d : ℕ) (hd : 0 < d) : constantCoeff (etaFactorPS d) = 1 := by
  have := coeff_etaFactorPS d hd (i := 0) (N := 1) (by omega)
  rw [← PowerSeries.coeff_zero_eq_constantCoeff_apply, this,
    etaPartial_succ, etaPartial_zero, one_mul, map_sub]
  simp [PowerSeries.coeff_one, PowerSeries.coeff_X_pow]
  omega

lemma approx_etaStep {n d m : ℕ} {r : S} {g : PowerSeries ℚ} (hr : Approx n r g) :
    Approx n (QS.etaStep n d r m) (g * (1 - X ^ (d * m))) := by
  rw [QS.etaStep]
  split
  · have := approx_sub hr (approx_shift (k := d * m) hr)
    intro i hi
    rw [this i hi, mul_sub, mul_one, map_sub, map_sub]
    ring_nf
  · intro i hi
    rw [coeff_mul_one_sub_X_pow (by omega), hr i hi]

lemma approx_etaFold (n d : ℕ) :
    ∀ N, Approx n ((List.range' 1 N).foldl (QS.etaStep n d) (QS.one n)) (etaPartial d N)
  | 0 => by simpa [etaPartial_zero] using approx_one n
  | (N + 1) => by
      rw [List.range'_1_concat, List.foldl_concat, etaPartial_succ]
      exact approx_etaStep (approx_etaFold n d N)

lemma approx_etaFactor (n d : ℕ) (hd : 0 < d) : Approx n (QS.etaFactor n d) (etaFactorPS d) := by
  intro i hi
  rw [QS.etaFactor, approx_etaFold n d n i hi, coeff_etaFactorPS d hd hi]

/-! ### Eta quotients -/

lemma constantCoeff_zpowPS {f : PowerSeries ℚ} (hcf : constantCoeff f = 1) (e : ℤ) :
    constantCoeff (zpowPS f e) = 1 := by
  rw [zpowPS]
  split <;> simp [PowerSeries.constantCoeff_inv, hcf]

/-- The unit part `∏_d (q^{-d/24} η(dτ))^{e_d}` of an eta quotient. -/
noncomputable def etaUnitPS (exps : List (ℕ × ℤ)) : PowerSeries ℚ :=
  exps.foldl (fun acc de => acc * zpowPS (etaFactorPS de.1) de.2) 1

lemma approx_etaUnit_aux (n : ℕ) : ∀ (exps : List (ℕ × ℤ)), (∀ de ∈ exps, 0 < de.1) →
    ∀ (r : S) (g : PowerSeries ℚ), Approx n r g →
      Approx n (exps.foldl (fun acc de => QS.mul n acc (QS.zpow n (QS.etaFactor n de.1) de.2)) r)
        (exps.foldl (fun acc de => acc * zpowPS (etaFactorPS de.1) de.2) g)
  | [], _, r, g, hr => hr
  | (de :: l), hpos, r, g, hr => by
      refine approx_etaUnit_aux n l (fun x hx => hpos x (List.mem_cons_of_mem _ hx)) _ _ ?_
      have hd : 0 < de.1 := hpos de List.mem_cons_self
      exact approx_mul hr (approx_zpow (approx_etaFactor n de.1 hd)
        (constantCoeff_etaFactorPS de.1 hd) de.2)

lemma approx_etaUnit (n : ℕ) (exps : List (ℕ × ℤ)) (hpos : ∀ de ∈ exps, 0 < de.1) :
    Approx n (QS.etaUnit n exps) (etaUnitPS exps) :=
  approx_etaUnit_aux n exps hpos _ _ (approx_one n)

lemma constantCoeff_etaUnitPS_aux : ∀ (exps : List (ℕ × ℤ)), (∀ de ∈ exps, 0 < de.1) →
    ∀ g : PowerSeries ℚ, constantCoeff g = 1 →
      constantCoeff (exps.foldl (fun acc de => acc * zpowPS (etaFactorPS de.1) de.2) g) = 1
  | [], _, g, hg => hg
  | (de :: l), hpos, g, hg => by
      refine constantCoeff_etaUnitPS_aux l (fun x hx => hpos x (List.mem_cons_of_mem _ hx)) _ ?_
      have hd : 0 < de.1 := hpos de List.mem_cons_self
      rw [map_mul, hg, one_mul, constantCoeff_zpowPS (constantCoeff_etaFactorPS de.1 hd)]

lemma constantCoeff_etaUnitPS (exps : List (ℕ × ℤ)) (hpos : ∀ de ∈ exps, 0 < de.1) :
    constantCoeff (etaUnitPS exps) = 1 :=
  constantCoeff_etaUnitPS_aux exps hpos 1 (by simp)

/-- The eta quotient `∏_d η(dτ)^{e_d}`, in the case of non-negative `q`-order. -/
noncomputable def etaQPS (exps : List (ℕ × ℤ)) : PowerSeries ℚ :=
  X ^ (QS.etaOrd exps).toNat * etaUnitPS exps

lemma approx_etaQ (n : ℕ) (exps : List (ℕ × ℤ)) (hpos : ∀ de ∈ exps, 0 < de.1)
    (hord : 0 ≤ QS.etaOrd exps) : Approx n (QS.etaQ n exps) (etaQPS exps) := by
  rw [QS.etaQ, etaQPS, if_pos hord]
  exact approx_shift (approx_etaUnit n exps hpos)

/-! ### Transporting the finite checks -/

lemma coeff_eq_of_eqUpTo {m n : ℕ} {a b : S} {f g : PowerSeries ℚ}
    (ha : Approx n a f) (hb : Approx n b g) (hmn : m ≤ n)
    (h : QS.eqUpTo m a b = true) : ∀ i < m, coeff i f = coeff i g := by
  intro i hi
  rw [← ha i (lt_of_lt_of_le hi hmn), ← hb i (lt_of_lt_of_le hi hmn)]
  rw [QS.eqUpTo, List.all_eq_true] at h
  have := h i (List.mem_range.mpr hi)
  simpa using this

lemma coeff_eq_zero_of_isZeroUpTo {m n : ℕ} {a : S} {f : PowerSeries ℚ}
    (ha : Approx n a f) (hmn : m ≤ n)
    (h : QS.isZeroUpTo m a = true) : ∀ i < m, coeff i f = 0 := by
  intro i hi
  rw [← ha i (lt_of_lt_of_le hi hmn)]
  rw [QS.isZeroUpTo, List.all_eq_true] at h
  have := h i (List.mem_range.mpr hi)
  simpa using this

/-! ### Series congruent to `1` modulo `q^n`

This is what is needed for the infinite product of Zagier's parametrisation of
the `D` family, whose factors carry negative exponents. -/

lemma coeff_mul_eq_zero_of_coeff_eq_zero {i : ℕ} {A B : PowerSeries ℚ}
    (hB : ∀ j ≤ i, coeff j B = 0) : coeff i (A * B) = 0 := by
  rw [PowerSeries.coeff_mul]
  refine Finset.sum_eq_zero fun p hp => ?_
  rw [Finset.mem_antidiagonal] at hp
  rw [hB p.2 (by omega), mul_zero]

/-- `CongrOne n h` says that `h ≡ 1 (mod q^n)`. -/
def CongrOne (n : ℕ) (h : PowerSeries ℚ) : Prop := ∀ i < n, coeff i (h - 1) = 0

lemma CongrOne.coeff_mul {n : ℕ} {h : PowerSeries ℚ} (hh : CongrOne n h) (g : PowerSeries ℚ) :
    ∀ i < n, coeff i (g * h) = coeff i g := by
  intro i hi
  have e : g * h - g = g * (h - 1) := by ring
  have : coeff i (g * h - g) = 0 := by
    rw [e]
    exact coeff_mul_eq_zero_of_coeff_eq_zero (fun j hj => hh j (by omega))
  rw [map_sub] at this
  linarith [sub_eq_zero.mp this]

lemma CongrOne.one (n : ℕ) : CongrOne n 1 := by intro i _; simp

lemma CongrOne.mul {n : ℕ} {h₁ h₂ : PowerSeries ℚ} (h1 : CongrOne n h₁) (h2 : CongrOne n h₂) :
    CongrOne n (h₁ * h₂) := by
  intro i hi
  have e : h₁ * h₂ - 1 = h₁ * (h₂ - 1) + (h₁ - 1) := by ring
  rw [e, map_add, coeff_mul_eq_zero_of_coeff_eq_zero (fun j hj => h2 j (by omega)), h1 i hi,
    add_zero]

lemma CongrOne.pow {n : ℕ} {h : PowerSeries ℚ} (hh : CongrOne n h) : ∀ k, CongrOne n (h ^ k)
  | 0 => by simpa using CongrOne.one n
  | (k + 1) => by rw [pow_succ]; exact (CongrOne.pow hh k).mul hh

lemma CongrOne.constantCoeff {n : ℕ} {h : PowerSeries ℚ} (hh : CongrOne n h) (hn : 0 < n) :
    constantCoeff h = 1 := by
  have := hh 0 hn
  rw [map_sub] at this
  simpa [PowerSeries.coeff_zero_eq_constantCoeff_apply] using sub_eq_zero.mp this

lemma CongrOne.inv {n : ℕ} {h : PowerSeries ℚ} (hh : CongrOne n h) (hn : 0 < n) :
    CongrOne n h⁻¹ := by
  intro i hi
  have hc : PowerSeries.constantCoeff h = 1 := hh.constantCoeff hn
  have e : h⁻¹ - 1 = h⁻¹ * (1 - h) := by
    rw [mul_sub, mul_one, PowerSeries.inv_mul_cancel h (by rw [hc]; exact one_ne_zero)]
  rw [e]
  refine coeff_mul_eq_zero_of_coeff_eq_zero fun j hj => ?_
  have := hh j (by omega)
  rw [map_sub] at this ⊢
  linarith [sub_eq_zero.mp this]

lemma CongrOne.zpow {n : ℕ} {h : PowerSeries ℚ} (hh : CongrOne n h) (hn : 0 < n) (e : ℤ) :
    CongrOne n (zpowPS h e) := by
  rw [zpowPS]
  split
  · exact hh.pow _
  · exact (hh.pow _).inv hn

lemma congrOne_one_sub_X_pow (n : ℕ) : CongrOne n (1 - X ^ n) := by
  intro i hi
  rw [show (1 : PowerSeries ℚ) - X ^ n - 1 = -X ^ n by ring, map_neg, PowerSeries.coeff_X_pow]
  simp [Nat.ne_of_lt hi]

/-! ### Zagier's product for the `D` family -/

/-- The partial product `∏_{n=1}^{N} (1-q^n)^{5(n/5)}`. -/
noncomputable def zagierPartial (N : ℕ) : PowerSeries ℚ :=
  (List.range' 1 N).foldl (fun acc n => acc * zpowPS (1 - X ^ n) (5 * QS.chi5 n)) 1

/-- The unit part `∏_{n≥1} (1-q^n)^{5(n/5)}` of Zagier's `t`. -/
noncomputable def zagierUnitPS : PowerSeries ℚ :=
  PowerSeries.mk fun i => coeff i (zagierPartial i)

lemma zagierPartial_succ (N : ℕ) :
    zagierPartial (N + 1) = zagierPartial N * zpowPS (1 - X ^ (1 + N)) (5 * QS.chi5 (1 + N)) := by
  rw [zagierPartial, zagierPartial, List.range'_1_concat, List.foldl_concat]

lemma coeff_zagierPartial_stable (i : ℕ) :
    ∀ N, i ≤ N → coeff i (zagierPartial N) = coeff i (zagierPartial i)
  | 0, h => by
      have : i = 0 := by omega
      rw [this]
  | (N + 1), h => by
      rcases Nat.lt_or_ge i (N + 1) with h' | h'
      · rw [zagierPartial_succ,
          ((congrOne_one_sub_X_pow (1 + N)).zpow (by omega) _).coeff_mul _ i (by omega),
          coeff_zagierPartial_stable i N (by omega)]
      · have : N + 1 = i := by omega
        rw [this]

lemma coeff_zagierUnitPS {i N : ℕ} (h : i ≤ N) :
    coeff i zagierUnitPS = coeff i (zagierPartial N) := by
  rw [zagierUnitPS, PowerSeries.coeff_mk, coeff_zagierPartial_stable i N h]


end Bridge
end Eisenstein
