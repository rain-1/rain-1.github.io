import Mathlib

/-!
# Algebraic core of the Eisenstein-source theorem

This file formalises, unconditionally and in a purely algebraic setting, the
identities of the paper *Eisenstein Sources for the Twelve Modular Sporadic
Apéry Companions* that are statements of (differential) algebra:

* Proposition "collapse of the source": in the canonical nome coordinate the
  companion source `Φ = t K^r / (P_r F)` collapses to `Φ = F · θ_q t`, both for
  `r = 2` (using the Wronskian relation `K = P₂ F²`) and for `r = 3` (using
  `K² = P₃ F²`);
* the exact "Wronskian–ODE" identities behind the certificate Lemma:
  `K³ · L₂F = P₂² F · H₂` and `u · K³ · (4 · L̃u) = s³ · H₃`, which show that the
  vanishing of the Rankin–Cohen expressions `H₂`, `H₃` is *equivalent* to the
  differential equations `L₂F = 0`, `L̃u = 0`;
* the square identity `Φ² = t η₁⁹ η₅³` for the `D` family, deduced from Zagier's
  parametrisation.

Everything is proved from scratch; the derivation `D` (playing the role of
`θ_q = q d/dq`) is an arbitrary additive Leibniz operator on a commutative ring.
-/

set_option linter.unusedSectionVars false

namespace Eisenstein

/-! ## Elementary calculus for an abstract derivation -/

section Deriv

variable {R : Type*} [CommRing R] {D : R → R}
  (hadd : ∀ x y, D (x + y) = D x + D y)
  (hmul : ∀ x y, D (x * y) = x * D y + y * D x)

include hadd hmul

lemma D_zero : D 0 = 0 := by
  have h := hadd 0 0
  rw [add_zero] at h
  linear_combination -h

lemma D_one : D 1 = 0 := by
  have h := hmul 1 1
  simp only [one_mul] at h
  linear_combination -h

lemma D_neg (x : R) : D (-x) = -D x := by
  have h := hadd x (-x)
  rw [add_neg_cancel] at h
  linear_combination (D_zero hadd hmul) - h

lemma D_sub (x y : R) : D (x - y) = D x - D y := by
  rw [sub_eq_add_neg, hadd, D_neg hadd hmul]
  ring

lemma D_const_mul {a : R} (ha : D a = 0) (x : R) : D (a * x) = a * D x := by
  rw [hmul, ha]; ring

lemma D_sq (x : R) : D (x ^ 2) = 2 * x * D x := by
  have h := hmul x x
  rw [pow_two, h]; ring

lemma D_two : D (2 : R) = 0 := by
  rw [show (2 : R) = 1 + 1 by ring, hadd, D_one hadd hmul]; ring

end Deriv

/-! ## Proposition: collapse of the source

With `t` the canonical coordinate, `K = θ_q log t = (θ_q t)/t`, `F` the analytic
solution pulled back to the nome and `P_r` the leading polynomial, the general
formula for the source of the normalised companion is `Φ = t K^r / (P_r F)`.
The Wronskian relations collapse it to `Φ = F θ_q t = F · K · t`.
-/

section Collapse

variable {R : Type*} [Field R]

/-- **The source of the normalised companion.**  Exact rectification by the
canonical nome writes `L_r = C(t) F θ_q^r F^{-1}` with `C = P_r/K^r`, so the
normalised companion `y_B = F θ_q^{-r} Φ` satisfies
`L_r y_B = C F Φ`.  With `Φ = t K^r/(P_r F)` this is exactly `t`, i.e. `Φ` is
the source of the equation `L_r y_B = t`. -/
theorem source_general (r : ℕ) (t F K P C Phi : R) (hF : F ≠ 0) (hP : P ≠ 0) (hK : K ≠ 0)
    (hC : C = P / K ^ r) (hPhi : Phi = t * K ^ r / (P * F)) :
    C * F * Phi = t := by
  subst hC hPhi
  field_simp

/-- Collapse of the source for the second-order family (`r = 2`):
if `K = P₂ F²` then `Φ = t K² / (P₂ F)` equals `F · θ_q t = F · (K t)`. -/
theorem collapse_R2 (t F K P Phi : R) (hF : F ≠ 0) (hP : P ≠ 0)
    (hK : K = P * F ^ 2) (hPhi : Phi = t * K ^ 2 / (P * F)) :
    Phi = F * (K * t) := by
  subst hPhi hK
  rw [div_eq_iff (mul_ne_zero hP hF)]
  ring

/-- Collapse of the source for the third-order family (`r = 3`):
if `K² = P₃ F²` then `Φ = t K³ / (P₃ F)` equals `F · θ_q t = F · (K t)`. -/
theorem collapse_R3 (t F K P Phi : R) (hF : F ≠ 0) (hP : P ≠ 0)
    (hK : K ^ 2 = P * F ^ 2) (hPhi : Phi = t * K ^ 3 / (P * F)) :
    Phi = F * (K * t) := by
  subst hPhi
  rw [div_eq_iff (mul_ne_zero hP hF)]
  linear_combination (t * K) * hK

end Collapse

/-! ## The Wronskian–ODE certificate identities -/

section Certificate

variable {R : Type*} [CommRing R] {D : R → R}
  (hadd : ∀ x y, D (x + y) = D x + D y)
  (hmul : ∀ x y, D (x * y) = x * D y + y * D x)

include hadd hmul

/-- Expansion of `L₂` in terms of `θ_t`: the operator
`θ_t² - t(aθ_t² + aθ_t + b) + ct²(θ_t+1)²` applied to `F` is
`P₂ θ_t²F + t P₂' θ_t F + t(-b+ct) F`. -/
theorem L2_expand (t a b c F θ₁ θ₂ : R) :
    (θ₂ - t * (a * θ₂ + a * θ₁ + b * F) + c * t ^ 2 * (θ₂ + 2 * θ₁ + F))
      = (1 - a * t + c * t ^ 2) * θ₂ + (t * (-a + 2 * c * t)) * θ₁
        + t * (-b + c * t) * F := by
  ring

/-- Expansion of four times the Almkvist–Zudilin root operator
`L̃ = θ_t² - t(2aθ_t² + aθ_t + b/2) + ct²(θ_t + 1/2)²` applied to `u`:
`4L̃u = 4P₃ θ_t²u + 4t(-a+ct)θ_t u + t(-2b+ct) u`. -/
theorem L3root_expand (t a b c u θ₁ θ₂ : R) :
    (4 * θ₂ - t * (8 * a * θ₂ + 4 * a * θ₁ + 2 * b * u)
        + c * t ^ 2 * (4 * θ₂ + 4 * θ₁ + u))
      = 4 * (1 - 2 * a * t + c * t ^ 2) * θ₂
        + 4 * (t * (-a + c * t)) * θ₁ + t * (-2 * b + c * t) * u := by
  ring

/-- **Wronskian–ODE identity, order two.**
Let `θ₁ = θ_t F`, `θ₂ = θ_t² F` (encoded by `K θ₁ = D F`, `K θ₂ = D θ₁`), let
`t` satisfy `D t = K t` and let the Wronskian relation `K = P₂ F²` hold.  Then
`K³ · L₂F = P₂² · F · H₂`, where `H₂ = F D²F - 2 (DF)² + t(-b+ct) P₂ F⁶`. -/
theorem L2_certificate (t F K a b c θ₁ θ₂ : R)
    (ha : D a = 0) (hc : D c = 0)
    (hDt : D t = K * t)
    (hK : K = (1 - a * t + c * t ^ 2) * F ^ 2)
    (h1 : K * θ₁ = D F) (h2 : K * θ₂ = D θ₁) :
    K ^ 3 * ((1 - a * t + c * t ^ 2) * θ₂ + (t * (-a + 2 * c * t)) * θ₁
        + t * (-b + c * t) * F)
      = (1 - a * t + c * t ^ 2) ^ 2 * F
        * (F * D (D F) - 2 * (D F) ^ 2
            + t * (-b + c * t) * (1 - a * t + c * t ^ 2) * F ^ 6) := by
  subst hK
  -- derivative of the leading polynomial
  have hDP : D (1 - a * t + c * t ^ 2)
      = (t * (-a + 2 * c * t)) * ((1 - a * t + c * t ^ 2) * F ^ 2) := by
    rw [hadd, D_sub hadd hmul, D_one hadd hmul, D_const_mul hadd hmul ha,
      D_const_mul hadd hmul hc, D_sq hadd hmul, hDt]
    ring
  -- derivative of the Wronskian relation
  have hDK : D ((1 - a * t + c * t ^ 2) * F ^ 2)
      = (t * (-a + 2 * c * t)) * ((1 - a * t + c * t ^ 2) * F ^ 2) * F ^ 2
        + (1 - a * t + c * t ^ 2) * (2 * F * D F) := by
    rw [hmul, D_sq hadd hmul, hDP]; ring
  -- the two θ-derivatives
  have hKKθ₂ : ((1 - a * t + c * t ^ 2) * F ^ 2) ^ 2 * θ₂
      = D (D F) - θ₁ * D ((1 - a * t + c * t ^ 2) * F ^ 2) := by
    have hd := hmul ((1 - a * t + c * t ^ 2) * F ^ 2) θ₁
    rw [h1] at hd
    rw [show ((1 - a * t + c * t ^ 2) * F ^ 2) ^ 2 * θ₂
        = ((1 - a * t + c * t ^ 2) * F ^ 2) * (((1 - a * t + c * t ^ 2) * F ^ 2) * θ₂) by ring,
      h2]
    linear_combination -hd
  have hK3θ₂ : ((1 - a * t + c * t ^ 2) * F ^ 2) ^ 3 * θ₂
      = ((1 - a * t + c * t ^ 2) * F ^ 2) * D (D F)
        - D ((1 - a * t + c * t ^ 2) * F ^ 2) * D F := by
    rw [show ((1 - a * t + c * t ^ 2) * F ^ 2) ^ 3 * θ₂
        = ((1 - a * t + c * t ^ 2) * F ^ 2) * (((1 - a * t + c * t ^ 2) * F ^ 2) ^ 2 * θ₂) by ring,
      hKKθ₂]
    linear_combination (-(D ((1 - a * t + c * t ^ 2) * F ^ 2))) * h1
  have hK3θ₁ : ((1 - a * t + c * t ^ 2) * F ^ 2) ^ 3 * θ₁
      = ((1 - a * t + c * t ^ 2) * F ^ 2) ^ 2 * D F := by
    rw [show ((1 - a * t + c * t ^ 2) * F ^ 2) ^ 3 * θ₁
        = ((1 - a * t + c * t ^ 2) * F ^ 2) ^ 2 * (((1 - a * t + c * t ^ 2) * F ^ 2) * θ₁) by ring,
      h1]
  linear_combination (1 - a * t + c * t ^ 2) * hK3θ₂
    + (t * (-a + 2 * c * t)) * hK3θ₁
    - ((1 - a * t + c * t ^ 2) * D F) * hDK

/-- **Wronskian–ODE identity, order three.**
Let `u` be a square root of `F` (`F = u²`), let `s` be the branch of `√P₃`
appearing in the Wronskian relation `K = F s`, `s² = P₃`, let `θ₁ = θ_t u`,
`θ₂ = θ_t² u` and `D t = K t`.  Then `u · K³ · (4 L̃u) = s³ · H₃`, where
`H₃ = 2 F D²F - 3 (DF)² + t(-2b+ct) F⁴`. -/
theorem L3_certificate (t u F K s a b c θ₁ θ₂ : R)
    (ha : D a = 0) (hc : D c = 0)
    (hDt : D t = K * t)
    (hF : F = u ^ 2)
    (hs : s ^ 2 = 1 - 2 * a * t + c * t ^ 2)
    (hK : K = F * s)
    (h1 : K * θ₁ = D u) (h2 : K * θ₂ = D θ₁) :
    u * K ^ 3 * (4 * (1 - 2 * a * t + c * t ^ 2) * θ₂
        + 4 * (t * (-a + c * t)) * θ₁ + t * (-2 * b + c * t) * u)
      = s ^ 3 * (2 * F * D (D F) - 3 * (D F) ^ 2
          + t * (-2 * b + c * t) * F ^ 4) := by
  subst hF
  subst hK
  -- derivative of `s`, in a form not requiring division by `s`
  have hDs : 2 * s * D s = (2 * t * (-a + c * t)) * (u ^ 2 * s) := by
    have hss : D (s ^ 2) = 2 * s * D s := D_sq hadd hmul s
    have ha2 : D (2 * a) = 0 := by
      rw [hmul, D_two hadd hmul, ha]; ring
    rw [hs, hadd, D_sub hadd hmul, D_one hadd hmul,
      show (2 : R) * a * t = (2 * a) * t by ring,
      D_const_mul hadd hmul ha2, D_const_mul hadd hmul hc, D_sq hadd hmul, hDt] at hss
    rw [← hss]
    ring
  -- derivatives of `F = u²`
  have hDF : D (u ^ 2) = 2 * u * D u := D_sq hadd hmul u
  have hDDF : D (D (u ^ 2)) = 2 * ((D u) ^ 2 + u * D (D u)) := by
    rw [hDF, show (2 : R) * u * D u = 2 * (u * D u) by ring,
      D_const_mul hadd hmul (D_two hadd hmul), hmul]
    ring
  -- derivative of `K = u² s`
  have hDK : D (u ^ 2 * s) = s * (2 * u * D u) + u ^ 2 * D s := by
    rw [hmul, D_sq hadd hmul]; ring
  -- the two θ-derivatives
  have hKKθ₂ : (u ^ 2 * s) ^ 2 * θ₂ = D (D u) - θ₁ * (s * (2 * u * D u) + u ^ 2 * D s) := by
    have hd := hmul (u ^ 2 * s) θ₁
    rw [h1, hDK] at hd
    rw [show (u ^ 2 * s) ^ 2 * θ₂ = (u ^ 2 * s) * ((u ^ 2 * s) * θ₂) by ring, h2]
    linear_combination -hd
  have hK3θ₂ : (u ^ 2 * s) ^ 3 * θ₂
      = (u ^ 2 * s) * D (D u) - (s * (2 * u * D u) + u ^ 2 * D s) * D u := by
    rw [show (u ^ 2 * s) ^ 3 * θ₂ = (u ^ 2 * s) * ((u ^ 2 * s) ^ 2 * θ₂) by ring, hKKθ₂]
    linear_combination (-(s * (2 * u * D u) + u ^ 2 * D s)) * h1
  have hK3θ₁ : (u ^ 2 * s) ^ 3 * θ₁ = (u ^ 2 * s) ^ 2 * D u := by
    rw [show (u ^ 2 * s) ^ 3 * θ₁ = (u ^ 2 * s) ^ 2 * ((u ^ 2 * s) * θ₁) by ring, h1]
  rw [hDDF, hDF]
  linear_combination (4 * (1 - 2 * a * t + c * t ^ 2) * u) * hK3θ₂
    + (4 * (t * (-a + c * t)) * u) * hK3θ₁
    - (2 * s * u ^ 3 * D u) * hDs
    + (8 * u ^ 2 * s * (D u) ^ 2 - 4 * u ^ 3 * s * D (D u)
        + 4 * u ^ 3 * D u * D s) * hs

end Certificate


/-! ## Consequences: the certificate identities force the differential equations -/

section Consequences

variable {R : Type*} [Field R] {D : R → R}
  (hadd : ∀ x y, D (x + y) = D x + D y)
  (hmul : ∀ x y, D (x * y) = x * D y + y * D x)

include hadd hmul

/-- If the Wronskian relation `K = P₂F²` holds and the Rankin–Cohen expression
`H₂` vanishes, then `F` solves `L₂F = 0` (in the `θ_t`-expanded form). -/
theorem L2_solution (t F K a b c θ₁ θ₂ : R)
    (ha : D a = 0) (hc : D c = 0) (hK0 : K ≠ 0)
    (hDt : D t = K * t)
    (hK : K = (1 - a * t + c * t ^ 2) * F ^ 2)
    (h1 : K * θ₁ = D F) (h2 : K * θ₂ = D θ₁)
    (hH : F * D (D F) - 2 * (D F) ^ 2
        + t * (-b + c * t) * (1 - a * t + c * t ^ 2) * F ^ 6 = 0) :
    (1 - a * t + c * t ^ 2) * θ₂ + (t * (-a + 2 * c * t)) * θ₁
      + t * (-b + c * t) * F = 0 := by
  have hcert := L2_certificate hadd hmul t F K a b c θ₁ θ₂ ha hc hDt hK h1 h2
  rw [hH, mul_zero] at hcert
  exact (mul_eq_zero.mp hcert).resolve_left (pow_ne_zero 3 hK0)

/-- If the Wronskian relation `K² = P₃F²` holds (in the form `K = F s`,
`s² = P₃`) and the Rankin–Cohen expression `H₃` vanishes, then `u = √F` solves
the Almkvist–Zudilin root equation `L̃u = 0` (in the `θ_t`-expanded form,
multiplied by `4`). -/
theorem L3_solution (t u F K s a b c θ₁ θ₂ : R)
    (ha : D a = 0) (hc : D c = 0) (hK0 : K ≠ 0) (hu0 : u ≠ 0)
    (hDt : D t = K * t)
    (hF : F = u ^ 2)
    (hs : s ^ 2 = 1 - 2 * a * t + c * t ^ 2)
    (hK : K = F * s)
    (h1 : K * θ₁ = D u) (h2 : K * θ₂ = D θ₁)
    (hH : 2 * F * D (D F) - 3 * (D F) ^ 2 + t * (-2 * b + c * t) * F ^ 4 = 0) :
    4 * (1 - 2 * a * t + c * t ^ 2) * θ₂ + 4 * (t * (-a + c * t)) * θ₁
      + t * (-2 * b + c * t) * u = 0 := by
  have hcert := L3_certificate hadd hmul t u F K s a b c θ₁ θ₂ ha hc hDt hF hs hK h1 h2
  rw [hH, mul_zero] at hcert
  rcases mul_eq_zero.mp hcert with h | h
  · exact absurd h (mul_ne_zero hu0 (pow_ne_zero 3 hK0))
  · exact h

end Consequences

/-! ## The `D` family square identity -/

section DFamily

variable {R : Type*} [Field R]


/-- **Sign determination for the `D` family.**  Two `q`-expansions with the same
square and with the same (nonzero) coefficient of `q` are equal.  This is the
step "since both `Φ` and `E_D` begin with `q`, the sign is positive". -/
theorem eq_of_sq_eq_sq_of_coeff_one (f g : PowerSeries ℚ) (h : f ^ 2 = g ^ 2)
    (hf : PowerSeries.coeff 1 f = 1) (hg : PowerSeries.coeff 1 g = 1) :
    f = g := by
  have hfac : (f - g) * (f + g) = 0 := by linear_combination h
  rcases mul_eq_zero.mp hfac with h1 | h2
  · exact sub_eq_zero.mp h1
  · exfalso
    have hfg : f = -g := by linear_combination h2
    rw [hfg, map_neg, hg] at hf
    norm_num at hf

/-- **The `D`-family square identity.**  With Zagier's parametrisation
`P(t) = t η₁⁶/η₅⁶` and `F² = t⁻¹ η₅⁵/η₁`, the collapsed source `Φ = t P F³`
satisfies `Φ² = t η₁⁹ η₅³`. -/
theorem D_square (t F P e1 e5 Phi : R) (ht : t ≠ 0) (he1 : e1 ≠ 0) (he5 : e5 ≠ 0)
    (hP : P = t * e1 ^ 6 / e5 ^ 6) (hF : F ^ 2 = e5 ^ 5 / (t * e1))
    (hPhi : Phi = t * P * F ^ 3) :
    Phi ^ 2 = t * e1 ^ 9 * e5 ^ 3 := by
  have h6 : Phi ^ 2 = t ^ 2 * P ^ 2 * (F ^ 2) ^ 3 := by rw [hPhi]; ring
  rw [h6, hF, hP]
  field_simp

end DFamily

end Eisenstein
