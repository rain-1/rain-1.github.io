import RequestProject.Bridge
import RequestProject.Certificate

/-!
# The `D` family on `Γ₁(5)` as genuine `q`-expansions

Zagier's parametrisation of the Apéry `ζ(2)` family is
`t = q ∏_{n≥1}(1-qⁿ)^{5(n/5)}`, `F² = t⁻¹η₅⁵/η₁`.  This file introduces the
corresponding power series, proves that the truncated computations of
`RequestProject/Certificate.lean` compute their Fourier coefficients, and
deduces — from the assumed classical modular input of
`RequestProject/ModularInput.lean` — the identity `Φ = E_D`.
-/

set_option maxHeartbeats 1000000

namespace Eisenstein
namespace DFamily

open QS Certificate Bridge PowerSeries

/-! ### The Zagier product -/

lemma approx_tStep {n : ℕ} (hn : 0 < n) {r : S} {g : PowerSeries ℚ}
    (hr : Approx prec r g) :
    Approx prec (D.tStep r n) (g * zpowPS (1 - X ^ n) (5 * QS.chi5 n)) := by
  have hone : Approx prec (QS.sub prec (QS.one prec) (QS.shift prec n (QS.one prec)))
      (1 - X ^ n) := by
    have h := approx_sub (approx_one prec) (approx_shift (k := n) (approx_one prec))
    simpa using h
  rw [D.tStep]
  split
  · exact approx_mul hr (approx_zpow hone ((congrOne_one_sub_X_pow n).constantCoeff hn) _)
  · rename_i he
    rw [not_not] at he
    rw [he]
    simpa [zpowPS] using hr

lemma approx_zagierFold : ∀ N,
    Approx prec ((List.range' 1 N).foldl D.tStep (QS.one prec)) (zagierPartial N)
  | 0 => by simpa [zagierPartial] using approx_one prec
  | (N + 1) => by
      rw [List.range'_1_concat, List.foldl_concat, zagierPartial_succ]
      exact approx_tStep (by omega) (approx_zagierFold N)

lemma approx_uSer : Approx prec D.uSer zagierUnitPS := by
  intro i hi
  rw [D.uSer, approx_zagierFold (prec - 1) i hi,
    coeff_zagierUnitPS (N := prec - 1) (by simp [prec] at hi ⊢; omega)]

lemma constantCoeff_zagierUnitPS : constantCoeff zagierUnitPS = 1 := by
  rw [← PowerSeries.coeff_zero_eq_constantCoeff_apply, coeff_zagierUnitPS (N := 0) (le_refl 0),
    zagierPartial]
  simp

/-! ### The power series of the `D` family -/

/-- Zagier's canonical coordinate `t = q ∏_{n≥1}(1-qⁿ)^{5(n/5)}`. -/
noncomputable def tPS : PowerSeries ℚ := X * zagierUnitPS

/-- `G = F² = t⁻¹η₅⁵/η₁`. -/
noncomputable def gPS : PowerSeries ℚ := etaUnitPS [(5, 5), (1, -1)] * zagierUnitPS⁻¹

/-- The weight-six form `t η₁⁹η₅³`. -/
noncomputable def sixPS : PowerSeries ℚ := tPS * etaQPS [(1, 9), (5, 3)]

/-- The weight-three Eisenstein series `E_D`. -/
noncomputable def eDPS : PowerSeries ℚ :=
  eisPS fun m => ((divisorsList m).map fun d => psiD d * (d : ℤ) ^ 2).sum

lemma approx_tSer : Approx prec D.tSer tPS := by
  have h := approx_shift (k := 1) approx_uSer
  simpa [D.tSer, tPS] using h

lemma approx_gSer : Approx prec D.gSer gPS :=
  approx_mul (approx_etaUnit prec [(5, 5), (1, -1)] (by decide))
    (approx_inv approx_uSer constantCoeff_zagierUnitPS)

lemma approx_sixSer : Approx prec D.sixSer sixPS :=
  approx_mul approx_tSer (approx_etaQ prec [(1, 9), (5, 3)] (by decide) (by decide))

lemma approx_eD : Approx prec D.eD eDPS := approx_eisSeries prec _

/-! ### The finite checks of the `D` family, transported -/

lemma coeff_square (h : D.squareOK = true) :
    ∀ i < 64, coeff i (gPS * Modular.theta tPS ^ 2) = coeff i sixPS :=
  coeff_eq_of_eqUpTo (approx_mul approx_gSer (approx_npow (approx_theta approx_tSer) 2))
    approx_sixSer (le_refl D.cmpD) h

lemma coeff_eisen (h : D.eisenOK = true) :
    ∀ i < 64, coeff i (eDPS ^ 2) = coeff i sixPS :=
  coeff_eq_of_eqUpTo (approx_npow approx_eD 2) approx_sixSer (le_refl D.cmpD) h

lemma coeff_one_eD (h : D.leadingOK = true) : coeff 1 eDPS = 1 := by
  rw [D.leadingOK, Bool.and_eq_true, beq_iff_eq, beq_iff_eq] at h
  rw [← approx_eD 1 (by decide), h.2]
  norm_num

/-! ### The Eisenstein-source theorem for the `D` family -/

/-- **The `D` family.**  If `Φ` is a square root of `G·(θ_q t)²` beginning with
`q` — that is, `Φ = F θ_q t` for the analytic solution `F` with `F² = G`, which
is the collapsed source of Proposition *collapse of the source* — then
`Φ = E_D`.  The only inputs beyond the certificate are Ligozat's criterion (the
three weight-six forms) and Sturm's theorem. -/
theorem source_eq_eisenstein (S : Modular.SturmSetup) (hb : S.bound 6 < 64)
    (Phi : PowerSeries ℚ) (hPhi : Phi ^ 2 = gPS * Modular.theta tPS ^ 2)
    (h1 : coeff 1 Phi = 1)
    (hPhi2 : S.IsMF 6 (Phi ^ 2)) (hED2 : S.IsMF 6 (eDPS ^ 2)) (hsix : S.IsMF 6 sixPS) :
    Phi = eDPS := by
  have hcert := D.cert_D
  rw [D.certD] at hcert
  simp only [Bool.and_eq_true] at hcert
  refine Modular.D_source_eq_eisenstein_of_modular_input S Phi eDPS sixPS hPhi2 hED2 hsix
    ?_ ?_ h1 (coeff_one_eD hcert.2)
  · intro i hi
    rw [hPhi]
    exact coeff_square hcert.1.1.2 i (by omega)
  · intro i hi
    exact coeff_eisen hcert.1.2 i (by omega)

end DFamily
end Eisenstein
