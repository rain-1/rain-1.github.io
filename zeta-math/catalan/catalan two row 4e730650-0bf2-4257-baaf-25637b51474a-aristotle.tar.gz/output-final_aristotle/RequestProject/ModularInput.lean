import Mathlib
import RequestProject.AlgebraicCore

/-!
# The classical modular input: Ligozat's criterion and Sturm's theorem

The paper uses two classical black boxes that Mathlib does not provide:

* **Ligozat's criterion**, which says that the displayed eta quotients are
  modular of the stated weight, level and character, and computes their orders
  at all cusps.  In the argument this is used *only* through the statement
  that certain explicit combinations of `t`, `F` and their `θ_q`-derivatives
  are (`q`-expansions of) **holomorphic** modular forms of a definite weight:
  `K = θ_q t / t`, `P_r(t)F²`, the Rankin–Cohen expressions `H₂`, `H₃`, the
  source `F θ_q t`, and the Eisenstein series `E`.  (The cusp-order formula
  enters exactly here: it is what makes `P_r(t)F²` and `F θ_q t`
  *holomorphic*, through the cancellation `ord F = -ord t` at every pole
  of `t`.)
* **Sturm's theorem**, which upgrades a finite Fourier check to an identity.

This file isolates those two inputs in a single interface `SturmSetup` and
shows exactly what they buy: *given* the interface and the finite Fourier
checks, the Wronskian identity, the ODE identity and the source identity
`F θ_q t = E` hold identically, and hence the companion source is the
Eisenstein series.

Nothing here is assumed as a Lean `axiom`: the classical statements occur as
explicit hypotheses (fields of `SturmSetup`, or hypotheses of the theorems),
so every theorem below is an honest implication.

## Answer to "is Ligozat's criterion enough?"

No — Ligozat's criterion alone does not finish the proof.  Reading off the
argument formalised here, the ingredients are:

1. Ligozat's criterion: modularity, weight, character and cusp orders of the
   eta quotients (`SturmSetup.IsMF` applied to the six combinations above);
2. **Sturm's theorem** (`SturmSetup.sturm`), *plus* an effective Sturm bound
   for the relevant level and weight, without which the finite checks cannot be
   upgraded;
3. the fact that the Eisenstein series of the source table is itself a
   holomorphic form of the same weight and level (a standard, but separate,
   Eisenstein-series input);
4. a `q`-expansion principle identifying the abstract Fourier coefficients with
   the coefficients of the explicit eta products (the finite checks of
   `RequestProject/Certificate.lean`).

Items 1–3 are the hypotheses below; item 4 is what the certificate file
verifies numerically.
-/

open PowerSeries

namespace Eisenstein
namespace Modular

/-! ## The operator `θ_q` on `q`-expansions -/

/-- The Euler operator `θ_q = q d/dq` acting on `q`-expansions. -/
noncomputable def theta (f : PowerSeries ℚ) : PowerSeries ℚ :=
  PowerSeries.mk fun n => (n : ℚ) * coeff n f

@[simp] lemma coeff_theta (n : ℕ) (f : PowerSeries ℚ) :
    coeff n (theta f) = (n : ℚ) * coeff n f := by
  simp [theta]

lemma theta_add (f g : PowerSeries ℚ) : theta (f + g) = theta f + theta g := by
  ext n; simp [mul_add]

/-- `θ_q` is a derivation. -/
lemma theta_mul (f g : PowerSeries ℚ) :
    theta (f * g) = f * theta g + theta f * g := by
  ext n
  rw [coeff_theta, coeff_mul, map_add, coeff_mul, coeff_mul, Finset.mul_sum,
    ← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun p hp => ?_
  rw [Finset.mem_antidiagonal] at hp
  rw [coeff_theta, coeff_theta, ← hp]
  push_cast
  ring

/-! ## The interface: Ligozat's criterion and Sturm's theorem -/

/-- The classical modular input, for one fixed level and character.

`IsMF k f` is to be read as: *`f` is the `q`-expansion at `∞` of a holomorphic
modular form of weight `k`, of the level and character of the family under
consideration*.  The only properties used are that these spaces are closed
under subtraction and that Sturm's theorem holds for them with the effective
bound `bound k`. -/
structure SturmSetup where
  /-- `IsMF k f`: `f` is the `q`-expansion of a holomorphic modular form of
  weight `k` (of the fixed level and character). -/
  IsMF : ℤ → PowerSeries ℚ → Prop
  /-- An effective Sturm bound in weight `k`. -/
  bound : ℤ → ℕ
  /-- The spaces are closed under subtraction. -/
  sub_mem : ∀ k f g, IsMF k f → IsMF k g → IsMF k (f - g)
  /-- **Sturm's theorem**: a holomorphic form whose Fourier coefficients vanish
  up to the Sturm bound vanishes identically. -/
  sturm : ∀ k f, IsMF k f → (∀ i ≤ bound k, coeff i f = 0) → f = 0

namespace SturmSetup

variable (S : SturmSetup)

/-- Two holomorphic forms of the same weight whose Fourier coefficients agree
up to the Sturm bound are equal. -/
theorem eq_of_coeff_eq (k : ℤ) (f g : PowerSeries ℚ) (hf : S.IsMF k f) (hg : S.IsMF k g)
    (h : ∀ i ≤ S.bound k, coeff i f = coeff i g) : f = g := by
  have hzero := S.sturm k (f - g) (S.sub_mem k f g hf hg) (by
    intro i hi
    simp [h i hi])
  exact sub_eq_zero.mp hzero

end SturmSetup

/-! ## The leading polynomials and the Rankin–Cohen expressions -/

variable (a b c : ℚ)

/-- `P₂(t) = 1 - a t + c t²`, as a `q`-expansion. -/
noncomputable def P2 (t : PowerSeries ℚ) : PowerSeries ℚ := 1 - C a * t + C c * t ^ 2

/-- `P₃(t) = 1 - 2a t + c t²`, as a `q`-expansion. -/
noncomputable def P3 (t : PowerSeries ℚ) : PowerSeries ℚ := 1 - C (2 * a) * t + C c * t ^ 2

/-- `H₂ = F θ²F - 2(θF)² + t(-b+ct)P₂(t)F⁶`. -/
noncomputable def H2 (t F : PowerSeries ℚ) : PowerSeries ℚ :=
  F * theta (theta F) - 2 * (theta F) ^ 2
    + t * (C (-b) + C c * t) * P2 a c t * F ^ 6

/-- `H₃ = 2F θ²F - 3(θF)² + t(-2b+ct)F⁴`. -/
noncomputable def H3 (t F : PowerSeries ℚ) : PowerSeries ℚ :=
  2 * F * theta (theta F) - 3 * (theta F) ^ 2
    + t * (C (-2 * b) + C c * t) * F ^ 4

/-! ## What Ligozat + Sturm give -/

section Family

variable (S : SturmSetup) (t F K E : PowerSeries ℚ)

/-- **The Wronskian identity for an `R2` family**, as an identity of
`q`-expansions.  Ligozat's criterion makes `K = θ_q t/t` and `P₂(t)F²`
holomorphic weight-two forms; the finite check plus Sturm's theorem identify
them. -/
theorem wronskian_R2 (hK : S.IsMF 2 K) (hPF : S.IsMF 2 (P2 a c t * F ^ 2))
    (cW : ∀ i ≤ S.bound 2, coeff i K = coeff i (P2 a c t * F ^ 2)) :
    K = P2 a c t * F ^ 2 :=
  S.eq_of_coeff_eq 2 _ _ hK hPF cW

/-- **The Wronskian identity for an `R3` family**: `K² = P₃(t)F²`, both sides
being holomorphic of weight four. -/
theorem wronskian_R3 (hK : S.IsMF 4 (K ^ 2)) (hPF : S.IsMF 4 (P3 a c t * F ^ 2))
    (cW : ∀ i ≤ S.bound 4, coeff i (K ^ 2) = coeff i (P3 a c t * F ^ 2)) :
    K ^ 2 = P3 a c t * F ^ 2 :=
  S.eq_of_coeff_eq 4 _ _ hK hPF cW

/-- **The ODE identity for an `R2` family**: `H₂` is a holomorphic weight-six
form vanishing up to the Sturm bound, hence identically zero. -/
theorem ode_R2 (hH : S.IsMF 6 (H2 a b c t F))
    (cH : ∀ i ≤ S.bound 6, coeff i (H2 a b c t F) = 0) :
    H2 a b c t F = 0 :=
  S.sturm 6 _ hH cH

/-- **The ODE identity for an `R3` family**: `H₃` is a holomorphic weight-eight
form vanishing up to the Sturm bound, hence identically zero. -/
theorem ode_R3 (hH : S.IsMF 8 (H3 b c t F))
    (cH : ∀ i ≤ S.bound 8, coeff i (H3 b c t F) = 0) :
    H3 b c t F = 0 :=
  S.sturm 8 _ hH cH

/-- **The source identity `F θ_q t = E`** (Proposition *eta-source* of the
paper).  At every pole of `t` the cusp-order formula gives `ord F = -ord t`, so
`F θ_q t = (tF)·K` is holomorphic at every cusp; it is a form of weight
`wt F + 2`, as is the Eisenstein series `E` of the source table.  The finite
Fourier check and Sturm's theorem then force the identity. -/
theorem source_identity (w : ℤ) (hFt : S.IsMF w (F * theta t)) (hE : S.IsMF w E)
    (cE : ∀ i ≤ S.bound w, coeff i (F * theta t) = coeff i E) :
    F * theta t = E :=
  S.eq_of_coeff_eq w _ _ hFt hE cE

end Family

/-! ## The Eisenstein-source theorem, conditional on the modular input

The `q`-expansions live in the power-series ring, while the source
`Φ = t K^r/(P_r F)` is a quotient; the statements below therefore take a ring
homomorphism `ι` from `q`-expansions into a field `R` carrying an operator `D`
compatible with `θ_q` (for instance the field of Laurent series, or the field
of meromorphic functions on the upper half-plane). -/

section Transport

variable {R : Type*} [Field R] (ι : PowerSeries ℚ →+* R)

/-- **Eisenstein-source theorem for an `R2` family, from Ligozat + Sturm.**
All the modular input is in the hypotheses `hK`, `hPF`, `hFt`, `hE`
(Ligozat's criterion: holomorphy and weight of the six displayed forms) and in
`S.sturm` (Sturm's theorem); `cW` and `cE` are the finite Fourier checks. -/
theorem source_eq_eisenstein_R2_of_modular_input (S : SturmSetup)
    (a c : ℚ) (t F K E : PowerSeries ℚ) (w : ℤ)
    (hKt : theta t = K * t)
    (hK : S.IsMF 2 K) (hPF : S.IsMF 2 (P2 a c t * F ^ 2))
    (hFt : S.IsMF w (F * theta t)) (hE : S.IsMF w E)
    (cW : ∀ i ≤ S.bound 2, coeff i K = coeff i (P2 a c t * F ^ 2))
    (cE : ∀ i ≤ S.bound w, coeff i (F * theta t) = coeff i E)
    (hF : ι F ≠ 0) (hP : ι (P2 a c t) ≠ 0)
    (Phi : R) (hPhi : Phi = ι t * ι K ^ 2 / (ι (P2 a c t) * ι F)) :
    Phi = ι E := by
  have hw : K = P2 a c t * F ^ 2 := wronskian_R2 a c S t F K hK hPF cW
  have hs : F * theta t = E := source_identity S t F E w hFt hE cE
  have hcol : Phi = ι F * (ι K * ι t) := by
    refine collapse_R2 (ι t) (ι F) (ι K) (ι (P2 a c t)) Phi hF hP ?_ hPhi
    rw [hw]; push_cast [map_mul, map_pow]; ring
  rw [hcol, ← hs, map_mul, hKt, map_mul]

/-- **Eisenstein-source theorem for an `R3` family, from Ligozat + Sturm.** -/
theorem source_eq_eisenstein_R3_of_modular_input (S : SturmSetup)
    (a c : ℚ) (t F K E : PowerSeries ℚ) (w : ℤ)
    (hKt : theta t = K * t)
    (hK : S.IsMF 4 (K ^ 2)) (hPF : S.IsMF 4 (P3 a c t * F ^ 2))
    (hFt : S.IsMF w (F * theta t)) (hE : S.IsMF w E)
    (cW : ∀ i ≤ S.bound 4, coeff i (K ^ 2) = coeff i (P3 a c t * F ^ 2))
    (cE : ∀ i ≤ S.bound w, coeff i (F * theta t) = coeff i E)
    (hF : ι F ≠ 0) (hP : ι (P3 a c t) ≠ 0)
    (Phi : R) (hPhi : Phi = ι t * ι K ^ 3 / (ι (P3 a c t) * ι F)) :
    Phi = ι E := by
  have hw : K ^ 2 = P3 a c t * F ^ 2 := wronskian_R3 a c S t F K hK hPF cW
  have hs : F * theta t = E := source_identity S t F E w hFt hE cE
  have hcol : Phi = ι F * (ι K * ι t) := by
    refine collapse_R3 (ι t) (ι F) (ι K) (ι (P3 a c t)) Phi hF hP ?_ hPhi
    rw [← map_pow, hw]; push_cast [map_mul, map_pow]; ring
  rw [hcol, ← hs, map_mul, hKt, map_mul]

/-- **Eisenstein-source theorem for the `D` family, from Ligozat + Sturm.**
Here the weight-six square identity `Φ² = t η₁⁹η₅³ = E_D²` is what Sturm's
theorem proves, and the sign is fixed by the leading coefficients. -/
theorem D_source_eq_eisenstein_of_modular_input (S : SturmSetup)
    (Phi ED sixForm : PowerSeries ℚ)
    (hPhi2 : S.IsMF 6 (Phi ^ 2)) (hED2 : S.IsMF 6 (ED ^ 2)) (hsix : S.IsMF 6 sixForm)
    (c1 : ∀ i ≤ S.bound 6, coeff i (Phi ^ 2) = coeff i sixForm)
    (c2 : ∀ i ≤ S.bound 6, coeff i (ED ^ 2) = coeff i sixForm)
    (h1 : coeff 1 Phi = 1) (h2 : coeff 1 ED = 1) :
    Phi = ED := by
  have e1 : Phi ^ 2 = sixForm := S.eq_of_coeff_eq 6 _ _ hPhi2 hsix c1
  have e2 : ED ^ 2 = sixForm := S.eq_of_coeff_eq 6 _ _ hED2 hsix c2
  exact eq_of_sq_eq_sq_of_coeff_one Phi ED (e1.trans e2.symm) h1 h2

end Transport

end Modular
end Eisenstein
