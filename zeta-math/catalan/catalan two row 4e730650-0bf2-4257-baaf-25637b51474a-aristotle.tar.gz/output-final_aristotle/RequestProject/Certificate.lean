import RequestProject.QSeries

/-!
# The exact finite certificate

This file runs, inside Lean and with exact integer arithmetic, all the finite
verifications of the paper *Eisenstein Sources for the Twelve Modular Sporadic
Apéry Companions*:

* Ligozat's two congruences for each of the 22 eta quotients of the table of
  eleven ordinary eta parametrisations;
* the **Wronskian identity** `θ_q t = t P₂ F²` (type `R2`) resp.
  `(θ_q t)² = t² P₃ F²` (type `R3`);
* the **ODE identity** `H₂ = 0` resp. `H₃ = 0`, where
  `H₂ = F θ²F - 2(θF)² + t(-b+ct) P₂ F⁶` and
  `H₃ = 2F θ²F - 3(θF)² + t(-2b+ct) F⁴`;
* the **source identity** `F θ_q t = E` with `E` the Eisenstein series of the
  source table;
* for the `D` family on `Γ₁(5)`: Zagier's relation `P(t) = t η₁⁶/η₅⁶`, the
  Wronskian and ODE identities in terms of `G = F²`, the square identity
  `Φ² = t η₁⁹ η₅³` and the Eisenstein identity `E_D² = t η₁⁹ η₅³`.

Every check is performed through `q^63`, which is beyond all Sturm bounds
occurring in the paper (the largest is `36`).  These are honest statements
about a fixed, finite number of Fourier coefficients: the passage from them to
identities of modular forms is Sturm's theorem, which is *not* formalised here.
-/

namespace Eisenstein
namespace Certificate

open QS

/-- Internal truncation order used for all computations. -/
def prec : ℕ := 64

/-- Number of Fourier coefficients that are compared.  All eta quotients
occurring in the eleven ordinary rows have non-negative `q`-order, so every
compared coefficient is exact. -/
def cmp : ℕ := 64

/-- A row of the table of eta parametrisations: the recurrence parameters
`(a,b,c)`, the level, the eta exponents of `t` and of `F`, and the coefficient
function of the Eisenstein series of the source table. -/
structure EtaRow where
  a : ℤ
  b : ℤ
  c : ℤ
  level : ℕ
  tExp : List (ℕ × ℤ)
  fExp : List (ℕ × ℤ)
  /-- The poles of `t`: the entry `(c, -m)` records `ord_{1/c} t = -m`. -/
  polesT : List (ℕ × ℤ)
  eis : ℕ → ℤ

namespace EtaRow

/-- Ligozat's cusp-order formula
`ord_{1/c} G = N/(24 c gcd(c,N/c)) ∑_{d ∣ N} gcd(c,d)² e_d / d`. -/
def cuspOrd (N : ℕ) (exps : List (ℕ × ℤ)) (c : ℕ) : ℚ :=
  (N : ℚ) / (24 * (c : ℚ) * (Nat.gcd c (N / c) : ℚ)) *
    ((exps.map fun de => ((Nat.gcd c de.1 ^ 2 : ℕ) : ℚ) * (de.2 : ℚ) / (de.1 : ℚ)).sum)

def tSer (r : EtaRow) : S := etaQ prec r.tExp
def fSer (r : EtaRow) : S := etaQ prec r.fExp

/-- `P₂(t) = 1 - a t + c t²`. -/
def p2 (r : EtaRow) : S :=
  sub prec (add prec (one prec) (smul prec r.c (mul prec r.tSer r.tSer)))
    (smul prec r.a r.tSer)

/-- `P₃(t) = 1 - 2a t + c t²`. -/
def p3 (r : EtaRow) : S :=
  sub prec (add prec (one prec) (smul prec r.c (mul prec r.tSer r.tSer)))
    (smul prec (2 * r.a) r.tSer)

/-- `H₂ = F θ²F - 2(θF)² + t(-b+ct) P₂ F⁶`. -/
def h2 (r : EtaRow) : S :=
  let F := r.fSer
  let dF := theta prec F
  let ddF := theta prec dF
  add prec (sub prec (mul prec F ddF) (smul prec 2 (mul prec dF dF)))
    (mul prec (mul prec r.tSer (add prec (const prec (-r.b)) (smul prec r.c r.tSer)))
      (mul prec r.p2 (npow prec F 6)))

/-- `H₃ = 2F θ²F - 3(θF)² + t(-2b+ct) F⁴`. -/
def h3 (r : EtaRow) : S :=
  let F := r.fSer
  let dF := theta prec F
  let ddF := theta prec dF
  add prec (sub prec (smul prec 2 (mul prec F ddF)) (smul prec 3 (mul prec dF dF)))
    (mul prec (mul prec r.tSer (add prec (const prec (-2 * r.b)) (smul prec r.c r.tSer)))
      (npow prec F 4))

/-- Ligozat's congruences for both eta quotients of the row. -/
def ligozatOK (r : EtaRow) : Bool := ligozat r.level r.tExp && ligozat r.level r.fExp

/-- `t = q + O(q²)` and `F = 1 + O(q)`. -/
def normalisationOK (r : EtaRow) : Bool :=
  coeff r.tSer 0 == 0 && coeff r.tSer 1 == 1 && coeff r.fSer 0 == 1

/-- The cusp-order data: at every cusp `1/c` (`c ∣ N`) the eta quotient `F` is
holomorphic, the poles of `t` are exactly those listed in `polesT` with the
listed orders, and at each of them `ord F = -ord t`, so that `tF` has order `0`
there.  Moreover `ord_∞ t = 1` and `ord_∞ F = 0`. -/
def cuspOrdersOK (r : EtaRow) : Bool :=
  let cs := (List.range (r.level + 1)).filter fun c => 0 < c && r.level % c == 0
  (cs.all fun c =>
      let ot := cuspOrd r.level r.tExp c
      let of := cuspOrd r.level r.fExp c
      (0 ≤ of) &&
      (match r.polesT.find? fun p => p.1 == c with
        | some p => (ot == (p.2 : ℚ)) && (ot < 0) && (of == -ot)
        | none => 0 ≤ ot)) &&
    (r.polesT.all fun p => cs.contains p.1) &&
    (cuspOrd r.level r.tExp r.level == 1) && (cuspOrd r.level r.fExp r.level == 0)

/-- Wronskian identity of type `R2`: `θ_q t = t P₂ F²`. -/
def wronskian2OK (r : EtaRow) : Bool :=
  eqUpTo cmp (theta prec r.tSer)
    (mul prec r.tSer (mul prec r.p2 (npow prec r.fSer 2)))

/-- Wronskian identity of type `R3`: `(θ_q t)² = t² P₃ F²`. -/
def wronskian3OK (r : EtaRow) : Bool :=
  eqUpTo cmp (npow prec (theta prec r.tSer) 2)
    (mul prec (npow prec r.tSer 2) (mul prec r.p3 (npow prec r.fSer 2)))

def ode2OK (r : EtaRow) : Bool := isZeroUpTo cmp r.h2

def ode3OK (r : EtaRow) : Bool := isZeroUpTo cmp r.h3

/-- Source identity: `F θ_q t = E`. -/
def sourceOK (r : EtaRow) : Bool :=
  eqUpTo cmp (mul prec r.fSer (theta prec r.tSer)) (eisSeries prec r.eis)

/-- The full certificate for a row of type `R2`. -/
def certR2 (r : EtaRow) : Bool :=
  r.ligozatOK && r.cuspOrdersOK && r.normalisationOK && r.wronskian2OK && r.ode2OK && r.sourceOK

/-- The full certificate for a row of type `R3`. -/
def certR3 (r : EtaRow) : Bool :=
  r.ligozatOK && r.cuspOrdersOK && r.normalisationOK && r.wronskian3OK && r.ode3OK && r.sourceOK

end EtaRow

/-! ### The eleven ordinary eta rows -/

/-- `σ₃`. -/
private def s3 : ℕ → ℤ := sigmaK 3

/-- Family `A`, level `6`, character `χ₋₃`, `(a,b,c) = (7,2,-8)`. -/
def rowA : EtaRow where
  a := 7; b := 2; c := -8; level := 6
  tExp := [(1, 3), (6, 9), (2, -3), (3, -9)]
  fExp := [(2, 1), (3, 6), (1, -2), (6, -3)]
  polesT := [(3, -1)]
  eis := fun m => sigmaOut chiM3 2 m - scaled (sigmaOut chiM3 2) 2 m

/-- Family `B`, level `36`, character `χ₋₃`, `(a,b,c) = (9,3,27)`. -/
def rowB : EtaRow where
  a := 9; b := 3; c := 27; level := 36
  tExp := [(1, 3), (4, 3), (18, 9), (2, -9), (9, -3), (36, -3)]
  fExp := [(2, 9), (3, 1), (12, 1), (1, -3), (4, -3), (6, -3)]
  polesT := [(1, -1), (2, -4), (4, -1)]
  eis := fun m => sigmaIn chiM3 2 m - 6 * scaled (sigmaIn chiM3 2) 2 m
    - 8 * scaled (sigmaIn chiM3 2) 4 m

/-- Family `C`, level `6`, character `χ₋₃`, `(a,b,c) = (10,3,9)`. -/
def rowC : EtaRow where
  a := 10; b := 3; c := 9; level := 6
  tExp := [(1, 4), (6, 8), (2, -8), (3, -4)]
  fExp := [(2, 6), (3, 1), (1, -3), (6, -2)]
  polesT := [(2, -1)]
  eis := fun m => sigmaIn chiM3 2 m - 8 * scaled (sigmaIn chiM3 2) 2 m

/-- Family `E`, level `8`, character `χ₋₄`, `(a,b,c) = (12,4,32)`. -/
def rowE : EtaRow where
  a := 12; b := 4; c := 32; level := 8
  tExp := [(1, 4), (4, 2), (8, 4), (2, -10)]
  fExp := [(2, 10), (1, -4), (4, -4)]
  polesT := [(2, -1)]
  eis := fun m => sigmaIn chiM4 2 m - 8 * scaled (sigmaIn chiM4 2) 2 m

/-- Family `F`, level `12`, character `χ₋₃`, `(a,b,c) = (17,6,72)`. -/
def rowF : EtaRow where
  a := 17; b := 6; c := 72; level := 12
  tExp := [(1, 5), (3, 1), (4, 5), (6, 2), (12, 1), (2, -14)]
  fExp := [(2, 15), (3, 2), (12, 2), (1, -6), (4, -6), (6, -5)]
  polesT := [(2, -2)]
  eis := fun m => sigmaIn chiM3 2 m - 7 * scaled (sigmaIn chiM3 2) 2 m
    - 8 * scaled (sigmaIn chiM3 2) 4 m

/-- Family `α`, level `12`, trivial character, `(a,b,c) = (10,4,64)`. -/
def rowAlpha : EtaRow where
  a := 10; b := 4; c := 64; level := 12
  tExp := [(1, 6), (3, 6), (4, 6), (12, 6), (2, -12), (6, -12)]
  fExp := [(2, 10), (6, 10), (1, -4), (3, -4), (4, -4), (12, -4)]
  polesT := [(2, -2), (6, -2)]
  eis := fun m => s3 m - 17 * scaled s3 2 m - 9 * scaled s3 3 m + 16 * scaled s3 4 m
    + 153 * scaled s3 6 m - 144 * scaled s3 12 m

/-- Family `γ`, level `6`, trivial character, `(a,b,c) = (17,5,1)`. -/
def rowGamma : EtaRow where
  a := 17; b := 5; c := 1; level := 6
  tExp := [(1, 12), (6, 12), (2, -12), (3, -12)]
  fExp := [(2, 7), (3, 7), (1, -5), (6, -5)]
  polesT := [(2, -1), (3, -1)]
  eis := fun m => s3 m - 28 * scaled s3 2 m + 63 * scaled s3 3 m - 36 * scaled s3 6 m

/-- Family `δ`, level `12`, trivial character, `(a,b,c) = (7,3,81)`. -/
def rowDelta : EtaRow where
  a := 7; b := 3; c := 81; level := 12
  tExp := [(1, 4), (4, 4), (6, 16), (2, -16), (3, -4), (12, -4)]
  fExp := [(2, 12), (3, 1), (12, 1), (1, -3), (4, -3), (6, -4)]
  polesT := [(1, -1), (2, -2), (4, -1)]
  eis := fun m => s3 m - 14 * scaled s3 2 m - scaled s3 3 m + 16 * scaled s3 4 m
    + 14 * scaled s3 6 m - 16 * scaled s3 12 m

/-- Family `ε`, level `8`, trivial character, `(a,b,c) = (12,4,16)`. -/
def rowEpsilon : EtaRow where
  a := 12; b := 4; c := 16; level := 8
  tExp := [(1, 8), (8, 8), (2, -8), (4, -8)]
  fExp := [(2, 6), (4, 6), (1, -4), (8, -4)]
  polesT := [(2, -1), (4, -1)]
  eis := fun m => s3 m - 21 * scaled s3 2 m + 84 * scaled s3 4 m - 64 * scaled s3 8 m

/-- Family `ζ`, level `9`, trivial character, `(a,b,c) = (9,3,-27)`. -/
def rowZeta : EtaRow where
  a := 9; b := 3; c := -27; level := 9
  tExp := [(1, 6), (9, 6), (3, -12)]
  fExp := [(3, 10), (1, -3), (9, -3)]
  polesT := [(3, -1)]
  eis := fun m => ((divisorsList m).map fun d => chiM3 d * chiM3 (m / d) * (d : ℤ) ^ 3).sum

/-- Family `η`, level `20`, character `χ₅`, `(a,b,c) = (11,5,125)`. -/
def rowEta : EtaRow where
  a := 11; b := 5; c := 125; level := 20
  tExp := [(1, 6), (4, 6), (10, 18), (2, -18), (5, -6), (20, -6)]
  fExp := [(2, 15), (5, 1), (20, 1), (1, -5), (4, -5), (10, -3)]
  polesT := [(1, -1), (2, -4), (4, -1)]
  eis := fun m => sigmaIn chi5 3 m - 14 * scaled (sigmaIn chi5 3) 2 m
    - 16 * scaled (sigmaIn chi5 3) 4 m

/-! ### The certificates for the eleven ordinary rows -/

theorem cert_A : rowA.certR2 = true := by native_decide
theorem cert_B : rowB.certR2 = true := by native_decide
theorem cert_C : rowC.certR2 = true := by native_decide
theorem cert_E : rowE.certR2 = true := by native_decide
theorem cert_F : rowF.certR2 = true := by native_decide
theorem cert_alpha : rowAlpha.certR3 = true := by native_decide
theorem cert_gamma : rowGamma.certR3 = true := by native_decide
theorem cert_delta : rowDelta.certR3 = true := by native_decide
theorem cert_epsilon : rowEpsilon.certR3 = true := by native_decide
theorem cert_zeta : rowZeta.certR3 = true := by native_decide
theorem cert_eta : rowEta.certR3 = true := by native_decide

/-! ### The `D` family on `Γ₁(5)` -/

namespace D

/-- `(a,b,c) = (11,3,-1)`. -/
def a : ℤ := 11
def b : ℤ := 3
def c : ℤ := -1

/-- Number of Fourier coefficients compared for the `D` family. -/
def cmpD : ℕ := 64

/-- One factor `(1-qⁿ)^{5(n/5)}` of Zagier's product. -/
def tStep (r : S) (n : ℕ) : S :=
  let e := 5 * chi5 n
  if e ≠ 0 then mul prec r (zpow prec (sub prec (one prec) (shift prec n (one prec))) e) else r

/-- The unit part `∏_{n≥1} (1-qⁿ)^{5(n/5)}` of Zagier's `t`. -/
def uSer : S := (List.range' 1 (prec - 1)).foldl tStep (one prec)

/-- Zagier's `t = q ∏_{n≥1} (1-qⁿ)^{5(n/5)}`. -/
def tSer : S := shift prec 1 uSer

/-- `P(t) = 1 - 11 t - t²`. -/
def pSer : S := sub prec (sub prec (one prec) (smul prec 11 tSer)) (mul prec tSer tSer)

/-- `G = F² = t⁻¹ η₅⁵/η₁`; since `t = q·u`, this is `(η₅⁵/η₁)/q` divided by `u`,
i.e. the unit `∏(1-q^{5m})⁵/∏(1-q^m)` divided by `u`. -/
def gSer : S := mul prec (etaUnit prec [(5, 5), (1, -1)]) (inv prec uSer)

/-- The weight-six form `t η₁⁹ η₅³`. -/
def sixSer : S := mul prec tSer (etaQ prec [(1, 9), (5, 3)])

/-- The weight-three Eisenstein series `E_D`. -/
def eD : S := eisSeries prec fun m => ((divisorsList m).map fun d => psiD d * (d : ℤ) ^ 2).sum

/-- `P(t) = t η₁⁶/η₅⁶` (Zagier). -/
def zagierOK : Bool :=
  eqUpTo cmpD pSer (mul prec uSer (etaUnit prec [(1, 6), (5, -6)]))

/-- Wronskian identity `θ_q t = t P F²`. -/
def wronskianOK : Bool := eqUpTo cmpD (theta prec tSer) (mul prec tSer (mul prec pSer gSer))

/-- The ODE identity `H₂ = 0`, written in terms of `G = F²`:
`4 F² H₂ = 2G θ²G - 3(θG)² + 4 t(-b+ct) P G⁴`. -/
def odeOK : Bool :=
  let dG := theta prec gSer
  let ddG := theta prec dG
  isZeroUpTo cmpD
    (add prec (sub prec (smul prec 2 (mul prec gSer ddG)) (smul prec 3 (mul prec dG dG)))
      (smul prec 4
        (mul prec (mul prec tSer (add prec (const prec (-b)) (smul prec c tSer)))
          (mul prec pSer (npow prec gSer 4)))))

/-- The square identity `Φ² = (F θ_q t)² = t η₁⁹ η₅³`. -/
def squareOK : Bool :=
  eqUpTo cmpD (mul prec gSer (npow prec (theta prec tSer) 2)) sixSer

/-- The Eisenstein identity `E_D² = t η₁⁹ η₅³`. -/
def eisenOK : Bool := eqUpTo cmpD (npow prec eD 2) sixSer

/-- `Φ` and `E_D` both start with `q`, which fixes the sign of the square root. -/
def leadingOK : Bool :=
  coeff (mul prec gSer (npow prec (theta prec tSer) 2)) 2 == 1 && coeff eD 1 == 1

/-- The full certificate of the `D` family. -/
def certD : Bool := zagierOK && wronskianOK && odeOK && squareOK && eisenOK && leadingOK

theorem cert_D : certD = true := by native_decide

end D

end Certificate
end Eisenstein
