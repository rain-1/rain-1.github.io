# Summary of changes for run 48c1472e-3573-4d18-9005-e7af6d616e5a
**Answer to your question: Ligozat's criterion alone is not enough — but with a small, explicitly stated set of classical inputs the proof now goes through, and those inputs are in place.**

What was needed, and what is now in the project:

1. **Ligozat's criterion** (when an eta quotient is a holomorphic modular form of a given weight/level/character). This is assumed, not proved: it enters as the hypothesis that the relevant eta quotients satisfy `IsMF`. Note that for soundness I did not add Lean `axiom` declarations — the classical facts appear as hypotheses/fields of an interface, so every theorem carries them visibly in its statement.
2. **Sturm's theorem with an effective bound.** Ligozat tells you a q-expansion is modular; it does not tell you that agreeing in finitely many coefficients forces equality. This is packaged in `Modular.SturmSetup` (`RequestProject/ModularInput.lean`): a predicate `IsMF`, a bound function, closure under differences, and the Sturm vanishing principle, yielding `eq_of_coeff_eq`.
3. **Modularity of the Eisenstein series** in the source table (same weight and level) — also part of the assumed input.
4. **A q-expansion principle** linking the abstract Fourier coefficients to the coefficients actually computed by the certificate. This was *not* available and was built and proved from scratch in `RequestProject/Bridge.lean`: a correctness relation between the truncated q-series library and formal power series, with correctness proofs for every operation (ring ops, θ_q, shift, inversion, integer powers, eta products, Eisenstein series, Zagier's unit product). Without this the finite `native_decide` checks would only be statements about arrays; now they are genuine statements about Fourier coefficients.

With (1)–(3) as hypotheses and (4) proved, the paper's conclusions are established for all twelve families: the Wronskian identity, the ODE identity, the source identity F·θ_q t = E, and Φ = E — see `RequestProject/Families.lean` (the eleven eta rows, with `Good` verified by `decide` and the certificate transported coefficientwise) and `RequestProject/DFamily.lean` (the D family with Zagier's product). `RequestProject/Main.lean` and `README.md` collect the conditional results and state which inputs they rest on.

Status: the full project builds (`lake build`, 8034 jobs, success), contains no `sorry`, and no `axiom` or `@[implemented_by]`. Axiom check on the conditional theorems shows only `propext`, `Classical.choice`, `Quot.sound`, plus `Lean.ofReduceBool`/`Lean.trustCompiler` where the compiled finite certificate is used. The only mathematics left unproved is Ligozat's criterion and Sturm's theorem themselves, neither of which is in Mathlib; both are carried as explicit hypotheses rather than assumed silently.

# Summary of changes for run e4da4cd7-db24-46b2-9e97-268cc106e325
I formalized the paper `EISENSTEIN_SOURCE_THEOREM.tex` ("Eisenstein Sources for the Twelve Modular Sporadic Apéry Companions") in Lean 4 / Mathlib. The project builds cleanly with no `sorry`, and `README.md` documents the full map of the formalization.

**Files added**
- `RequestProject/AlgebraicCore.lean` — the (differential-)algebraic content, proved unconditionally.
- `RequestProject/QSeries.lean` — a small exact-arithmetic library of truncated `q`-expansions over `ℤ` (eta products, `θ_q`, series inversion, divisor sums, Ligozat data).
- `RequestProject/Certificate.lean` — the paper's "exact certificate", rerun inside Lean for all twelve families.
- `RequestProject/Main.lean` — the assembled main theorem plus a roadmap.

**Proved unconditionally**
- `source_general`: with `C = P_r/K^r` and `Φ = tK^r/(P_r F)`, the rectified equation gives `C F Φ = t`, i.e. `Φ` is the source of the normalized companion.
- `collapse_R2`, `collapse_R3` (Proposition "collapse of the source"): `Φ = F · θ_q t`, from `K = P₂F²` resp. `K² = P₃F²`.
- `L2_certificate`, `L3_certificate`: the exact identities `K³ L₂F = P₂² F H₂` and `u K³ (4L̃u) = s³ H₃`, for an arbitrary additive Leibniz operator `θ_q` on a commutative ring; and their corollaries `L2_solution`, `L3_solution`, showing that the Wronskian relation together with `H₂ = 0` (resp. `H₃ = 0`) forces `L₂F = 0` (resp. the Almkvist–Zudilin root equation).
- `D_square`: the `D`-family square identity `Φ² = t η₁⁹η₅³`, with the sign determination `eq_of_sq_eq_sq_of_coeff_one` / `D_source_eq_eisenstein` giving `Φ = E_D`.
- `source_eq_eisenstein_R2`, `source_eq_eisenstein_R3`: the main theorem in the form — given the Wronskian relation and the source identity `F θ_q t = E`, the normalized companion source equals the Eisenstein series `E`.
- `finite_certificate`: for all twelve families, verified in Lean with exact integer/rational arithmetic — Ligozat's two congruences for all 22 eta quotients, Ligozat's cusp-order formula at every cusp (reproducing the paper's pole table of `t` exactly, holomorphy of `F` at every cusp, and `ord F = -ord t` at every pole), the normalizations `t = q+O(q²)`, `F = 1+O(q)`, the Wronskian identities, the ODE identities `H₂ = 0` / `H₃ = 0`, and the source identities `F θ_q t = E`, checked through `q^63`; and for the `D` family Zagier's relation `P(t) = tη₁⁶/η₅⁶`, the Wronskian and ODE identities in terms of `G = F²`, `Φ² = tη₁⁹η₅³` and `E_D² = tη₁⁹η₅³`, checked through `q^61`. The largest Sturm bound in the paper is `36`, so all checks go well beyond the stated bounds. I also confirmed the checks are non-vacuous (perturbing a parameter, an exponent or a pole entry makes them fail).

**Not formalized (stated explicitly as hypotheses/limitations).** Two classical ingredients used by the paper are unavailable in Mathlib in the required generality and are therefore not formalized: Ligozat's criterion (that the eta quotients are modular of the stated weight/level/character with the computed cusp orders) and Sturm's theorem (upgrading a finite coefficient check to an identity of modular forms). Accordingly the modular inputs `K = P₂F²` / `K² = P₃F²` and `F θ_q t = E` appear as explicit hypotheses of the main theorems, while the certificate file establishes exactly the finite computations Sturm's theorem would upgrade.

Axioms: everything depends only on `propext`, `Classical.choice`, `Quot.sound`, except the finite certificate, which additionally uses Lean's compiled-evaluation axioms (`ofReduceBool`, `trustCompiler`).