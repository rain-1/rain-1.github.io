This project was edited by [Aristotle](https://aristotle.harmonic.fun).

To cite Aristotle:
- Tag @Aristotle-Harmonic on GitHub PRs/issues
- Add as co-author to commits:
```
Co-authored-by: Aristotle (Harmonic) <aristotle-harmonic@harmonic.fun>
```

# Formalization of *Eisenstein Sources for the Twelve Modular Sporadic Apéry Companions*

The Lean 4 / Mathlib development in `RequestProject/` formalizes the source
article `EISENSTEIN_SOURCE_THEOREM.tex`.

## Files

| file | content |
| --- | --- |
| `RequestProject/AlgebraicCore.lean` | the (differential-)algebraic content of the paper, proved unconditionally |
| `RequestProject/QSeries.lean` | a small library of truncated `q`-expansions over `ℤ` with exact arithmetic (eta products, `θ_q`, inverses, divisor sums, Ligozat data) |
| `RequestProject/Certificate.lean` | the paper's *exact certificate*: all finite checks for the twelve families, run inside Lean |
| `RequestProject/ModularInput.lean` | the two classical modular inputs (Ligozat's criterion, Sturm's theorem) as an explicit hypothesis interface, and the theorems they imply |
| `RequestProject/Bridge.lean` | correctness of the truncated library: every operation computes the Fourier coefficients of the corresponding formal power series over `ℚ` |
| `RequestProject/Families.lean` | the eleven eta rows as genuine `q`-expansions, the certificate transported to them, and the resulting conditional theorems |
| `RequestProject/DFamily.lean` | the same for the `D` family on `Γ₁(5)` (Zagier's product) |
| `RequestProject/Main.lean` | the assembled main theorem and a roadmap of what is and is not formalized |

## What is proved unconditionally

* `Eisenstein.source_general` — the rectified equation: with `C = P_r/K^r` and
  `Φ = t K^r/(P_r F)`, one has `C F Φ = t`, i.e. `Φ` is the source of the
  normalized companion.
* `Eisenstein.collapse_R2`, `Eisenstein.collapse_R3` — Proposition *collapse of
  the source*: `Φ = F · θ_q t`, from `K = P₂F²` resp. `K² = P₃F²`.
* `Eisenstein.L2_certificate`, `Eisenstein.L3_certificate` — the exact
  differential-algebra identities `K³ L₂F = P₂² F H₂` and
  `u K³ (4 L̃u) = s³ H₃` behind the Wronskian–ODE certificate lemma, for an
  arbitrary additive Leibniz operator `θ_q` on a commutative ring.
* `Eisenstein.L2_solution`, `Eisenstein.L3_solution` — consequently, the
  Wronskian relation together with `H₂ = 0` (resp. `H₃ = 0`) forces `L₂F = 0`
  (resp. the Almkvist–Zudilin root equation `L̃u = 0`).
* `Eisenstein.D_square` — the `D`-family square identity `Φ² = t η₁⁹η₅³`, and
  `Eisenstein.eq_of_sq_eq_sq_of_coeff_one` / `Eisenstein.D_source_eq_eisenstein`
  — the sign determination `Φ = E_D`.
* `Eisenstein.source_eq_eisenstein_R2`, `Eisenstein.source_eq_eisenstein_R3` —
  the resulting main theorem: given the Wronskian relation and the source
  identity `F θ_q t = E`, the normalized companion source is the Eisenstein
  series `E`.
* `Eisenstein.finite_certificate` — the complete finite certificate (see below).

## The finite certificate

`RequestProject/Certificate.lean` reruns, in Lean and with exact
integer/rational arithmetic, every finite verification of the paper:

* Ligozat's two congruences for all 22 eta quotients of the eleven ordinary
  rows, and Ligozat's cusp-order formula at every cusp `1/c`, `c ∣ N`: the pole
  table of `t` is reproduced exactly, `F` is holomorphic at every cusp, and
  `ord F = -ord t` at every pole of `t` (so `tF` has order `0` there);
* the normalizations `t = q + O(q²)`, `F = 1 + O(q)`;
* the Wronskian identities `θ_q t = t P₂ F²` (type `R2`) and
  `(θ_q t)² = t² P₃ F²` (type `R3`);
* the ODE identities `H₂ = 0`, `H₃ = 0`;
* the source identities `F θ_q t = E` against the Eisenstein coefficient
  formulas of the source table;
* for the `D` family on `Γ₁(5)`: Zagier's relation `P(t) = t η₁⁶/η₅⁶`, the
  Wronskian and ODE identities written in terms of `G = F²`, the square identity
  `Φ² = t η₁⁹η₅³`, the Eisenstein identity `E_D² = t η₁⁹η₅³`, and the leading
  coefficients that fix the sign.

The eleven eta rows are checked through `q^63` and the `D` family through
`q^61`; the largest Sturm bound occurring in the paper is `36`.  These checks
are evaluated by compiled evaluation, so `Eisenstein.finite_certificate`
additionally depends on Lean's `ofReduceBool`/`trustCompiler` axioms; all other
results depend only on the standard `propext`, `Classical.choice`, `Quot.sound`.

## Assuming the classical modular input

The two ingredients the paper uses as black boxes are **Ligozat's criterion**
(the eta quotients are modular of the stated weight, level and character, with
the cusp orders given by the order formula) and **Sturm's theorem** (a
holomorphic form vanishing beyond the Sturm bound vanishes).  Mathlib provides
neither, so they are *assumed*, as explicit hypotheses — never as Lean
`axiom`s, so every theorem below is an honest implication.

`Eisenstein.Modular.SturmSetup` packages them:

* `IsMF k f` — "`f` is the `q`-expansion of a holomorphic modular form of
  weight `k`, of the level and character of the family";
* `bound k` — an effective Sturm bound in weight `k`;
* `sturm` — Sturm's theorem for those spaces.

Ligozat's criterion is then used exactly through the `IsMF` hypotheses attached
to the finitely many forms of the argument: `K = θ_q t/t`, `P_r(t)F²`, `H₂`
resp. `H₃`, `F θ_q t`, and the Eisenstein series `E`.  (For `P_r(t)F²` and
`F θ_q t` this is where the cusp-order formula is used: holomorphy at the poles
of `t` comes from the cancellation `ord F = -ord t`, which the certificate
verifies numerically.)

Ligozat's criterion alone is *not* enough to close the argument.  What is
needed, in addition, is: Sturm's theorem together with an effective bound; the
fact that the Eisenstein series of the source table is itself a holomorphic
form of the same weight and level; and a `q`-expansion principle identifying
the abstract Fourier coefficients with the coefficients of the explicit eta
products.  The last item is supplied here by `RequestProject/Bridge.lean`,
which proves the truncated `q`-expansion library correct against formal power
series over `ℚ` — so the certificate's checks really are statements about the
Fourier coefficients of the eta quotients and of Zagier's product.

Given all of this, the paper's conclusions are proved for all twelve families:

* `Eisenstein.Families.Good.wronskian_eq_R2` / `…_R3` — `K = P₂F²`,
  `K² = P₃F²`;
* `Eisenstein.Families.Good.ode_eq_zero_R2` / `…_R3` — `H₂ = 0`, `H₃ = 0`;
* `Eisenstein.Families.Good.source_eq` — `F θ_q t = E`;
* `Eisenstein.Families.source_eq_eisenstein_R2_of_mem` (families `A, B, C, E,
  F`), `Eisenstein.Families.source_eq_eisenstein_R3_of_mem` (families
  `α, γ, δ, ε, ζ, η`) and `Eisenstein.DFamily.source_eq_eisenstein` (family
  `D`) — the source is the Eisenstein series, `Φ = E`.
